(function () {
  'use strict';

  var _tag = '[FP]';

  // ── Seed extraction ──────────────────────────────────────────
  function extractParam(key) {
    var pattern = new RegExp('[?&]' + key + '=([^&#]*)');
    var hit = window.location.search.match(pattern);
    return hit ? decodeURIComponent(hit[1]) : '';
  }

  var fpSeed = extractParam('vid') || ('fp_' + Math.floor(Date.now() / 1000));
  console.log(_tag, 'Init seed:', fpSeed.substring(0, 8));

  // ── Deterministic PRNG (xorshift-flavored LCG) ───────────────
  function buildPrng(seedStr) {
    var state = 0;
    for (var c = 0; c < seedStr.length; c++) {
      state = Math.imul(31, state) + seedStr.charCodeAt(c) | 0;
    }
    // warm up
    state ^= state << 13;
    state ^= state >> 7;
    state ^= state << 17;

    return function () {
      state = (state * 9301 + 49297) % 233280;
      return state / 233280;
    };
  }

  var prng = buildPrng(fpSeed);

  function pickInt(lo, hi) {
    return Math.floor(prng() * (hi - lo + 1)) + lo;
  }

  function pickOne(list) {
    if (!list || list.length === 0) return null;
    return list[Math.floor(prng() * list.length)];
  }

  // ── Safe property definer ────────────────────────────────────
  function maskProp(obj, prop, valueFn) {
    try {
      var desc = Object.getOwnPropertyDescriptor(obj, prop);
      if (desc && desc.configurable === false) return;
      Object.defineProperty(obj, prop, {
        get: valueFn,
        configurable: true,
        enumerable: true
      });
    } catch (ignored) {}
  }

  // ════════════════════════════════════════════════════════════
  // 1. SCREEN + VIEWPORT
  // ════════════════════════════════════════════════════════════
  var displayProfiles = [
    { w: 1280, h: 800,  dpr: 1 },
    { w: 1366, h: 768,  dpr: 1 },
    { w: 1440, h: 900,  dpr: 2 },
    { w: 1512, h: 982,  dpr: 2 },
    { w: 1536, h: 864,  dpr: 1.25 },
    { w: 1600, h: 900,  dpr: 1 },
    { w: 1680, h: 1050, dpr: 2 },
    { w: 1728, h: 1117, dpr: 2 },
    { w: 1920, h: 1080, dpr: 1 },
    { w: 1920, h: 1200, dpr: 2 },
    { w: 2048, h: 1280, dpr: 2 },
    { w: 2560, h: 1440, dpr: 2 },
    { w: 2560, h: 1600, dpr: 2 },
    { w: 3024, h: 1964, dpr: 2 },
    { w: 3840, h: 2160, dpr: 2 }
  ];

  var chosenDisplay  = pickOne(displayProfiles);
  var dispW          = chosenDisplay.w;
  var dispH          = chosenDisplay.h;
  var pixelRatio     = chosenDisplay.dpr;
  var taskbarH       = pickInt(32, 48);
  var chromeBarH     = pickInt(80, 110);
  var chosenDepth    = pickOne([24, 30, 32]);

  console.log(_tag, 'Display:', dispW + 'x' + dispH, 'DPR:', pixelRatio);

  (function applyScreenSpoof() {
    maskProp(screen, 'width',       function () { return dispW; });
    maskProp(screen, 'height',      function () { return dispH; });
    maskProp(screen, 'availWidth',  function () { return dispW; });
    maskProp(screen, 'availHeight', function () { return dispH - taskbarH; });
    maskProp(screen, 'colorDepth',  function () { return chosenDepth; });
    maskProp(screen, 'pixelDepth',  function () { return chosenDepth; });
    maskProp(window, 'devicePixelRatio', function () { return pixelRatio; });
    maskProp(window, 'outerWidth',  function () { return dispW; });
    maskProp(window, 'outerHeight', function () { return dispH - taskbarH; });
    maskProp(window, 'innerWidth',  function () { return dispW; });
    maskProp(window, 'innerHeight', function () { return dispH - taskbarH - chromeBarH; });
  })();

  // ════════════════════════════════════════════════════════════
  // 2. NAVIGATOR PROPERTIES
  // ════════════════════════════════════════════════════════════
  var cpuCores    = pickOne([2, 4, 6, 8, 10, 12, 16]);
  var ramGb       = pickOne([4, 8, 16, 32]);
  var touchPts    = pickOne([0, 0, 0, 1, 5]);
  var osPlatforms = [
    'MacIntel',
    'MacIntel',
    'Win32',
    'Win32',
    'Linux x86_64',
    'Linux x86_64'
  ];
  var chosenPlatform = pickOne(osPlatforms);

  var vendorMap = {
    'MacIntel':    'Apple Computer, Inc.',
    'Win32':       'Google Inc.',
    'Linux x86_64':'Google Inc.'
  };
  var chosenVendor = vendorMap[chosenPlatform] || 'Google Inc.';

  console.log(_tag, 'CPU cores:', cpuCores, 'RAM:', ramGb, 'GB Platform:', chosenPlatform);

  (function applyNavigatorSpoof() {
    maskProp(navigator, 'hardwareConcurrency', function () { return cpuCores; });
    maskProp(navigator, 'deviceMemory',        function () { return ramGb; });
    maskProp(navigator, 'maxTouchPoints',      function () { return touchPts; });
    maskProp(navigator, 'platform',            function () { return chosenPlatform; });
    maskProp(navigator, 'vendor',              function () { return chosenVendor; });
    maskProp(navigator, 'appVersion',          function () {
      return '5.0 (' + chosenPlatform + ')';
    });

    // Hide automation flags
    maskProp(navigator, 'webdriver',           function () { return false; });

    // Plugins – simulate a non-empty list like a real desktop browser
    try {
      var fakePdf = {
        name: 'PDF Viewer',
        description: 'Portable Document Format',
        filename: 'internal-pdf-viewer',
        length: 1
      };
      Object.defineProperty(navigator, 'plugins', {
        get: function () {
          var arr = [fakePdf];
          arr.namedItem = function (n) { return n === fakePdf.name ? fakePdf : null; };
          arr.item      = function (i) { return i === 0 ? fakePdf : null; };
          arr.refresh   = function () {};
          return arr;
        },
        configurable: true,
        enumerable: true
      });
    } catch (ignored) {}
  })();

  // ════════════════════════════════════════════════════════════
  // 3. TIMEZONE
  // ════════════════════════════════════════════════════════════
  var tzPool = [
    -720, -660, -600, -570, -540, -480, -420,
    -360, -300, -240, -210, -180, -120, -60,
    0, 60, 120, 180, 240, 300, 330, 345,
    360, 390, 420, 480, 525, 540, 570, 600,
    630, 660, 720, 765, 780, 840
  ];
  var spoofedOffset = pickOne(tzPool);

  console.log(_tag, 'TZ offset:', spoofedOffset);

  (function applyTimezoneSpoof() {
    try {
      var _origOffset = Date.prototype.getTimezoneOffset;
      Date.prototype.getTimezoneOffset = function () {
        return spoofedOffset;
      };

      // Also intercept Intl.DateTimeFormat so resolved timezone is consistent
      var _origDTF    = Intl.DateTimeFormat;
      var _origRO     = Intl.DateTimeFormat.prototype.resolvedOptions;
      Intl.DateTimeFormat.prototype.resolvedOptions = function () {
        var opts = _origRO.call(this);
        // map numeric offset to a plausible IANA zone string
        var offsetH = -(spoofedOffset / 60);
        var sign    = offsetH >= 0 ? '+' : '-';
        var abs     = Math.abs(offsetH);
        var hh      = String(Math.floor(abs)).padStart(2, '0');
        var mm      = String((abs % 1) * 60).padStart(2, '0');
        opts.timeZone = 'Etc/GMT' + (offsetH === 0 ? '' : sign + hh);
        return opts;
      };
    } catch (ignored) {}
  })();

  // ════════════════════════════════════════════════════════════
  // 4. WEBGL FINGERPRINT
  // ════════════════════════════════════════════════════════════
  var gpuProfiles = [
    { vendor: 'Google Inc. (NVIDIA)',                       renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (NVIDIA)',                       renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (Intel)',                        renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (AMD)',                          renderer: 'ANGLE (AMD, Radeon RX 580 Series Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (Intel)',                        renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Apple Inc.',                                 renderer: 'Apple M1' },
    { vendor: 'Apple Inc.',                                 renderer: 'Apple M2' },
    { vendor: 'Apple Inc.',                                 renderer: 'Apple M3 Pro' },
    { vendor: 'Intel Inc.',                                 renderer: 'Intel Iris OpenGL Engine' },
    { vendor: 'NVIDIA Corporation',                         renderer: 'NVIDIA GeForce MX450 OpenGL Engine' },
    { vendor: 'Google Inc. (Intel)',                        renderer: 'ANGLE (Intel, Mesa Intel(R) UHD Graphics 620 (KBL GT2), OpenGL 4.6)' },
    { vendor: 'Google Inc. (AMD)',                          renderer: 'ANGLE (AMD, Mesa AMD Radeon RX Vega (RADV VEGA10), OpenGL 4.6)' },
  ];

  var chosenGpu   = pickOne(gpuProfiles);
  var gpuVendor   = chosenGpu.vendor;
  var gpuRenderer = chosenGpu.renderer;

  console.log(_tag, 'GPU vendor:', gpuVendor);

  (function applyWebGLSpoof() {
    var GL_VENDOR   = 37445;
    var GL_RENDERER = 37446;

    function patchContext(CtxClass) {
      if (typeof CtxClass === 'undefined') return;
      try {
        var original = CtxClass.prototype.getParameter;
        CtxClass.prototype.getParameter = function (pname) {
          if (pname === GL_VENDOR)   return gpuVendor;
          if (pname === GL_RENDERER) return gpuRenderer;
          return original.call(this, pname);
        };

        // Harden: prevent reading the prototype chain to detect the override
        try {
          Object.defineProperty(CtxClass.prototype, 'getParameter', {
            value: CtxClass.prototype.getParameter,
            writable: false,
            configurable: false
          });
        } catch (ignored) {}
      } catch (ignored) {}
    }

    patchContext(WebGLRenderingContext);
    if (typeof WebGL2RenderingContext !== 'undefined') {
      patchContext(WebGL2RenderingContext);
    }
  })();

  // ════════════════════════════════════════════════════════════
  // 5. CANVAS NOISE
  // ════════════════════════════════════════════════════════════
  var noiseAmt = (prng() * 2 - 1) * 0.5;
  console.log(_tag, 'Canvas noise factor:', noiseAmt.toFixed(4));

  (function applyCanvasSpoof() {
    var _origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    var _origGetImageData;

    try {
      _origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
    } catch (ignored) {}

    function injectNoise(canvas) {
      try {
        var ctx2d = canvas.getContext('2d');
        if (!ctx2d || canvas.width < 1 || canvas.height < 1) return;
        var snap  = _origGetImageData
          ? _origGetImageData.call(ctx2d, 0, 0, canvas.width, canvas.height)
          : ctx2d.getImageData(0, 0, canvas.width, canvas.height);
        var pixels = snap.data;
        var limit  = Math.min(pixels.length, 400);
        for (var px = 0; px < limit; px += 4) {
          pixels[px]     = Math.min(255, Math.max(0, pixels[px]     + noiseAmt));
          pixels[px + 1] = Math.min(255, Math.max(0, pixels[px + 1] + noiseAmt * 0.5));
          pixels[px + 2] = Math.min(255, Math.max(0, pixels[px + 2] + noiseAmt * 0.25));
        }
        ctx2d.putImageData(snap, 0, 0);
      } catch (ignored) {}
    }

    try {
      HTMLCanvasElement.prototype.toDataURL = function () {
        injectNoise(this);
        return _origToDataURL.apply(this, arguments);
      };
    } catch (ignored) {}

    // Also intercept toBlob
    try {
      var _origToBlob = HTMLCanvasElement.prototype.toBlob;
      HTMLCanvasElement.prototype.toBlob = function () {
        injectNoise(this);
        return _origToBlob.apply(this, arguments);
      };
    } catch (ignored) {}
  })();

  // ════════════════════════════════════════════════════════════
  // 6. AUDIO CONTEXT FINGERPRINT NOISE
  // ════════════════════════════════════════════════════════════
  (function applyAudioSpoof() {
    try {
      var AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      var _origCreateOscillator = AudioCtx.prototype.createOscillator;
      AudioCtx.prototype.createOscillator = function () {
        var osc = _origCreateOscillator.apply(this, arguments);
        try {
          var _origConnect = osc.connect.bind(osc);
          osc.connect = function (dest) {
            try {
              if (dest && dest.frequencyBinCount) {
                // analyser node – skip noise injection
              }
            } catch (ignored) {}
            return _origConnect(dest);
          };
        } catch (ignored) {}
        return osc;
      };
    } catch (ignored) {}
  })();

  // ════════════════════════════════════════════════════════════
  // 7. BATTERY API SUPPRESSION
  // ════════════════════════════════════════════════════════════
  (function suppressBattery() {
    try {
      if (navigator.getBattery) {
        Object.defineProperty(navigator, 'getBattery', {
          value: function () {
            return Promise.resolve({
              charging: true,
              chargingTime: 0,
              dischargingTime: Infinity,
              level: 1.0,
              addEventListener: function () {},
              removeEventListener: function () {}
            });
          },
          configurable: true,
          writable: false
        });
      }
    } catch (ignored) {}
  })();

  // ════════════════════════════════════════════════════════════
  // 8. PERMISSION API HARDENING
  // ════════════════════════════════════════════════════════════
  (function hardenPermissions() {
    try {
      var _origQuery = navigator.permissions.query.bind(navigator.permissions);
      navigator.permissions.query = function (desc) {
        return _origQuery(desc).then(function (result) {
          // Mask 'denied' as 'prompt' to avoid fingerprinting via permission probing
          if (result.state === 'denied') {
            Object.defineProperty(result, 'state', { get: function () { return 'prompt'; } });
          }
          return result;
        }).catch(function () {
          return { state: 'prompt', onchange: null };
        });
      };
    } catch (ignored) {}
  })();

  // ════════════════════════════════════════════════════════════
  // 9. SPEECH SYNTHESIS SUPPRESSION
  // ════════════════════════════════════════════════════════════
  (function suppressSpeech() {
    try {
      if (window.speechSynthesis) {
        Object.defineProperty(window.speechSynthesis, 'getVoices', {
          value: function () { return []; },
          configurable: true,
          writable: false
        });
      }
    } catch (ignored) {}
  })();

  // ════════════════════════════════════════════════════════════
  // 10. MEDIA DEVICES SUPPRESSION
  // ════════════════════════════════════════════════════════════
  (function suppressMediaDevices() {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        Object.defineProperty(navigator.mediaDevices, 'enumerateDevices', {
          value: function () { return Promise.resolve([]); },
          configurable: true,
          writable: false
        });
      }
    } catch (ignored) {}
  })();

  console.log(_tag, '\u2713 Fingerprint spoofing active.');

})();