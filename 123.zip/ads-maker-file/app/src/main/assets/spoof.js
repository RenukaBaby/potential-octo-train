(function(){
  'use strict';
  
  const log = (msg) => console.log('[FINGERPRINT]', msg);
  log('Initializing advanced spoofing system...');
  
  // URL parameter extraction utility
  const extractUrlParam = (paramName) => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(paramName) || '';
  };
  
  const fingerprintSeed = extractUrlParam('vid') || 'fallback_seed';
  log(`Using seed: ${fingerprintSeed.slice(0, 8)}...`);
  
  // Deterministic PRNG implementation
  class SeededGenerator {
    constructor(seedValue) {
      this.state = 0;
      for (let i = 0; i < seedValue.length; i++) {
        this.state = ((this.state << 5) - this.state + seedValue.charCodeAt(i)) & 0xffffffff;
      }
    }
    
    next() {
      this.state = (this.state * 16807) % 2147483647;
      return this.state / 2147483647;
    }
    
    range(min, max) {
      return Math.floor(this.next() * (max - min + 1)) + min;
    }
    
    pick(collection) {
      return collection[this.range(0, collection.length - 1)];
    }
  }
  
  const randomizer = new SeededGenerator(fingerprintSeed);
  
  // Display configuration profiles
  const displayProfiles = [
    {width: 360, height: 640, ratio: 2},
    {width: 360, height: 800, ratio: 3},
    {width: 375, height: 667, ratio: 2},
    {width: 390, height: 844, ratio: 3},
    {width: 393, height: 851, ratio: 2.625},
    {width: 412, height: 915, ratio: 2.625},
    {width: 414, height: 896, ratio: 3},
    {width: 428, height: 926, ratio: 3},
    {width: 360, height: 780, ratio: 3}
  ];
  
  const selectedProfile = randomizer.pick(displayProfiles);
  const fakeWidth = selectedProfile.width;
  const fakeHeight = selectedProfile.height;
  const fakePixelRatio = selectedProfile.ratio;
  const fakeColorBits = randomizer.pick([24, 32]);
  
  log(`Display: ${fakeWidth}×${fakeHeight} @ ${fakePixelRatio}x`);
  
  // Screen property spoofing with error handling
  const spoofDisplayProperties = () => {
    try {
      const descriptors = {
        width: {value: fakeWidth, configurable: true},
        height: {value: fakeHeight, configurable: true},
        availWidth: {value: fakeWidth, configurable: true},
        availHeight: {value: fakeHeight - randomizer.range(0, 24), configurable: true},
        colorDepth: {value: fakeColorBits, configurable: true},
        pixelDepth: {value: fakeColorBits, configurable: true}
      };
      
      Object.keys(descriptors).forEach(prop => {
        Object.defineProperty(screen, prop, {
          get: () => descriptors[prop].value,
          configurable: descriptors[prop].configurable
        });
      });
      
      Object.defineProperty(window, 'devicePixelRatio', {
        get: () => fakePixelRatio,
        configurable: true
      });
      
      Object.defineProperty(window, 'innerWidth', {
        get: () => fakeWidth,
        configurable: true
      });
      
      Object.defineProperty(window, 'innerHeight', {
        get: () => fakeHeight - randomizer.range(50, 120),
        configurable: true
      });
    } catch (err) {
      log(`Display spoofing failed: ${err.message}`);
    }
  };
  
  // Hardware specification spoofing
  const spoofHardwareSpecs = () => {
    const cpuCoreCount = randomizer.pick([4, 6, 8, 10, 12]);
    const memoryAmount = randomizer.pick([2, 3, 4, 6, 8]);
    const touchCapacity = randomizer.pick([1, 5, 10]);
    const systemPlatforms = ['Linux armv81', 'Linux armv8l', 'Linux aarch64', 'Android'];
    const selectedPlatform = randomizer.pick(systemPlatforms);
    
    log(`Hardware: ${cpuCoreCount} cores, ${memoryAmount}GB RAM`);
    
    try {
      Object.defineProperty(navigator, 'hardwareConcurrency', {
        get: () => cpuCoreCount,
        configurable: true
      });
      
      if (typeof navigator.deviceMemory === 'undefined') {
        Object.defineProperty(navigator, 'deviceMemory', {
          get: () => memoryAmount,
          configurable: true
        });
      }
      
      Object.defineProperty(navigator, 'maxTouchPoints', {
        get: () => touchCapacity,
        configurable: true
      });
      
      Object.defineProperty(navigator, 'platform', {
        get: () => selectedPlatform,
        configurable: true
      });
    } catch (err) {
      log(`Hardware spoofing failed: ${err.message}`);
    }
  };
  
  // Timezone manipulation
  const spoofTimezone = () => {
    const timezoneValues = [-720, -480, -420, -360, -300, -240, -180, 0, 60, 120, 180, 300, 330, 480, 540, 600];
    const fakeOffset = randomizer.pick(timezoneValues);
    
    log(`Timezone offset: ${fakeOffset}`);
    
    try {
      const originalTimezoneMethod = Date.prototype.getTimezoneOffset;
      Date.prototype.getTimezoneOffset = function() {
        return fakeOffset;
      };
    } catch (err) {
      log(`Timezone spoofing failed: ${err.message}`);
    }
  };
  
  // WebGL renderer spoofing
  const spoofWebGLContext = () => {
    const gpuManufacturers = [
      'Qualcomm', 'ARM', 'Google Inc. (Qualcomm)', 'Apple Inc.', 'NVIDIA Corporation',
      'Imagination Technologies', 'Broadcom'
    ];
    const gpuModels = [
      'Adreno (TM) 730', 'Adreno (TM) 660', 'Adreno (TM) 640', 'Mali-G78', 'Mali-G77',
      'Apple A15 GPU', 'Apple A16 GPU', 'PowerVR Rogue GE8320',
      'ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)'
    ];
    
    const fakeVendor = randomizer.pick(gpuManufacturers);
    const fakeRenderer = randomizer.pick(gpuModels);
    
    log(`WebGL: ${fakeVendor} / ${fakeRenderer}`);
    
    const patchWebGLContext = (contextPrototype) => {
      const originalGetParameter = contextPrototype.getParameter;
      contextPrototype.getParameter = function(parameter) {
        switch (parameter) {
          case 37445: // VENDOR
            return fakeVendor;
          case 37446: // RENDERER
            return fakeRenderer;
          default:
            return originalGetParameter.call(this, parameter);
        }
      };
    };
    
    try {
      if (typeof WebGLRenderingContext !== 'undefined') {
        patchWebGLContext(WebGLRenderingContext.prototype);
      }
      if (typeof WebGL2RenderingContext !== 'undefined') {
        patchWebGLContext(WebGL2RenderingContext.prototype);
      }
    } catch (err) {
      log(`WebGL spoofing failed: ${err.message}`);
    }
  };
  
  // Canvas fingerprint obfuscation
  const obfuscateCanvasFingerprint = () => {
    const noiseIntensity = (randomizer.next() * 2 - 1) * 0.5;
    log(`Canvas noise intensity: ${noiseIntensity.toFixed(3)}`);
    
    try {
      const originalDataURLMethod = HTMLCanvasElement.prototype.toDataURL;
      HTMLCanvasElement.prototype.toDataURL = function(...args) {
        try {
          const canvasContext = this.getContext('2d');
          if (canvasContext && this.width > 0 && this.height > 0) {
            const pixelData = canvasContext.getImageData(0, 0, this.width, this.height);
            const dataLength = Math.min(pixelData.data.length, 400);
            
            for (let i = 0; i < dataLength; i += 4) {
              pixelData.data[i] = Math.min(255, Math.max(0, pixelData.data[i] + noiseIntensity));
            }
            
            canvasContext.putImageData(pixelData, 0, 0);
          }
        } catch (err) {
          // Silently continue if canvas manipulation fails
        }
        return originalDataURLMethod.apply(this, args);
      };
    } catch (err) {
      log(`Canvas spoofing failed: ${err.message}`);
    }
  };
  
  // Execute all spoofing functions
  spoofDisplayProperties();
  spoofHardwareSpecs();
  spoofTimezone();
  spoofWebGLContext();
  obfuscateCanvasFingerprint();
  
  log('✓ Advanced fingerprint spoofing system activated');
  
})();