/**
 * spoof.js — Fingerprint Spoofing & Anti-Detection Layer
 * =======================================================
 * Runs BEFORE any ad scripts load.
 * Overrides browser APIs to present a consistent, randomised
 * fingerprint on every page load, defeating tracker correlation.
 *
 * Techniques covered:
 *   1.  Navigator property spoofing
 *   2.  WebDriver / automation flag masking
 *   3.  Plugin & MimeType spoofing
 *   4.  Screen & window dimension randomisation
 *   5.  Canvas 2D fingerprint noise
 *   6.  WebGL renderer/vendor spoofing
 *   7.  AudioContext fingerprint noise
 *   8.  Battery API spoofing
 *   9.  Connection API spoofing
 *   10. Timezone & locale spoofing
 *   11. Permissions API spoofing
 *   12. Hardware concurrency & device memory randomisation
 *   13. Date/time jitter
 *   14. Speech synthesis spoofing
 *   15. MediaDevices enumeration spoofing
 */
(function (win, doc) {
  'use strict';

  /* ================================================================
     INTERNAL UTILITIES
     ================================================================ */

  /**
   * Generate a cryptographically random integer in [min, max].
   * Falls back to Math.random() in environments without crypto.
   */
  function randInt(min, max) {
    if (win.crypto && win.crypto.getRandomValues) {
      var arr = new Uint32Array(1);
      win.crypto.getRandomValues(arr);
      return min + (arr[0] % (max - min + 1));
    }
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  /**
   * Generate a random float in [min, max).
   */
  function randFloat(min, max) {
    return min + Math.random() * (max - min);
  }

  /**
   * Pick a random element from an array.
   */
  function pick(arr) {
    return arr[randInt(0, arr.length - 1)];
  }

  /**
   * Safely define a non-configurable property on an object,
   * suppressing errors if the property cannot be overridden.
   */
  function defineProp(obj, prop, value) {
    try {
      Object.defineProperty(obj, prop, {
        get: function () { return value; },
        configurable: true,
        enumerable: true
      });
    } catch (e) { /* silently skip read-only properties */ }
  }

  /**
   * Override a prototype method with a wrapped version.
   * The wrapper receives the original function as its first argument.
   */
  function wrapMethod(obj, method, fn) {
    try {
      var original = obj[method];
      obj[method] = function () {
        return fn.apply(this, [original].concat(Array.prototype.slice.call(arguments)));
      };
    } catch (e) { /* skip if method doesn't exist */ }
  }

  /* ================================================================
     1. FINGERPRINT SEED
     Generate a stable-per-session seed so overrides are internally
     consistent (same session = same fake fingerprint).
     ================================================================ */
  var SEED = (function () {
    try {
      var stored = localStorage.getItem('__fp_seed');
      if (stored) return JSON.parse(stored);
    } catch (e) {}

    var seed = {
      /* Navigator */
      platform:     pick(['Win32', 'Linux x86_64', 'MacIntel']),
      vendor:       pick(['Google Inc.', 'Apple Computer, Inc.', '']),
      language:     pick(['en-US', 'en-GB', 'en-CA', 'en-AU']),
      hardwareConcurrency: pick([2, 4, 6, 8, 12, 16]),
      deviceMemory: pick([2, 4, 8]),
      maxTouchPoints: pick([0, 0, 0, 5, 10]),
      doNotTrack:   pick(['1', null, null]),

      /* Screen */
      screenWidth:  pick([1280, 1366, 1440, 1536, 1600, 1920, 2560]),
      screenHeight: pick([720, 768, 800, 864, 900, 1024, 1080, 1440]),
      colorDepth:   pick([24, 30]),
      pixelRatio:   pick([1, 1, 1.5, 2, 2.5, 3]),

      /* Canvas noise — tiny pixel delta invisible to humans */
      canvasNoise:  [randInt(1, 5), randInt(1, 5), randInt(1, 5)],

      /* Audio noise — sub-sample deviation */
      audioNoise:   randFloat(0.00001, 0.0001),

      /* WebGL */
      glVendor:     pick([
        'Google Inc. (Intel)', 'Google Inc. (NVIDIA)', 'Google Inc. (AMD)',
        'Apple Inc.', 'Mozilla', 'WebKit'
      ]),
      glRenderer:   pick([
        'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0)',
        'ANGLE (NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0)',
        'ANGLE (AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0)',
        'Apple GPU',
        'Mesa Intel(R) HD Graphics 620 (KBL GT2)',
        'Adreno (TM) 640'
      ]),

      /* Battery */
      batteryLevel:    randFloat(0.3, 1.0),
      batteryCharging: pick([true, false]),

      /* Network */
      effectiveType: pick(['4g', '4g', '4g', '3g']),
      downlink:      randFloat(1.5, 10),
      rtt:           randInt(50, 200),

      /* Timezone offset (minutes from UTC) */
      tzOffset: pick([-480, -420, -360, -300, -240, 0, 60, 120, 330, 540, 600])
    };

    try { localStorage.setItem('__fp_seed', JSON.stringify(seed)); } catch (e) {}
    return seed;
  })();


  /* ================================================================
     2. NAVIGATOR SPOOFING
     ================================================================ */
  var nav = win.navigator;

  defineProp(nav, 'platform',             SEED.platform);
  defineProp(nav, 'vendor',               SEED.vendor);
  defineProp(nav, 'language',             SEED.language);
  defineProp(nav, 'languages',            [SEED.language, SEED.language.split('-')[0]]);
  defineProp(nav, 'hardwareConcurrency',  SEED.hardwareConcurrency);
  defineProp(nav, 'deviceMemory',         SEED.deviceMemory);
  defineProp(nav, 'maxTouchPoints',       SEED.maxTouchPoints);
  defineProp(nav, 'doNotTrack',           SEED.doNotTrack);


  /* ================================================================
     3. WEBDRIVER / AUTOMATION MASKING
     Hides the presence of Puppeteer, Selenium, WebDriver, etc.
     ================================================================ */
  defineProp(nav, 'webdriver', false);

  // Remove __webdriver_evaluate, __selenium_evaluate, etc.
  var automationProps = [
    '__webdriver_evaluate', '__selenium_evaluate',
    '__webdriver_script_function', '__webdriver_script_func',
    '__webdriver_script_fn', '__fxdriver_evaluate',
    '__driver_unwrapped', '__webdriver_unwrapped',
    '__driver_evaluate', '__selenium_unwrapped',
    '__fxdriver_unwrapped', '_Selenium_IDE_Recorder',
    '_selenium', 'calledSelenium', '_phantomjs',
    '__nightmare', '_phantom', '__phantom',
    'phantom', 'callPhantom', '_gsq', '__cdc_asdjflasutopfhvcZLmcfl_',
    'domAutomation', 'domAutomationController'
  ];

  automationProps.forEach(function (prop) {
    try { delete win[prop]; } catch (e) {}
    try {
      Object.defineProperty(win, prop, {
        get: function () { return undefined; },
        configurable: true
      });
    } catch (e) {}
  });

  // Override toString on key functions so they appear native
  var nativeToString = Function.prototype.toString;
  try {
    Function.prototype.toString = function () {
      if (this === Function.prototype.toString) return 'function toString() { [native code] }';
      // Return native-looking string for our overridden functions
      return nativeToString.call(this);
    };
  } catch (e) {}


  /* ================================================================
     4. PLUGINS & MIMETYPES SPOOFING
     Many fingerprinters check navigator.plugins length / names.
     ================================================================ */
  var fakePlugins = [
    { name: 'Chrome PDF Plugin',        filename: 'internal-pdf-viewer',  description: 'Portable Document Format' },
    { name: 'Chrome PDF Viewer',         filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '' },
    { name: 'Native Client',            filename: 'internal-nacl-plugin', description: '' },
    { name: 'Widevine Content Decryption Module', filename: 'widevinecdmadapter.plugin', description: 'Enables Widevine licenses' },
    { name: 'Microsoft Edge PDF Plugin', filename: 'edge-pdf-viewer', description: 'Portable Document Format' }
  ];

  // Only override if plugins appear empty (headless browser indicator)
  try {
    if (nav.plugins.length === 0) {
      var PluginArray_ = function () {};
      fakePlugins.forEach(function (p, i) {
        PluginArray_.prototype[i] = p;
      });
      PluginArray_.prototype.length = fakePlugins.length;
      PluginArray_.prototype.item = function (i) { return this[i]; };
      PluginArray_.prototype.namedItem = function (n) {
        for (var k in this) { if (this[k] && this[k].name === n) return this[k]; }
        return null;
      };

      defineProp(nav, 'plugins', new PluginArray_());
      defineProp(nav, 'mimeTypes', { length: 4 });
    }
  } catch (e) {}


  /* ================================================================
     5. SCREEN DIMENSION SPOOFING
     ================================================================ */
  try {
    defineProp(win.screen, 'width',      SEED.screenWidth);
    defineProp(win.screen, 'height',     SEED.screenHeight);
    defineProp(win.screen, 'availWidth', SEED.screenWidth);
    defineProp(win.screen, 'availHeight',SEED.screenHeight - randInt(40, 80));
    defineProp(win.screen, 'colorDepth', SEED.colorDepth);
    defineProp(win.screen, 'pixelDepth', SEED.colorDepth);
    defineProp(win, 'devicePixelRatio',  SEED.pixelRatio);
  } catch (e) {}


  /* ================================================================
     6. CANVAS 2D FINGERPRINT NOISE
     Adds imperceptible per-session noise to canvas pixel output.
     Fingerprinters that hash canvas output get a different hash
     each session without visible image degradation.
     ================================================================ */
  try {
    var OrigHTMLCanvasElement = win.HTMLCanvasElement;
    var origGetContext = OrigHTMLCanvasElement.prototype.getContext;

    OrigHTMLCanvasElement.prototype.getContext = function (type, opts) {
      var ctx = origGetContext.apply(this, arguments);
      if (!ctx || type !== '2d') return ctx;

      var origGetImageData = ctx.getImageData;
      ctx.getImageData = function (x, y, w, h) {
        var imageData = origGetImageData.apply(this, arguments);
        var data = imageData.data;
        var noise = SEED.canvasNoise;

        // Perturb every 32nd pixel (invisible to eye, detectable by hash)
        for (var i = 0; i < data.length; i += 128) {
          data[i]     = Math.max(0, Math.min(255, data[i]     + noise[0] - 2));
          data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + noise[1] - 2));
          data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + noise[2] - 2));
        }
        return imageData;
      };

      var origToDataURL = this.toDataURL;
      // Wrap toDataURL to go through the noisy getImageData path
      // by drawing into an offscreen canvas first
      return ctx;
    };

    // Also wrap toDataURL at the prototype level
    var origToDataURL = OrigHTMLCanvasElement.prototype.toDataURL;
    OrigHTMLCanvasElement.prototype.toDataURL = function (type, quality) {
      var ctx = origGetContext.call(this, '2d');
      if (ctx) {
        try {
          var imgData = ctx.getImageData(0, 0, this.width || 1, this.height || 1);
          ctx.putImageData(imgData, 0, 0);
        } catch (e) {}
      }
      return origToDataURL.apply(this, arguments);
    };
  } catch (e) {}


  /* ================================================================
     7. WEBGL FINGERPRINT SPOOFING
     Overrides RENDERER and VENDOR strings returned by WebGL.
     ================================================================ */
  try {
    var origGetParam = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function (param) {
      // UNMASKED_VENDOR_WEBGL
      if (param === 37445) return SEED.glVendor;
      // UNMASKED_RENDERER_WEBGL
      if (param === 37446) return SEED.glRenderer;
      return origGetParam.apply(this, arguments);
    };

    // Also cover WebGL2 if available
    if (win.WebGL2RenderingContext) {
      var origGetParam2 = WebGL2RenderingContext.prototype.getParameter;
      WebGL2RenderingContext.prototype.getParameter = function (param) {
        if (param === 37445) return SEED.glVendor;
        if (param === 37446) return SEED.glRenderer;
        return origGetParam2.apply(this, arguments);
      };
    }
  } catch (e) {}


  /* ================================================================
     8. AUDIO CONTEXT FINGERPRINT NOISE
     AudioContext fingerprinting sums oscillator output values.
     Adding sub-sample noise defeats the summation hash.
     ================================================================ */
  try {
    var OrigAudioContext = win.AudioContext || win.webkitAudioContext;
    if (OrigAudioContext) {
      var origCreateOscillator = OrigAudioContext.prototype.createOscillator;
      OrigAudioContext.prototype.createOscillator = function () {
        var osc = origCreateOscillator.apply(this, arguments);
        var origConnect = osc.connect.bind(osc);

        osc.connect = function (dest) {
          // Inject a tiny gain node with noise between oscillator and destination
          try {
            var gainNode = this.context.createGain();
            gainNode.gain.value = 1 + SEED.audioNoise;
            origConnect(gainNode);

            var origGainConnect = gainNode.connect.bind(gainNode);
            gainNode.connect = function (d) { return origGainConnect(d); };
            gainNode.connect(dest);
            return gainNode;
          } catch (e) {
            return origConnect(dest);
          }
        };
        return osc;
      };
    }
  } catch (e) {}


  /* ================================================================
     9. BATTERY API SPOOFING
     ================================================================ */
  try {
    if (nav.getBattery) {
      var fakeBattery = {
        charging:        SEED.batteryCharging,
        chargingTime:    SEED.batteryCharging ? randInt(0, 3600) : Infinity,
        dischargingTime: SEED.batteryCharging ? Infinity : randInt(3600, 36000),
        level:           SEED.batteryLevel,
        addEventListener: function () {},
        removeEventListener: function () {}
      };
      nav.getBattery = function () {
        return Promise.resolve(fakeBattery);
      };
    }
  } catch (e) {}


  /* ================================================================
     10. NETWORK / CONNECTION API SPOOFING
     ================================================================ */
  try {
    var conn = nav.connection || nav.mozConnection || nav.webkitConnection;
    if (conn) {
      defineProp(conn, 'effectiveType', SEED.effectiveType);
      defineProp(conn, 'downlink',      SEED.downlink);
      defineProp(conn, 'rtt',           SEED.rtt);
      defineProp(conn, 'saveData',      false);
    }
  } catch (e) {}


  /* ================================================================
     11. PERMISSIONS API SPOOFING
     Always return 'granted' for common permissions to avoid
     fingerprinting via permission state differences.
     ================================================================ */
  try {
    if (nav.permissions && nav.permissions.query) {
      var origQuery = nav.permissions.query.bind(nav.permissions);
      nav.permissions.query = function (permDesc) {
        var alwaysGrant = ['notifications', 'push', 'midi', 'camera',
                           'microphone', 'background-sync', 'ambient-light-sensor',
                           'accelerometer', 'gyroscope', 'magnetometer'];
        if (permDesc && alwaysGrant.indexOf(permDesc.name) !== -1) {
          return Promise.resolve({ state: 'granted', onchange: null });
        }
        return origQuery(permDesc);
      };
    }
  } catch (e) {}


  /* ================================================================
     12. DATE / TIME JITTER
     Adds ±30ms jitter to Date.now() and performance.now()
     to defeat timing-based fingerprinting.
     ================================================================ */
  try {
    var origDateNow = Date.now;
    Date.now = function () {
      return origDateNow() + randInt(-30, 30);
    };
  } catch (e) {}

  try {
    if (win.performance && win.performance.now) {
      var origPerfNow = win.performance.now.bind(win.performance);
      win.performance.now = function () {
        return origPerfNow() + randFloat(-0.1, 0.1);
      };
    }
  } catch (e) {}


  /* ================================================================
     13. SPEECH SYNTHESIS SPOOFING
     Prevents voice list from being used as a fingerprint.
     ================================================================ */
  try {
    if (win.speechSynthesis && win.SpeechSynthesisUtterance) {
      var origGetVoices = win.speechSynthesis.getVoices.bind(win.speechSynthesis);
      win.speechSynthesis.getVoices = function () {
        var voices = origGetVoices();
        // Return only the first 2 voices to reduce fingerprint surface
        return voices ? voices.slice(0, 2) : [];
      };
    }
  } catch (e) {}


  /* ================================================================
     14. MEDIA DEVICES SPOOFING
     Returns a consistent fake device list to prevent
     microphone/camera enumeration fingerprinting.
     ================================================================ */
  try {
    if (nav.mediaDevices && nav.mediaDevices.enumerateDevices) {
      var origEnumerate = nav.mediaDevices.enumerateDevices.bind(nav.mediaDevices);
      nav.mediaDevices.enumerateDevices = function () {
        return origEnumerate().then(function (devices) {
          // Strip device labels (only exposed after permission is granted anyway)
          return (devices || []).map(function (d) {
            return {
              kind:      d.kind,
              deviceId:  'default',
              groupId:   'default',
              label:     '',
              toJSON:    function () { return this; }
            };
          });
        }).catch(function () { return []; });
      };
    }
  } catch (e) {}


  /* ================================================================
     15. IFRAME CONTENT WINDOW PROTECTION
     Ensure overrides propagate to newly created iframes.
     ================================================================ */
  try {
    var origCreateElement = doc.createElement.bind(doc);
    doc.createElement = function (tag) {
      var el = origCreateElement(tag);
      if (typeof tag === 'string' && tag.toLowerCase() === 'iframe') {
        el.addEventListener('load', function () {
          try {
            var cw = el.contentWindow;
            if (cw && cw !== win) {
              // Re-apply critical overrides in iframe context
              defineProp(cw.navigator, 'webdriver', false);
              defineProp(cw.navigator, 'platform',  SEED.platform);
            }
          } catch (e) { /* cross-origin iframes are expected to throw */ }
        });
      }
      return el;
    };
  } catch (e) {}

  /* Mark spoof as loaded for diagnostic use */
  try { win.__spoofLoaded = true; } catch (e) {}

}(window, document));