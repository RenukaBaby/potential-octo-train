(function () {
  'use strict';

  console.log('[SPOOF] Starting fingerprint randomization...');

  // -----------------------------------------------
  // URL PARAMETER READER
  // -----------------------------------------------
  function extractParam(paramName) {
    var pattern = new RegExp("[?&]" + paramName + "=([^&]*)");
    var result = window.location.search.match(pattern);
    return result ? decodeURIComponent(result[1]) : "";
  }

  var fingerprintSeed = extractParam("vid") || "defaultseed";
  console.log('[SPOOF] Seed:', fingerprintSeed.substring(0, 8));

  // -----------------------------------------------
  // SEEDED PSEUDO-RANDOM NUMBER GENERATOR
  // -----------------------------------------------
  function buildPrng(inputSeed) {
    var state = 0;
    for (var c = 0; c < inputSeed.length; c++) {
      state = (state << 5) - state + inputSeed.charCodeAt(c);
      state |= 0;
    }
    return function () {
      state = (state * 9301 + 49297) % 233280;
      return state / 233280;
    };
  }

  var prng = buildPrng(fingerprintSeed);

  function pickInt(lo, hi) {
    return Math.floor(prng() * (hi - lo + 1)) + lo;
  }

  function pickFrom(list) {
    if (!list || list.length === 0) return null;
    return list[pickInt(0, list.length - 1)];
  }

  // -----------------------------------------------
  // SAFE PROPERTY DEFINER
  // -----------------------------------------------
  function defineGetter(obj, prop, fn) {
    try {
      Object.defineProperty(obj, prop, {
        get: fn,
        configurable: true,
        enumerable: true
      });
    } catch (e) {}
  }

  // -----------------------------------------------
  // 1. SCREEN & VIEWPORT SPOOFING
  // -----------------------------------------------
  var screenProfiles = [
    { w: 360, h: 640,  dpr: 2       },
    { w: 360, h: 800,  dpr: 3       },
    { w: 375, h: 667,  dpr: 2       },
    { w: 390, h: 844,  dpr: 3       },
    { w: 393, h: 851,  dpr: 2.625   },
    { w: 412, h: 915,  dpr: 2.625   },
    { w: 414, h: 896,  dpr: 3       },
    { w: 428, h: 926,  dpr: 3       },
    { w: 360, h: 780,  dpr: 3       }
  ];

  var chosenProfile  = pickFrom(screenProfiles) || screenProfiles[0];
  var spoofWidth     = chosenProfile.w;
  var spoofHeight    = chosenProfile.h;
  var spoofDpr       = chosenProfile.dpr;
  var spoofColorBits = pickFrom([24, 32]) || 24;
  var availOffset    = pickInt(0, 24);
  var innerOffset    = pickInt(50, 120);

  console.log('[SPOOF] Screen:', spoofWidth + 'x' + spoofHeight, 'DPR:', spoofDpr);

  try {
    defineGetter(screen, 'width',       function () { return spoofWidth; });
    defineGetter(screen, 'height',      function () { return spoofHeight; });
    defineGetter(screen, 'availWidth',  function () { return spoofWidth; });
    defineGetter(screen, 'availHeight', function () { return spoofHeight - availOffset; });
    defineGetter(screen, 'colorDepth',  function () { return spoofColorBits; });
    defineGetter(screen, 'pixelDepth',  function () { return spoofColorBits; });
    defineGetter(window, 'devicePixelRatio', function () { return spoofDpr; });
    defineGetter(window, 'innerWidth',  function () { return spoofWidth; });
    defineGetter(window, 'innerHeight', function () { return spoofHeight - innerOffset; });
  } catch (e) {
    console.log('[SPOOF] Screen override error:', e.message);
  }

  // -----------------------------------------------
  // 2. NAVIGATOR PROPERTY SPOOFING
  // -----------------------------------------------
  var spoofCores   = pickFrom([4, 6, 8, 10, 12]) || 8;
  var spoofRam     = pickFrom([2, 3, 4, 6, 8])   || 4;
  var spoofTouch   = pickFrom([1, 5, 10])         || 5;
  var spoofPlatform = pickFrom([
    "Linux armv81",
    "Linux armv8l",
    "Linux aarch64",
    "Android"
  ]) || "Android";

  console.log('[SPOOF] HW:', spoofCores, 'cores,', spoofRam, 'GB RAM');

  try {
    defineGetter(navigator, 'hardwareConcurrency', function () { return spoofCores; });
    if (!navigator.deviceMemory) {
      defineGetter(navigator, 'deviceMemory', function () { return spoofRam; });
    }
    defineGetter(navigator, 'maxTouchPoints', function () { return spoofTouch; });
    defineGetter(navigator, 'platform',       function () { return spoofPlatform; });
  } catch (e) {
    console.log('[SPOOF] Navigator override error:', e.message);
  }

  // -----------------------------------------------
  // 3. TIMEZONE SPOOFING
  // -----------------------------------------------
  var tzPool = [
    -720, -480, -420, -360, -300,
    -240, -180, 0, 60, 120, 180,
    300, 330, 480, 540, 600
  ];
  var spoofTzOffset = pickFrom(tzPool) || 0;

  console.log('[SPOOF] Timezone offset:', spoofTzOffset);

  try {
    var nativeTzOffset = Date.prototype.getTimezoneOffset;
    Date.prototype.getTimezoneOffset = function () {
      return spoofTzOffset;
    };
  } catch (e) {
    console.log('[SPOOF] Timezone override error:', e.message);
  }

  // -----------------------------------------------
  // 4. WEBGL VENDOR & RENDERER SPOOFING
  // -----------------------------------------------
  var vendorPool = [
    "Qualcomm",
    "ARM",
    "Google Inc. (Qualcomm)",
    "Apple Inc.",
    "NVIDIA Corporation",
    "Imagination Technologies",
    "Broadcom"
  ];

  var rendererPool = [
    "Adreno (TM) 730",
    "Adreno (TM) 660",
    "Adreno (TM) 640",
    "Mali-G78",
    "Mali-G77",
    "Apple A15 GPU",
    "Apple A16 GPU",
    "PowerVR Rogue GE8320",
    "ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)"
  ];

  var spoofVendor   = pickFrom(vendorPool)   || "Qualcomm";
  var spoofRenderer = pickFrom(rendererPool) || "Adreno (TM) 660";

  var UNMASKED_VENDOR_WEBGL   = 37445;
  var UNMASKED_RENDERER_WEBGL = 37446;

  console.log('[SPOOF] WebGL:', spoofVendor, '/', spoofRenderer);

  try {
    var nativeGl1Param = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function (pname) {
      if (pname === UNMASKED_VENDOR_WEBGL)   return spoofVendor;
      if (pname === UNMASKED_RENDERER_WEBGL) return spoofRenderer;
      return nativeGl1Param.call(this, pname);
    };

    if (typeof WebGL2RenderingContext !== "undefined") {
      var nativeGl2Param = WebGL2RenderingContext.prototype.getParameter;
      WebGL2RenderingContext.prototype.getParameter = function (pname) {
        if (pname === UNMASKED_VENDOR_WEBGL)   return spoofVendor;
        if (pname === UNMASKED_RENDERER_WEBGL) return spoofRenderer;
        return nativeGl2Param.call(this, pname);
      };
    }
  } catch (e) {
    console.log('[SPOOF] WebGL override error:', e.message);
  }

  // -----------------------------------------------
  // 5. CANVAS NOISE INJECTION
  // -----------------------------------------------
  var pixelNoise = (prng() * 2 - 1) * 0.5;
  console.log('[SPOOF] Canvas noise:', pixelNoise.toFixed(3));

  try {
    var nativeToDataURL = HTMLCanvasElement.prototype.toDataURL;

    HTMLCanvasElement.prototype.toDataURL = function () {
      try {
        var ctx2d = this.getContext('2d');
        if (ctx2d && this.width > 0 && this.height > 0) {
          var pixels = ctx2d.getImageData(0, 0, this.width, this.height);
          var limit  = Math.min(pixels.data.length, 400);
          for (var p = 0; p < limit; p += 4) {
            pixels.data[p] = Math.min(255, Math.max(0, pixels.data[p] + pixelNoise));
          }
          ctx2d.putImageData(pixels, 0, 0);
        }
      } catch (e) {}
      return nativeToDataURL.apply(this, arguments);
    };
  } catch (e) {
    console.log('[SPOOF] Canvas override error:', e.message);
  }

  console.log('[SPOOF] ✓ Fingerprint randomization complete!');

}());