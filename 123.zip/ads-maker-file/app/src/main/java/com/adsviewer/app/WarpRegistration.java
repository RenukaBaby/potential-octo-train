package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class WarpRegistration {

    private static final String LOG_TAG = "AdsViewer/WARP-REG";

    private static final String REGISTRATION_ENDPOINT = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String HTTP_USER_AGENT = "okhttp/3.12.1";
    private static final String CLIENT_VERSION_HEADER = "a-6.30-3596";

    private static final String PREF_PRIVATE_KEY   = "warp_priv";
    private static final String PREF_PUBLIC_KEY    = "warp_pub";
    private static final String PREF_SERVER_KEY    = "warp_srv_pub";
    private static final String PREF_ENDPOINT      = "warp_endpoint";
    private static final String PREF_IPV4          = "warp_v4";
    private static final String PREF_IPV6          = "warp_v6";
    private static final String PREF_CLIENT_ID     = "warp_client_id";

    public static class WarpConfig {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;
    }

    public static WarpConfig getOrRegister(SharedPreferences prefs, boolean forceFreshRegistration)
            throws Exception {

        if (!forceFreshRegistration
                && prefs.contains(PREF_PRIVATE_KEY)
                && prefs.contains(PREF_SERVER_KEY)) {

            WarpConfig cached = loadFromPrefs(prefs);
            Log.d(LOG_TAG, "Reusing cached WARP registration: v4=" + cached.v4Address);
            return cached;
        }

        Log.d(LOG_TAG, "Registering new WARP device with Cloudflare...");
        return performRegistration(prefs);
    }

    private static WarpConfig loadFromPrefs(SharedPreferences prefs) {
        WarpConfig cfg = new WarpConfig();
        cfg.privateKeyBase64 = prefs.getString(PREF_PRIVATE_KEY, null);
        cfg.publicKeyBase64  = prefs.getString(PREF_PUBLIC_KEY,  null);
        cfg.serverPublicKey  = prefs.getString(PREF_SERVER_KEY,  null);
        cfg.endpoint         = prefs.getString(PREF_ENDPOINT,    null);
        cfg.v4Address        = prefs.getString(PREF_IPV4,        null);
        cfg.v6Address        = prefs.getString(PREF_IPV6,        null);
        cfg.clientId         = prefs.getString(PREF_CLIENT_ID,   null);
        return cfg;
    }

    private static WarpConfig performRegistration(SharedPreferences prefs) throws Exception {
        KeyPair keyPair = new KeyPair();
        String generatedPriv = keyPair.getPrivateKey().toBase64();
        String generatedPub  = keyPair.getPublicKey().toBase64();

        String requestPayload = buildRequestPayload(generatedPub);

        OkHttpClient httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        Request httpRequest = new Request.Builder()
                .url(REGISTRATION_ENDPOINT)
                .header("User-Agent", HTTP_USER_AGENT)
                .header("CF-Client-Version", CLIENT_VERSION_HEADER)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(
                        requestPayload,
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        String rawResponse = executeRequest(httpClient, httpRequest);
        Log.d(LOG_TAG, "WARP reg response received (" + rawResponse.length() + " bytes)");

        WarpConfig result = parseResponse(rawResponse, generatedPriv, generatedPub);
        validateAndPersist(result, prefs);

        Log.d(LOG_TAG, "[WARP] Registered with Cloudflare: v4=" + result.v4Address
                + " endpoint=" + result.endpoint);

        return result;
    }

    private static String buildRequestPayload(String publicKeyB64) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("key",        publicKeyB64);
        payload.put("install_id", "");
        payload.put("fcm_token",  "");
        payload.put("tos",        currentUtcTimestamp());
        payload.put("model",      "PC");
        payload.put("type",       "Android");
        payload.put("locale",     "en_US");
        return payload.toString();
    }

    private static String executeRequest(OkHttpClient client, Request request) throws IOException {
        try (Response response = client.newCall(request).execute()) {
            ResponseBody body = response.body();
            String bodyText = (body != null) ? body.string() : "";
            if (!response.isSuccessful()) {
                throw new IOException("WARP reg HTTP " + response.code() + ": " + bodyText);
            }
            return bodyText;
        }
    }

    private static WarpConfig parseResponse(String json, String privKey, String pubKey)
            throws Exception {

        JSONObject root       = new JSONObject(json);
        JSONObject configNode = root.getJSONObject("config");

        JSONArray  peersArray = configNode.getJSONArray("peers");
        JSONObject firstPeer  = peersArray.getJSONObject(0);
        String     serverPub  = firstPeer.getString("public_key");

        JSONObject epObject   = firstPeer.getJSONObject("endpoint");
        String     epHost     = epObject.getString("host");

        JSONObject ifaceNode  = configNode.getJSONObject("interface");
        JSONObject addrNode   = ifaceNode.getJSONObject("addresses");
        String     ipv4       = addrNode.getString("v4");
        String     ipv6       = addrNode.getString("v6");

        String     cid        = configNode.optString("client_id", "");

        WarpConfig cfg = new WarpConfig();
        cfg.privateKeyBase64 = privKey;
        cfg.publicKeyBase64  = pubKey;
        cfg.serverPublicKey  = serverPub;
        cfg.endpoint         = epHost;
        cfg.v4Address        = ipv4;
        cfg.v6Address        = ipv6;
        cfg.clientId         = cid;

        return cfg;
    }

    private static void validateAndPersist(WarpConfig cfg, SharedPreferences prefs)
            throws Exception {

        Key.fromBase64(cfg.privateKeyBase64);
        Key.fromBase64(cfg.serverPublicKey);

        prefs.edit()
                .putString(PREF_PRIVATE_KEY, cfg.privateKeyBase64)
                .putString(PREF_PUBLIC_KEY,  cfg.publicKeyBase64)
                .putString(PREF_SERVER_KEY,  cfg.serverPublicKey)
                .putString(PREF_ENDPOINT,    cfg.endpoint)
                .putString(PREF_IPV4,        cfg.v4Address)
                .putString(PREF_IPV6,        cfg.v6Address)
                .putString(PREF_CLIENT_ID,   cfg.clientId)
                .apply();
    }

    public static void clearCache(SharedPreferences prefs) {
        prefs.edit()
                .remove(PREF_PRIVATE_KEY)
                .remove(PREF_PUBLIC_KEY)
                .remove(PREF_SERVER_KEY)
                .remove(PREF_ENDPOINT)
                .remove(PREF_IPV4)
                .remove(PREF_IPV6)
                .remove(PREF_CLIENT_ID)
                .apply();
    }

    private static String currentUtcTimestamp() {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        return fmt.format(new Date());
    }
}