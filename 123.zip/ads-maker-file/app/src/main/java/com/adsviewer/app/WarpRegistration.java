package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class CloudflareWarpRegistrar {
    private static final String LOG_TAG = "AdsViewer/WARP-REG";

    private static final String API_ENDPOINT = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String HEADER_USER_AGENT = "User-Agent";
    private static final String VALUE_USER_AGENT = "okhttp/3.12.1";
    private static final String HEADER_CLIENT_VERSION = "CF-Client-Version";
    private static final String VALUE_CLIENT_VERSION = "a-6.30-3596";
    private static final String CONTENT_TYPE_JSON = "application/json; charset=utf-8";

    private static final String CACHE_PRIV_KEY = "warp_priv";
    private static final String CACHE_PUB_KEY = "warp_pub";
    private static final String CACHE_SRV_PUB_KEY = "warp_srv_pub";
    private static final String CACHE_ENDPOINT_HOST = "warp_endpoint";
    private static final String CACHE_IP_V4 = "warp_v4";
    private static final String CACHE_IP_V6 = "warp_v6";
    private static final String CACHE_CLIENT_ID = "warp_client_id";

    public static class WarpRegistrationData {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;
    }

    public static WarpRegistrationData obtainDeviceConfig(SharedPreferences sharedPreferences, boolean requireNewDevice) throws Exception {
        if (!requireNewDevice && hasValidCache(sharedPreferences)) {
            WarpRegistrationData cachedData = loadFromCache(sharedPreferences);
            Log.d(LOG_TAG, "Reusing cached WARP registration: v4=" + cachedData.v4Address);
            return cachedData;
        }

        Log.d(LOG_TAG, "Registering new WARP device with Cloudflare...");
        return createNewRegistration(sharedPreferences);
    }

    public static void purgeCache(SharedPreferences sharedPreferences) {
        sharedPreferences.edit()
                .remove(CACHE_PRIV_KEY)
                .remove(CACHE_PUB_KEY)
                .remove(CACHE_SRV_PUB_KEY)
                .remove(CACHE_ENDPOINT_HOST)
                .remove(CACHE_IP_V4)
                .remove(CACHE_IP_V6)
                .remove(CACHE_CLIENT_ID)
                .apply();
    }

    private static boolean hasValidCache(SharedPreferences sp) {
        return sp.contains(CACHE_PRIV_KEY) && sp.contains(CACHE_SRV_PUB_KEY);
    }

    private static WarpRegistrationData loadFromCache(SharedPreferences sp) {
        WarpRegistrationData config = new WarpRegistrationData();
        config.privateKeyBase64 = sp.getString(CACHE_PRIV_KEY, null);
        config.publicKeyBase64 = sp.getString(CACHE_PUB_KEY, null);
        config.serverPublicKey = sp.getString(CACHE_SRV_PUB_KEY, null);
        config.endpoint = sp.getString(CACHE_ENDPOINT_HOST, null);
        config.v4Address = sp.getString(CACHE_IP_V4, null);
        config.v6Address = sp.getString(CACHE_IP_V6, null);
        config.clientId = sp.getString(CACHE_CLIENT_ID, null);
        return config;
    }

    private static void saveToCache(SharedPreferences sp, WarpRegistrationData data) {
        sp.edit()
                .putString(CACHE_PRIV_KEY, data.privateKeyBase64)
                .putString(CACHE_PUB_KEY, data.publicKeyBase64)
                .putString(CACHE_SRV_PUB_KEY, data.serverPublicKey)
                .putString(CACHE_ENDPOINT_HOST, data.endpoint)
                .putString(CACHE_IP_V4, data.v4Address)
                .putString(CACHE_IP_V6, data.v6Address)
                .putString(CACHE_CLIENT_ID, data.clientId)
                .apply();
    }

    private static WarpRegistrationData createNewRegistration(SharedPreferences sp) throws Exception {
        KeyPair wireGuardKeys = new KeyPair();
        String privKeyB64 = wireGuardKeys.getPrivateKey().toBase64();
        String pubKeyB64 = wireGuardKeys.getPublicKey().toBase64();

        JSONObject payload = new JSONObject();
        payload.put("key", pubKeyB64);
        payload.put("install_id", "");
        payload.put("fcm_token", "");
        payload.put("tos", fetchCurrentUtcTime());
        payload.put("model", "PC");
        payload.put("type", "Android");
        payload.put("locale", "en_US");

        OkHttpClient httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        RequestBody requestBody = RequestBody.create(
                payload.toString(),
                MediaType.parse(CONTENT_TYPE_JSON)
        );

        Request registrationRequest = new Request.Builder()
                .url(API_ENDPOINT)
                .header(HEADER_USER_AGENT, VALUE_USER_AGENT)
                .header(HEADER_CLIENT_VERSION, VALUE_CLIENT_VERSION)
                .header("Content-Type", "application/json")
                .post(requestBody)
                .build();

        String responseBodyString = "";
        try (Response httpResponse = httpClient.newCall(registrationRequest).execute()) {
            ResponseBody body = httpResponse.body();
            if (body != null) {
                responseBodyString = body.string();
            }
            if (!httpResponse.isSuccessful()) {
                throw new IOException("WARP reg HTTP " + httpResponse.code() + ": " + responseBodyString);
            }
        }

        Log.d(LOG_TAG, "WARP reg response received (" + responseBodyString.length() + " bytes)");

        WarpRegistrationData parsedConfig = parseCloudflareResponse(responseBodyString, privKeyB64, pubKeyB64);

        Key.fromBase64(parsedConfig.privateKeyBase64);
        Key.fromBase64(parsedConfig.serverPublicKey);

        saveToCache(sp, parsedConfig);

        Log.d(LOG_TAG, "[WARP] Registered with Cloudflare: v4=" + parsedConfig.v4Address
                + " endpoint=" + parsedConfig.endpoint);

        return parsedConfig;
    }

    private static WarpRegistrationData parseCloudflareResponse(String jsonString, String privateKey, String publicKey) throws Exception {
        JSONObject rootObject = new JSONObject(jsonString);
        JSONObject configObject = rootObject.getJSONObject("config");

        JSONArray peersArray = configObject.getJSONArray("peers");
        JSONObject primaryPeer = peersArray.getJSONObject(0);
        String serverPubKey = primaryPeer.getString("public_key");

        JSONObject endpointObj = primaryPeer.getJSONObject("endpoint");
        String connectionHost = endpointObj.getString("host");

        JSONObject interfaceObj = configObject.getJSONObject("interface");
        JSONObject addressesObj = interfaceObj.getJSONObject("addresses");
        String ipv4 = addressesObj.getString("v4");
        String ipv6 = addressesObj.getString("v6");

        String cid = configObject.optString("client_id", "");

        WarpRegistrationData result = new WarpRegistrationData();
        result.privateKeyBase64 = privateKey;
        result.publicKeyBase64 = publicKey;
        result.serverPublicKey = serverPubKey;
        result.endpoint = connectionHost;
        result.v4Address = ipv4;
        result.v6Address = ipv6;
        result.clientId = cid;

        return result;
    }

    private static String fetchCurrentUtcTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }
}