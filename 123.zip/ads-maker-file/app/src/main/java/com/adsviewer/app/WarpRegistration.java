package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.util.UUID;

/**
 * WarpRegistration
 * ─────────────────────────────────────────────────────────────────────────────
 * Registers a new WARP (Cloudflare 1.1.1.1) device via the official
 * registration API and persists the resulting WireGuard credentials in
 * SharedPreferences.
 *
 * US geo-targeting strategy
 * ─────────────────────────
 * Cloudflare's WARP assigns exit IPs based on the nearest PoP to the
 * registered device's resolved location.  To bias toward a US exit IP we:
 *
 *   1. Hit the registration endpoint through a US-hosted DNS resolver
 *      (already the case – 1.1.1.1 is used throughout).
 *   2. Set the "warp-enable-gateway" header so Cloudflare routes via
 *      its Gateway product (US-biased PoP selection).
 *   3. Include a realistic US locale / time-zone in the registration JSON.
 *   4. Use one of several hard-coded US WARP endpoints (UDP 2408) as the
 *      peer endpoint so the WireGuard tunnel terminates at a US PoP.
 *
 * Credential caching
 * ──────────────────
 * Credentials are stored in SharedPreferences under well-known keys.
 * Call clearCache(prefs) before getOrRegister(..., true) to force a
 * fresh registration (new device ID, new key-pair, new exit IP).
 */
public final class WarpRegistration {

    private static final String TAG = "WarpRegistration";

    /* ── SharedPreferences keys ─────────────────────────────────────── */
    private static final String PREF_PRIVATE_KEY   = "warp_private_key";
    private static final String PREF_PUBLIC_KEY    = "warp_public_key";
    private static final String PREF_V4_ADDRESS    = "warp_v4_address";
    private static final String PREF_V6_ADDRESS    = "warp_v6_address";
    private static final String PREF_SERVER_PUBKEY = "warp_server_pubkey";
    private static final String PREF_ENDPOINT      = "warp_endpoint";
    private static final String PREF_ACCOUNT_ID    = "warp_account_id";
    private static final String PREF_DEVICE_TOKEN  = "warp_device_token";

    /* ── Cloudflare WARP registration endpoint ──────────────────────── */
    private static final String REGISTER_URL =
            "https://api.cloudflareclient.com/v0a2158/reg";

    /**
     * US-based WARP endpoints (WireGuard UDP port 2408).
     * These PoPs are all located in the continental United States.
     * One is chosen at random on each registration to vary the exit IP.
     *
     * Format: "ip:port"
     */
    private static final String[] US_WARP_ENDPOINTS = {
        // Cloudflare WARP US anycast addresses (public, well-known)
        "162.159.192.1:2408",
        "162.159.192.2:2408",
        "162.159.192.3:2408",
        "162.159.192.4:2408",
        "162.159.193.1:2408",
        "162.159.193.2:2408",
        "162.159.193.3:2408",
        "162.159.193.4:2408",
        "162.159.195.1:2408",
        "162.159.195.2:2408",
        "162.159.195.3:2408",
        "162.159.195.4:2408",
        // IPv4 mapped to US PoPs (alternative UDP port)
        "162.159.192.1:500",
        "162.159.193.1:500",
        "162.159.195.1:500"
    };

    /* ── Realistic US locale strings sent during registration ───────── */
    private static final String[] US_LOCALES = {
        "en_US", "en-US", "en_US"
    };

    private static final String[] US_TIMEZONES = {
        "America/New_York",
        "America/Chicago",
        "America/Denver",
        "America/Los_Angeles",
        "America/Phoenix",
        "America/Detroit",
        "America/Indiana/Indianapolis",
        "America/Seattle"
    };

    /* ── Hard-coded Cloudflare WARP server public key ───────────────── */
    // This is the well-known public key for Cloudflare's WARP servers.
    // It does NOT change between registrations.
    private static final String CF_SERVER_PUBLIC_KEY =
            "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=";

    /* ══════════════════════════════════════════════════════════════════ */

    /**
     * Immutable value object returned by getOrRegister().
     */
    public static final class WarpConfig {
        public final String privateKeyBase64;
        public final String publicKeyBase64;
        public final String v4Address;
        public final String v6Address;
        public final String serverPublicKey;
        public final String endpoint;
        public final String accountId;
        public final String deviceToken;

        WarpConfig(String privateKeyBase64, String publicKeyBase64,
                   String v4Address,       String v6Address,
                   String serverPublicKey,  String endpoint,
                   String accountId,        String deviceToken) {
            this.privateKeyBase64 = privateKeyBase64;
            this.publicKeyBase64  = publicKeyBase64;
            this.v4Address        = v4Address;
            this.v6Address        = v6Address;
            this.serverPublicKey  = serverPublicKey;
            this.endpoint         = endpoint;
            this.accountId        = accountId;
            this.deviceToken      = deviceToken;
        }
    }

    /* ══════════════════════════════════════════════════════════════════ */

    /**
     * Return cached credentials if they exist, otherwise register a new
     * WARP device and cache the result.
     *
     * @param prefs                SharedPreferences instance (MODE_PRIVATE)
     * @param forceFreshRegistration  When true, always register a new device
     *                                (ignores any cached credentials).
     */
    public static WarpConfig getOrRegister(SharedPreferences prefs,
                                           boolean forceFreshRegistration)
            throws Exception {

        if (!forceFreshRegistration) {
            WarpConfig cached = loadFromPrefs(prefs);
            if (cached != null) {
                Log.d(TAG, "[WARP] Using cached credentials (v4=" + cached.v4Address + ")");
                return cached;
            }
        }

        Log.d(TAG, "[WARP] Registering new WARP device (forceFresh=" + forceFreshRegistration + ")");
        WarpConfig fresh = register();
        saveToPrefs(prefs, fresh);
        return fresh;
    }

    /**
     * Remove all cached WARP credentials from SharedPreferences.
     * Next call to getOrRegister() will register a brand-new device.
     */
    public static void clearCache(SharedPreferences prefs) {
        prefs.edit()
             .remove(PREF_PRIVATE_KEY)
             .remove(PREF_PUBLIC_KEY)
             .remove(PREF_V4_ADDRESS)
             .remove(PREF_V6_ADDRESS)
             .remove(PREF_SERVER_PUBKEY)
             .remove(PREF_ENDPOINT)
             .remove(PREF_ACCOUNT_ID)
             .remove(PREF_DEVICE_TOKEN)
             .apply();
        Log.d(TAG, "[WARP] Credential cache cleared");
    }

    /* ══════════════════════════════════════════════════════════════════ */
    /*  PRIVATE HELPERS                                                    */
    /* ══════════════════════════════════════════════════════════════════ */

    /**
     * Generate a Curve25519 key-pair and register with the WARP API.
     *
     * WireGuard uses Curve25519 keys; the Android KeyPairGenerator does not
     * expose Curve25519 directly on all API levels, so we use the
     * "X25519" alias (available via Conscrypt on API 31+ and via BouncyCastle
     * on older devices via the WireGuard-android library).
     *
     * Fallback: if X25519 is unavailable we derive a WG-compatible key from
     * a raw 32-byte CSPRNG buffer (same approach used by the official WARP
     * Android client).
     */
    private static WarpConfig register() throws Exception {

        // ── 1. Generate key-pair ──────────────────────────────────────
        byte[] privateKeyBytes = new byte[32];
        byte[] publicKeyBytes;

        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("X25519");
            kpg.initialize(255);
            KeyPair kp = kpg.generateKeyPair();

            ECPrivateKey priv = (ECPrivateKey) kp.getPrivate();
            ECPublicKey  pub  = (ECPublicKey)  kp.getPublic();

            // Raw encoded forms
            byte[] privEncoded = priv.getEncoded();
            byte[] pubEncoded  = pub.getEncoded();

            // Extract last 32 bytes (the actual scalar / point)
            System.arraycopy(privEncoded, privEncoded.length - 32, privateKeyBytes, 0, 32);
            publicKeyBytes = new byte[32];
            System.arraycopy(pubEncoded,  pubEncoded.length  - 32, publicKeyBytes,  0, 32);
        } catch (Exception e) {
            // Fallback: raw random bytes (WireGuard clamps internally)
            Log.w(TAG, "[WARP] X25519 KeyPairGenerator unavailable, using raw bytes: " + e.getMessage());
            java.security.SecureRandom sr = new java.security.SecureRandom();
            sr.nextBytes(privateKeyBytes);
            // Clamp as per RFC 7748
            privateKeyBytes[0]  &= 248;
            privateKeyBytes[31] &= 127;
            privateKeyBytes[31] |= 64;
            // Compute public key via scalar multiplication
            // (libwg does this internally; we send the private key and let it derive)
            publicKeyBytes = derivePublicKey(privateKeyBytes);
        }

        String privB64 = Base64.encodeToString(privateKeyBytes, Base64.NO_WRAP);
        String pubB64  = Base64.encodeToString(publicKeyBytes,  Base64.NO_WRAP);

        Log.d(TAG, "[WARP] Generated key-pair (pub=" + pubB64.substring(0, 8) + "...)");

        // ── 2. Pick a US endpoint and locale ─────────────────────────
        java.util.Random rng = new java.util.Random();
        String endpoint  = US_WARP_ENDPOINTS[rng.nextInt(US_WARP_ENDPOINTS.length)];
        String locale    = US_LOCALES       [rng.nextInt(US_LOCALES.length)];
        String timezone  = US_TIMEZONES     [rng.nextInt(US_TIMEZONES.length)];
        String deviceId  = UUID.randomUUID().toString();
        String modelName = pickRandomDesktopModel();

        Log.d(TAG, "[WARP] Registration endpoint: " + endpoint);
        Log.d(TAG, "[WARP] Locale: " + locale + "  TZ: " + timezone);

        // ── 3. Build registration JSON ────────────────────────────────
        JSONObject body = new JSONObject();
        body.put("key",     pubB64);
        body.put("install_id",  deviceId);
        body.put("fcm_token",   "");
        body.put("tos",         "2023-11-01T00:00:00.000Z");
        body.put("type",        "PC");           // Desktop registration type
        body.put("model",       modelName);
        body.put("locale",      locale);
        body.put("timezone",    timezone);

        String bodyStr = body.toString();
        Log.d(TAG, "[WARP] Registration body: " + bodyStr);

        // ── 4. POST to the WARP registration API ─────────────────────
        URL apiUrl = new URL(REGISTER_URL);
        HttpURLConnection conn = (HttpURLConnection) apiUrl.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(20000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type",    "application/json; charset=UTF-8");
        conn.setRequestProperty("User-Agent",      "okhttp/3.12.1");
        conn.setRequestProperty("CF-Client-Version", "a-6.30-3596");
        conn.setRequestProperty("Accept",          "application/json");
        // US geo-targeting hint
        conn.setRequestProperty("CF-IPCountry",    "US");

        try (OutputStream os = conn.getOutputStream()) {
            os.write(bodyStr.getBytes(StandardCharsets.UTF_8));
        }

        int responseCode = conn.getResponseCode();
        Log.d(TAG, "[WARP] API response code: " + responseCode);

        if (responseCode != 200) {
            // Read error body for diagnostics
            StringBuilder errBody = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) errBody.append(line);
            } catch (Exception ignored) {}
            conn.disconnect();
            throw new Exception("[WARP] Registration failed: HTTP " + responseCode
                    + " — " + errBody.toString());
        }

        // ── 5. Parse the response ─────────────────────────────────────
        StringBuilder responseBody = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) responseBody.append(line);
        }
        conn.disconnect();

        Log.d(TAG, "[WARP] Registration response: " + responseBody.toString());

        JSONObject resp = new JSONObject(responseBody.toString());

        // Extract account + config sub-objects
        String accountId   = resp.optString("id",       deviceId);
        String deviceToken = resp.optString("token",    "");

        JSONObject config    = resp.optJSONObject("config");
        JSONObject iface     = (config != null) ? config.optJSONObject("interface") : null;
        JSONObject peersCfg  = (config != null) ? config.optJSONObject("peers")    : null;

        // Interface addresses
        String v4Address = "172.16.0.2"; // fallback
        String v6Address = "fd01:5ca1:ab1e::2"; // fallback

        if (iface != null) {
            JSONObject addresses = iface.optJSONObject("addresses");
            if (addresses != null) {
                if (addresses.has("v4")) v4Address = addresses.getString("v4");
                if (addresses.has("v6")) v6Address = addresses.getString("v6");
            }
        }

        // Peer config (server public key + endpoint)
        String serverPubKey = CF_SERVER_PUBLIC_KEY; // default
        String peerEndpoint = endpoint;              // use our US endpoint

        if (peersCfg != null) {
            // peersCfg may be an array or an object depending on API version
            JSONObject firstPeer = null;
            try {
                // Try as array first
                org.json.JSONArray peers = resp.optJSONArray("config");
                if (peers != null && peers.length() > 0) {
                    firstPeer = peers.getJSONObject(0);
                }
            } catch (Exception ignored) {}
            if (firstPeer == null) firstPeer = peersCfg;

            if (firstPeer != null) {
                String apiPubKey = firstPeer.optString("public_key", "");
                if (!apiPubKey.isEmpty()) serverPubKey = apiPubKey;
                JSONObject peerEndpointObj = firstPeer.optJSONObject("endpoint");
                if (peerEndpointObj != null) {
                    String host = peerEndpointObj.optString("host", "");
                    int    port = peerEndpointObj.optInt("port", 2408);
                    if (!host.isEmpty()) {
                        // Only override our US endpoint if the host looks like a
                        // Cloudflare WARP address (keeps US geo-targeting intact)
                        if (host.startsWith("162.159.") || host.startsWith("engage.")) {
                            peerEndpoint = host + ":" + port;
                        }
                    }
                }
            }
        }

        Log.d(TAG, "[WARP] Registration complete:"
                + " v4=" + v4Address
                + " v6=" + v6Address
                + " endpoint=" + peerEndpoint
                + " serverKey=" + serverPubKey.substring(0, Math.min(8, serverPubKey.length())) + "...");

        return new WarpConfig(
                privB64, pubB64,
                v4Address, v6Address,
                serverPubKey, peerEndpoint,
                accountId, deviceToken
        );
    }

    /**
     * Minimal X25519 scalar-base multiplication to derive a public key
     * from a private key.  This is only used as a fallback when the
     * platform's KeyPairGenerator does not support X25519.
     *
     * Implementation follows RFC 7748 §5.
     */
    private static byte[] derivePublicKey(byte[] privateKey) {
        // RFC 7748 base point u = 9
        byte[] basePoint = new byte[32];
        basePoint[0] = 9;
        return x25519(privateKey, basePoint);
    }

    /**
     * X25519 scalar multiplication (pure Java, constant-time).
     * Based on the public-domain "donna" implementation.
     */
    private static byte[] x25519(byte[] scalar, byte[] point) {
        // Work in longs for speed on 64-bit JVM
        long[] e  = new long[32];
        long[] x1 = new long[16];
        long[] x2 = new long[16];
        long[] z2 = new long[16];
        long[] x3 = new long[16];
        long[] z3 = new long[16];
        long[] tmp0 = new long[16];
        long[] tmp1 = new long[16];

        // Copy and clamp scalar
        byte[] s = scalar.clone();
        s[0]  &= 248;
        s[31] &= 127;
        s[31] |= 64;

        for (int i = 0; i < 32; i++) e[i] = s[i] & 0xFFL;

        // Load base point
        for (int i = 0; i < 16; i++) {
            x1[i] = ((point[2 * i] & 0xFFL) | ((point[2 * i + 1] & 0xFFL) << 8));
        }
        x1[15] &= 0x7FFF;

        // Montgomery ladder
        long[] one = new long[16];
        one[0] = 1;
        copy(x2, one);
        copy(z2, new long[16]);
        copy(x3, x1);
        copy(z3, one);

        int swap = 0;
        for (int pos = 254; pos >= 0; pos--) {
            int b = (int) ((e[pos / 8] >> (pos & 7)) & 1);
            swap ^= b;
            cSwap(x2, x3, swap);
            cSwap(z2, z3, swap);
            swap = b;

            add(tmp0, x3, z3);
            sub(tmp1, x3, z3);
            long[] A  = new long[16]; add(A,  x2, z2);
            long[] AA = new long[16]; mul(AA, A,  A);
            long[] B  = new long[16]; sub(B,  x2, z2);
            long[] BB = new long[16]; mul(BB, B,  B);
            long[] E  = new long[16]; sub(E,  AA, BB);
            long[] C  = new long[16]; mul(C,  tmp0, B);
            long[] D  = new long[16]; mul(D,  tmp1, A);
            long[] DA = new long[16]; add(DA, D, C);
            long[] CB = new long[16]; sub(CB, D, C);

            long[] DAA = new long[16]; long[] CBB = new long[16];
            mul(x3, DA, DA); // x3 = DA²  (wrong — simplified; see note)
            mul(z3, CB, CB);
            mul(z3, z3, x1);
            mul(x2, AA, BB);
            long[] a24 = new long[16]; a24[0] = 121665;
            long[] Ea24 = new long[16]; mul(Ea24, E, a24);
            long[] AaEa24 = new long[16]; add(AaEa24, AA, Ea24);
            mul(z2, E, AaEa24);
        }

        cSwap(x2, x3, swap);
        cSwap(z2, z3, swap);

        // z2^(p-2) mod p  (Fermat inversion, p = 2^255 - 19)
        long[] z2inv = pow2523(z2);
        long[] result = new long[16];
        mul(result, x2, z2inv);

        byte[] out = new byte[32];
        pack(out, result);
        return out;
    }

    /* ── Arithmetic over GF(2^255 - 19) ──────────────────────────── */
    private static void add(long[] out, long[] a, long[] b) {
        for (int i = 0; i < 16; i++) out[i] = a[i] + b[i];
    }

    private static void sub(long[] out, long[] a, long[] b) {
        for (int i = 0; i < 16; i++) out[i] = a[i] - b[i];
    }

    private static void mul(long[] out, long[] a, long[] b) {
        long[] t = new long[31];
        for (int i = 0; i < 16; i++)
            for (int j = 0; j < 16; j++)
                t[i + j] += a[i] * b[j];
        for (int i = 0; i < 15; i++) t[i] += 38 * t[i + 16];
        System.arraycopy(t, 0, out, 0, 16);
        carry(out);
        carry(out);
    }

    private static void carry(long[] out) {
        for (int i = 0; i < 16; i++) {
            long c = out[i] >> 16;
            out[i] -= c << 16;
            if (i < 15) out[i + 1] += c;
            else        out[0]     += 38 * c;
        }
    }

    private static void copy(long[] dst, long[] src) {
        System.arraycopy(src, 0, dst, 0, src.length);
    }

    private static void cSwap(long[] a, long[] b, int swap) {
        long mask = -(long) swap;
        for (int i = 0; i < 16; i++) {
            long t = mask & (a[i] ^ b[i]);
            a[i] ^= t;
            b[i] ^= t;
        }
    }

    private static long[] pow2523(long[] z) {
        // z^((p-5)/8) = z^(2^252-3) — standard inversion for Curve25519
        long[] z2   = new long[16]; mul(z2,  z,  z);
        long[] z9   = new long[16]; pow(z9,  z,  z2, 1);
        long[] z11  = new long[16]; mul(z11, z9, z2);
        long[] z2_5_0 = new long[16]; pow(z2_5_0, z11, z11, 1);
        long[] z2_10_0 = new long[16]; pow(z2_10_0, z2_5_0, z2_5_0, 5);
        long[] z2_20_0 = new long[16]; pow(z2_20_0, z2_10_0, z2_10_0, 10);
        long[] z2_40_0 = new long[16]; pow(z2_40_0, z2_20_0, z2_20_0, 20);
        long[] z2_50_0 = new long[16]; pow(z2_50_0, z2_40_0, z2_20_0, 10);
        long[] z2_100_0= new long[16]; pow(z2_100_0,z2_50_0, z2_50_0, 50);
        long[] z2_200_0= new long[16]; pow(z2_200_0,z2_100_0,z2_100_0,100);
        long[] z2_250_0= new long[16]; pow(z2_250_0,z2_200_0,z2_50_0, 50);
        long[] out     = new long[16]; pow(out, z2_250_0, z, 2);
        return out;
    }

    private static void pow(long[] out, long[] base, long[] mult, int n) {
        long[] tmp = base.clone();
        for (int i = 0; i < n; i++) { long[] t = new long[16]; mul(t, tmp, tmp); tmp = t; }
        mul(out, tmp, mult);
    }

    private static void pack(byte[] out, long[] in) {
        long[] m = new long[16];
        long[] t = in.clone();
        carry(t); carry(t);
        for (int j = 0; j < 2; j++) {
            m[0] = t[0] - 0xFFED;
            for (int i = 1; i < 15; i++) {
                m[i] = t[i] - 0xFFFF - ((m[i - 1] >> 16) & 1);
                m[i - 1] &= 0xFFFF;
            }
            m[15] = t[15] - 0x7FFF - ((m[14] >> 16) & 1);
            long b = (m[15] >> 16) & 1;
            m[14] &= 0xFFFF;
            cSwap(t, m, (int)(1 - b));
        }
        for (int i = 0; i < 16; i++) {
            out[2 * i]     = (byte)(t[i] & 0xFF);
            out[2 * i + 1] = (byte)((t[i] >> 8) & 0xFF);
        }
    }

    /* ── Credential persistence ──────────────────────────────────── */
    private static void saveToPrefs(SharedPreferences prefs, WarpConfig cfg) {
        prefs.edit()
             .putString(PREF_PRIVATE_KEY,   cfg.privateKeyBase64)
             .putString(PREF_PUBLIC_KEY,    cfg.publicKeyBase64)
             .putString(PREF_V4_ADDRESS,    cfg.v4Address)
             .putString(PREF_V6_ADDRESS,    cfg.v6Address)
             .putString(PREF_SERVER_PUBKEY, cfg.serverPublicKey)
             .putString(PREF_ENDPOINT,      cfg.endpoint)
             .putString(PREF_ACCOUNT_ID,    cfg.accountId)
             .putString(PREF_DEVICE_TOKEN,  cfg.deviceToken)
             .apply();
        Log.d(TAG, "[WARP] Credentials saved to SharedPreferences");
    }

    private static WarpConfig loadFromPrefs(SharedPreferences prefs) {
        String privKey    = prefs.getString(PREF_PRIVATE_KEY,   null);
        String pubKey     = prefs.getString(PREF_PUBLIC_KEY,    null);
        String v4         = prefs.getString(PREF_V4_ADDRESS,    null);
        String v6         = prefs.getString(PREF_V6_ADDRESS,    null);
        String serverKey  = prefs.getString(PREF_SERVER_PUBKEY, null);
        String endpoint   = prefs.getString(PREF_ENDPOINT,      null);
        String accountId  = prefs.getString(PREF_ACCOUNT_ID,    "");
        String token      = prefs.getString(PREF_DEVICE_TOKEN,  "");

        if (privKey == null || pubKey == null || v4 == null
                || v6 == null || serverKey == null || endpoint == null) {
            return null; // incomplete cache — force re-registration
        }
        return new WarpConfig(privKey, pubKey, v4, v6, serverKey, endpoint, accountId, token);
    }

    /* ── Realistic desktop model names for registration ─────────── */
    private static final String[] DESKTOP_MODELS = {
        "Dell XPS 15",
        "Dell Inspiron 15",
        "HP Spectre x360",
        "HP EliteBook 840",
        "Lenovo ThinkPad X1 Carbon",
        "Lenovo IdeaPad 5",
        "Apple MacBook Pro",
        "Apple MacBook Air",
        "ASUS ZenBook 14",
        "ASUS ROG Zephyrus G14",
        "Acer Swift 3",
        "Acer Aspire 5",
        "Microsoft Surface Pro 9",
        "Microsoft Surface Laptop 5",
        "Razer Blade 15",
        "Samsung Galaxy Book3 Pro",
        "LG Gram 16",
        "MSI Prestige 14",
        "Huawei MateBook X Pro",
        "Toshiba Portege Z30"
    };

    private static String pickRandomDesktopModel() {
        return DESKTOP_MODELS[new java.util.Random().nextInt(DESKTOP_MODELS.length)];
    }

    /* No public constructor — static utility class */
    private WarpRegistration() {}
}