package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.Route;

/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║              CLOUDFLARE WARP DEVICE REGISTRATION MANAGER                   ║
 * ║                     God-Level Implementation v3.0                          ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║                                                                            ║
 * ║  ROOT CAUSE OF INDIA CONNECTIONS:                                          ║
 * ║  ─────────────────────────────────                                         ║
 * ║  Cloudflare assigns WARP server endpoints based on the IP address          ║
 * ║  that hits their registration API. When your proxy (gate.kookeey.info)     ║
 * ║  exits through an Indian IP, Cloudflare responds with an Indian            ║
 * ║  WARP server (Ranchi/Mumbai region).                                       ║
 * ║                                                                            ║
 * ║  SOLUTION STRATEGIES (tried in priority order):                            ║
 * ║  ─────────────────────────────────────────────                             ║
 * ║  1. PRIMARY:   Proxy with country-targeted session string                  ║
 * ║  2. FALLBACK:  Rotate through multiple proxy configs                       ║
 * ║  3. LAST:      Direct connection (no proxy)                                ║
 * ║                                                                            ║
 * ║  HOW TO FIX YOUR SPECIFIC CASE:                                            ║
 * ║  ──────────────────────────────                                            ║
 * ║  Change PROXY_USER to include country targeting:                           ║
 * ║  • "6374376-f060870b-country-us" → US exit node                           ║
 * ║  • "6374376-f060870b-country-de" → Germany exit node                      ║
 * ║  • "6374376-f060870b-country-nl" → Netherlands exit node                  ║
 * ║  (Exact format depends on your proxy provider's documentation)             ║
 * ║                                                                            ║
 * ║  Uses public consumer endpoint (same as wgcf and official 1.1.1.1 app):   ║
 * ║    POST https://api.cloudflareclient.com/v0a2405/reg                       ║
 * ║                                                                            ║
 * ║  Thread-safe: Concurrent calls serialized via REGISTRATION_LOCK            ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */
public class WarpRegistration {

    private static final String TAG = "AdsViewer/WARP-REG";

    // ──────────────────────────────────────────────────────────────────────────
    // CLOUDFLARE API CONSTANTS
    // ──────────────────────────────────────────────────────────────────────────

    private static final String REG_URL            = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String USER_AGENT         = "okhttp/3.12.1";
    private static final String CF_CLIENT_VERSION  = "a-6.30-3596";

    // ──────────────────────────────────────────────────────────────────────────
    // PROXY STRATEGY CONFIGURATION
    //
    // IMPORTANT: This is where you control geographic targeting.
    //
    // WHY YOU GET INDIA:
    //   Your proxy exits through an Indian IP → Cloudflare sees India → assigns
    //   Indian WARP server. Fix = force non-Indian exit node on the proxy side.
    //
    // HOW TO TARGET A SPECIFIC COUNTRY (Kookeey format examples):
    //   Format varies by provider. Common patterns:
    //   username-country-us         → United States
    //   username-country-de         → Germany
    //   username-country-gb         → United Kingdom
    //   username-country-nl         → Netherlands
    //   username-country-sg         → Singapore
    //   username-session-abc123     → sticky session (same IP repeated)
    //   username-rotate             → rotate on each request
    //
    //   Check your provider's dashboard for the exact format.
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Proxy configuration entry. Immutable value object.
     *
     * <p>The {@code username} field is where you inject country/session targeting.
     * The proxy network uses this field to select the exit node country.
     *
     * <p>Example targeting (verify exact format with your proxy provider):
     * <pre>
     *   // Force US exit node:
     *   username = "6374376-f060870b-country-us"
     *
     *   // Force Germany exit node:
     *   username = "6374376-f060870b-country-de"
     *
     *   // Rotate on every request:
     *   username = "6374376-f060870b-rotate"
     * </pre>
     */
    private static final class ProxyConfig {
        final String  host;
        final int     port;
        final String  username;   // ← inject country targeting here
        final String  password;
        final String  description; // human-readable label for logs

        ProxyConfig(String host, int port, String username,
                String password, String description) {
            this.host        = host;
            this.port        = port;
            this.username    = username;
            this.password    = password;
            this.description = description;
        }

        @Override
        public String toString() {
            return description + " [" + host + ":" + port + "]";
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // PROXY POOL
    //
    // Add/remove entries as needed. They are tried IN ORDER.
    // First success wins. If ALL fail, falls back to direct connection.
    //
    // ★ PRIMARY FIX: Change the username below to include your target country.
    //   e.g. "6374376-f060870b-country-us" for United States exit.
    //
    // ★ If your provider uses a different port per country, change the port too.
    //   Kookeey typically uses the same port with username-based routing.
    // ──────────────────────────────────────────────────────────────────────────
    private static final List<ProxyConfig> PROXY_POOL = Collections.unmodifiableList(
            Arrays.asList(

                    // ── SLOT 1: Primary proxy — US-targeted exit ──────────────────────────
                    // ★ ACTION REQUIRED: Replace username with country-targeted version
                    //   Current: connects to India (proxy assigns Indian exit IP)
                    //   Fix:     append country code your provider supports
                    //   Example: "6374376-f060870b-country-us"
                    new ProxyConfig(
                            "gate.kookeey.info",
                            1000,
                            "6374376-f060870b-country-us",   // ← CHANGE THIS
                            "14bd4e31-global-36143056-5m",
                            "Kookeey-US"
                    ),

                    // ── SLOT 2: Same proxy, Germany fallback ──────────────────────────────
                    new ProxyConfig(
                            "gate.kookeey.info",
                            1000,
                            "6374376-f060870b-country-de",   // Germany exit
                            "14bd4e31-global-36143056-5m",
                            "Kookeey-DE"
                    ),

                    // ── SLOT 3: Same proxy, Netherlands fallback ──────────────────────────
                    new ProxyConfig(
                            "gate.kookeey.info",
                            1000,
                            "6374376-f060870b-country-nl",   // Netherlands exit
                            "14bd4e31-global-36143056-5m",
                            "Kookeey-NL"
                    )

                    // ── Add more proxy providers here if needed ───────────────────────────
                    // new ProxyConfig("another-proxy.com", 8080, "user", "pass", "Backup-US"),
            )
    );

    // ──────────────────────────────────────────────────────────────────────────
    // DIRECT CONNECTION FALLBACK
    //
    // If ALL proxies fail, the registration attempt uses your real IP.
    // Set to false if you want hard failure when proxies are unavailable
    // (e.g., you must never expose your real IP to Cloudflare's API).
    // ──────────────────────────────────────────────────────────────────────────
    private static final boolean ALLOW_DIRECT_FALLBACK = true;

    // ──────────────────────────────────────────────────────────────────────────
    // NETWORK TIMEOUTS
    // ──────────────────────────────────────────────────────────────────────────
    private static final int CONNECT_TIMEOUT_SECONDS = 15;
    private static final int READ_TIMEOUT_SECONDS    = 20;

    // ──────────────────────────────────────────────────────────────────────────
    // SHARED PREFERENCES KEYS
    // ──────────────────────────────────────────────────────────────────────────
    private static final String K_PRIV      = "warp_priv";
    private static final String K_PUB       = "warp_pub";
    private static final String K_SRV_PUB   = "warp_srv_pub";
    private static final String K_ENDPOINT  = "warp_endpoint";
    private static final String K_V4        = "warp_v4";
    private static final String K_V6        = "warp_v6";
    private static final String K_CLIENT_ID = "warp_client_id";

    // ──────────────────────────────────────────────────────────────────────────
    // JSON FIELD NAME CONSTANTS
    // ──────────────────────────────────────────────────────────────────────────
    private static final String JSON_KEY        = "key";
    private static final String JSON_INSTALL_ID = "install_id";
    private static final String JSON_FCM_TOKEN  = "fcm_token";
    private static final String JSON_TOS        = "tos";
    private static final String JSON_MODEL      = "model";
    private static final String JSON_TYPE       = "type";
    private static final String JSON_LOCALE     = "locale";
    private static final String JSON_CONFIG     = "config";
    private static final String JSON_PEERS      = "peers";
    private static final String JSON_PUBLIC_KEY = "public_key";
    private static final String JSON_ENDPOINT   = "endpoint";
    private static final String JSON_HOST       = "host";
    private static final String JSON_INTERFACE  = "interface";
    private static final String JSON_ADDRESSES  = "addresses";
    private static final String JSON_V4         = "v4";
    private static final String JSON_V6         = "v6";
    private static final String JSON_CLIENT_ID  = "client_id";

    // ──────────────────────────────────────────────────────────────────────────
    // INTERNAL STATE
    // ──────────────────────────────────────────────────────────────────────────

    /** Immutable MediaType — parsing is expensive; reuse across calls. */
    private static final MediaType JSON_MEDIA_TYPE =
            MediaType.parse("application/json; charset=utf-8");

    /**
     * Tracks the index of the last successfully used proxy so subsequent calls
     * prefer the same working proxy instead of always starting from index 0.
     * Value -1 means "no successful proxy recorded yet".
     */
    private static final AtomicInteger lastSuccessfulProxyIndex = new AtomicInteger(-1);

    /** Serializes all registration operations to prevent race conditions. */
    private static final Object REGISTRATION_LOCK = new Object();

    // ──────────────────────────────────────────────────────────────────────────
    // PUBLIC API
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Immutable value object containing the complete WARP device identity.
     * All fields are populated after successful registration.
     */
    public static final class WarpConfig {
        public String privateKeyBase64;   // Our WireGuard private key (base64)
        public String publicKeyBase64;    // Our WireGuard public key (base64)
        public String serverPublicKey;    // Cloudflare's WireGuard pubkey (base64)
        public String endpoint;           // WireGuard server host:port
        public String v4Address;          // Assigned IPv4 (172.16.0.x)
        public String v6Address;          // Assigned IPv6 (2606:...)
        public String clientId;           // Base64 client_id → WireGuard 'reserved' bytes
    }

    /**
     * Returns a valid WARP configuration, loading from cache or registering fresh.
     *
     * <p><b>Thread safety:</b> Safe to call from multiple background threads simultaneously.
     * Concurrent calls are serialized internally — only one network request fires at a time.
     *
     * <p><b>Geographic targeting:</b> Configure {@code PROXY_POOL} entries with country-specific
     * usernames to control which Cloudflare WARP region is assigned. Cloudflare assigns the
     * nearest WARP server based on the IP that hits the registration API.
     *
     * @param prefs                  SharedPreferences for caching (must not be null)
     * @param forceFreshRegistration If true, ignores cache and forces a new registration
     * @return Complete WarpConfig with all WARP identity fields populated
     * @throws IllegalArgumentException if {@code prefs} is null
     * @throws IOException              on network failure (all proxies exhausted + no direct)
     * @throws JSONException            on malformed API response
     * @throws IllegalStateException    on invalid cryptographic key material
     */
    public static WarpConfig getOrRegister(
            SharedPreferences prefs,
            boolean forceFreshRegistration) throws Exception {

        if (prefs == null) {
            throw new IllegalArgumentException("SharedPreferences cannot be null");
        }

        synchronized (REGISTRATION_LOCK) {
            if (!forceFreshRegistration) {
                WarpConfig cached = loadCachedConfig(prefs);
                if (cached != null) {
                    Log.d(TAG, "✓ Reusing cached WARP config | v4=" + cached.v4Address
                            + " endpoint=" + cached.endpoint);
                    return cached;
                }
                Log.d(TAG, "Cache miss or corrupted — performing fresh registration");
            } else {
                Log.d(TAG, "Forced fresh registration requested");
            }

            return performRegistrationWithFallback(prefs);
        }
    }

    /**
     * Clears all cached WARP configuration from SharedPreferences.
     * The next call to {@link #getOrRegister} will trigger a fresh registration.
     *
     * <p>Safe to call even if cache is empty or {@code prefs} is null.
     *
     * @param prefs SharedPreferences instance (null is handled gracefully)
     */
    public static void clearCache(SharedPreferences prefs) {
        if (prefs == null) {
            Log.w(TAG, "clearCache called with null prefs — no-op");
            return;
        }
        prefs.edit()
                .remove(K_PRIV)
                .remove(K_PUB)
                .remove(K_SRV_PUB)
                .remove(K_ENDPOINT)
                .remove(K_V4)
                .remove(K_V6)
                .remove(K_CLIENT_ID)
                .apply();
        Log.d(TAG, "WARP cache cleared");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // REGISTRATION ORCHESTRATION
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Orchestrates registration attempts across the proxy pool with smart ordering.
     *
     * <p>Strategy:
     * <ol>
     *   <li>Try the last known-good proxy first (avoids redundant retries)</li>
     *   <li>Iterate remaining proxies in pool order</li>
     *   <li>Fall back to direct connection if {@link #ALLOW_DIRECT_FALLBACK} is true</li>
     *   <li>Throw {@link IOException} if everything fails</li>
     * </ol>
     */
    private static WarpConfig performRegistrationWithFallback(SharedPreferences prefs)
            throws Exception {

        // Build attempt order: last-successful first, then round-robin the rest
        int poolSize = PROXY_POOL.size();
        int[] attemptOrder = buildAttemptOrder(poolSize);

        StringBuilder failureLog = new StringBuilder("WARP registration attempts:\n");
        int attemptNumber = 1;

        // ── Phase 1: Try proxies in smart order ───────────────────────────────
        for (int idx : attemptOrder) {
            ProxyConfig proxyConfig = PROXY_POOL.get(idx);
            Log.d(TAG, "Attempt " + attemptNumber + "/" + poolSize
                    + " → proxy: " + proxyConfig);

            try {
                WarpConfig result = performRegistration(prefs, proxyConfig);
                lastSuccessfulProxyIndex.set(idx);
                Log.i(TAG, "✓ Registration successful via " + proxyConfig);
                return result;

            } catch (Exception e) {
                String failure = "  [" + attemptNumber + "] " + proxyConfig
                        + " FAILED: " + e.getClass().getSimpleName()
                        + " — " + e.getMessage();
                failureLog.append(failure).append("\n");
                Log.w(TAG, failure);
                attemptNumber++;
                // Continue to next proxy
            }
        }

        // ── Phase 2: Direct connection fallback ───────────────────────────────
        if (ALLOW_DIRECT_FALLBACK) {
            Log.w(TAG, "All proxies failed — attempting direct connection (no proxy)");
            try {
                WarpConfig result = performRegistration(prefs, null /* direct */);
                lastSuccessfulProxyIndex.set(-1);
                Log.i(TAG, "✓ Registration successful via direct connection");
                return result;

            } catch (Exception e) {
                failureLog.append("  [direct] FAILED: ")
                        .append(e.getClass().getSimpleName())
                        .append(" — ").append(e.getMessage()).append("\n");
                Log.e(TAG, "Direct connection also failed: " + e.getMessage());
            }
        }

        // ── Phase 3: Total failure ────────────────────────────────────────────
        Log.e(TAG, "All registration strategies exhausted:\n" + failureLog);
        throw new IOException("WARP registration failed — all strategies exhausted.\n"
                + failureLog
                + "\nFix: Update PROXY_POOL with country-targeted usernames "
                + "(e.g. username-country-us) to avoid Indian exit nodes.");
    }

    /**
     * Builds an attempt order array that prioritizes the last successful proxy.
     *
     * <p>Example: pool=[A,B,C], last successful=1 (B) → order=[1,0,2]
     */
    private static int[] buildAttemptOrder(int poolSize) {
        int[] order = new int[poolSize];
        int preferred = lastSuccessfulProxyIndex.get();

        if (preferred >= 0 && preferred < poolSize) {
            // Last successful proxy goes first
            order[0] = preferred;
            int writeIdx = 1;
            for (int i = 0; i < poolSize; i++) {
                if (i != preferred) {
                    order[writeIdx++] = i;
                }
            }
        } else {
            // No preference — sequential order
            for (int i = 0; i < poolSize; i++) {
                order[i] = i;
            }
        }
        return order;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // CORE REGISTRATION LOGIC
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Performs a single registration attempt using the specified proxy configuration.
     *
     * @param prefs       SharedPreferences for caching the result
     * @param proxyConfig Proxy to use, or {@code null} for direct connection
     * @return Populated and validated WarpConfig
     * @throws Exception on any network, parsing, or validation failure
     */
    private static WarpConfig performRegistration(
            SharedPreferences prefs,
            ProxyConfig proxyConfig) throws Exception {

        Log.d(TAG, "Registering WARP device → "
                + (proxyConfig != null ? "proxy: " + proxyConfig : "direct connection"));

        // ── Step 1: Generate fresh WireGuard keypair ──────────────────────────
        KeyPair keyPair     = new KeyPair();
        String  privateKeyB64 = keyPair.getPrivateKey().toBase64();
        String  publicKeyB64  = keyPair.getPublicKey().toBase64();
        Log.d(TAG, "Generated WireGuard keypair | pubkey=" + publicKeyB64.substring(0, 8) + "...");

        // ── Step 2: Build registration request body ───────────────────────────
        JSONObject requestBody = buildRequestBody(publicKeyB64);

        // ── Step 3: Build OkHttp client (with or without proxy) ───────────────
        OkHttpClient httpClient = buildHttpClient(proxyConfig);

        // ── Step 4: Build HTTP request ─────────────────────────────────────────
        Request httpRequest = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent", USER_AGENT)
                .header("CF-Client-Version", CF_CLIENT_VERSION)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(requestBody.toString(), JSON_MEDIA_TYPE))
                .build();

        // ── Step 5: Execute request and read response ──────────────────────────
        String responseText = executeRequest(httpClient, httpRequest);

        // ── Step 6: Parse response ─────────────────────────────────────────────
        WarpConfig config = parseRegistrationResponse(responseText, privateKeyB64, publicKeyB64);

        // ── Step 7: Validate cryptographic material ────────────────────────────
        validateWireGuardKeys(config);

        // ── Step 8: Persist to cache ───────────────────────────────────────────
        persistConfig(prefs, config);

        Log.i(TAG, "✓ WARP registered | v4=" + config.v4Address
                + " v6=" + (config.v6Address.isEmpty() ? "none" : config.v6Address)
                + " endpoint=" + config.endpoint
                + " via=" + (proxyConfig != null ? proxyConfig.description : "direct"));

        return config;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // HTTP CLIENT BUILDER
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Builds an OkHttpClient configured for the given proxy.
     *
     * @param proxyConfig Proxy to configure, or null for direct connection
     * @return Configured OkHttpClient instance
     */
    private static OkHttpClient buildHttpClient(ProxyConfig proxyConfig) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS);

        if (proxyConfig != null) {
            // Configure proxy
            Proxy proxy = new Proxy(
                    Proxy.Type.HTTP,
                    new InetSocketAddress(proxyConfig.host, proxyConfig.port)
            );
            builder.proxy(proxy);

            // Configure proxy authentication
            final String proxyUsername = proxyConfig.username;
            final String proxyPassword = proxyConfig.password;

            builder.proxyAuthenticator(new Authenticator() {
                @Override
                public Request authenticate(Route route, Response response) throws IOException {
                    // Prevent infinite retry loops — OkHttp calls this on 407 responses.
                    // If we already sent auth and still get 407, credentials are wrong.
                    if (response.request().header("Proxy-Authorization") != null) {
                        Log.e(TAG, "Proxy auth failed — check username/password for "
                                + proxyUsername);
                        return null; // Returning null aborts the request
                    }
                    String credential = Credentials.basic(proxyUsername, proxyPassword);
                    return response.request().newBuilder()
                            .header("Proxy-Authorization", credential)
                            .build();
                }
            });

            Log.d(TAG, "HTTP client configured | proxy=" + proxyConfig.host
                    + ":" + proxyConfig.port + " user=" + proxyUsername);
        } else {
            Log.d(TAG, "HTTP client configured | direct (no proxy)");
        }

        return builder.build();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // REQUEST BUILDING
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Builds the Cloudflare WARP registration request body.
     * Matches the structure sent by the official 1.1.1.1 app and wgcf.
     */
    private static JSONObject buildRequestBody(String publicKeyBase64) throws JSONException {
        JSONObject body = new JSONObject();
        body.put(JSON_KEY,        publicKeyBase64);
        body.put(JSON_INSTALL_ID, "");
        body.put(JSON_FCM_TOKEN,  "");
        body.put(JSON_TOS,        iso8601Now());
        body.put(JSON_MODEL,      "PC");
        body.put(JSON_TYPE,       "Android");
        body.put(JSON_LOCALE,     "en_US");
        return body;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // HTTP EXECUTION
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Executes the HTTP request and returns the response body as a string.
     *
     * @throws IOException on HTTP error, null body, or empty body
     */
    private static String executeRequest(OkHttpClient client, Request request) throws IOException {
        try (Response response = client.newCall(request).execute()) {

            if (!response.isSuccessful()) {
                ResponseBody errorBody = response.body();
                String errorText = (errorBody != null) ? errorBody.string() : "<no body>";
                throw new IOException("WARP API HTTP " + response.code() + ": " + errorText);
            }

            ResponseBody responseBody = response.body();
            if (responseBody == null) {
                throw new IOException("WARP API returned null body (HTTP " + response.code() + ")");
            }

            String text = responseBody.string();
            if (text == null || text.isEmpty()) {
                throw new IOException("WARP API returned empty body (HTTP " + response.code() + ")");
            }

            Log.d(TAG, "Response received: " + text.length() + " bytes");
            return text;
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // RESPONSE PARSING
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Parses the Cloudflare registration response JSON into a WarpConfig.
     *
     * <p>Required fields: config.peers[0].public_key, config.peers[0].endpoint.host,
     * config.interface.addresses.v4
     *
     * <p>Optional fields: config.interface.addresses.v6, config.client_id
     *
     * @throws JSONException on malformed JSON
     * @throws IOException   on missing required fields
     */
    private static WarpConfig parseRegistrationResponse(
            String responseText,
            String privateKeyBase64,
            String publicKeyBase64) throws JSONException, IOException {

        JSONObject json = new JSONObject(responseText);

        // Navigate: root → config
        requireField(json, JSON_CONFIG, "root");
        JSONObject config = json.getJSONObject(JSON_CONFIG);

        // Navigate: config → peers[0]
        requireField(config, JSON_PEERS, "config");
        JSONArray peers = config.getJSONArray(JSON_PEERS);
        if (peers.length() == 0) {
            throw new IOException("WARP response: config.peers is empty");
        }
        JSONObject peer0 = peers.getJSONObject(0);

        // Extract server public key
        requireField(peer0, JSON_PUBLIC_KEY, "peers[0]");
        String serverPublicKey = requireNonEmpty(
                peer0.getString(JSON_PUBLIC_KEY), "peers[0].public_key");

        // Extract endpoint host
        requireField(peer0, JSON_ENDPOINT, "peers[0]");
        JSONObject endpointObj = peer0.getJSONObject(JSON_ENDPOINT);
        requireField(endpointObj, JSON_HOST, "endpoint");
        String endpointHost = requireNonEmpty(
                endpointObj.getString(JSON_HOST), "endpoint.host");

        // Navigate: config → interface → addresses
        requireField(config, JSON_INTERFACE, "config");
        JSONObject iface = config.getJSONObject(JSON_INTERFACE);
        requireField(iface, JSON_ADDRESSES, "interface");
        JSONObject addresses = iface.getJSONObject(JSON_ADDRESSES);

        // v4 address (required)
        requireField(addresses, JSON_V4, "addresses");
        String v4 = requireNonEmpty(addresses.getString(JSON_V4), "addresses.v4");

        // v6 address and client_id (optional)
        String v6       = addresses.optString(JSON_V6, "");
        String clientId = config.optString(JSON_CLIENT_ID, "");

        // Assemble config
        WarpConfig result = new WarpConfig();
        result.privateKeyBase64 = privateKeyBase64;
        result.publicKeyBase64  = publicKeyBase64;
        result.serverPublicKey  = serverPublicKey;
        result.endpoint         = endpointHost;
        result.v4Address        = v4;
        result.v6Address        = v6;
        result.clientId         = clientId;

        return result;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // VALIDATION
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Validates WireGuard key material can be decoded from base64.
     * Catches invalid keys before they propagate into tunnel setup.
     *
     * @throws IllegalStateException if either key is malformed
     */
    private static void validateWireGuardKeys(WarpConfig config) {
        try {
            Key.fromBase64(config.privateKeyBase64);
        } catch (Exception e) {
            throw new IllegalStateException(
                    "Invalid WireGuard private key in registration response: " + e.getMessage(), e);
        }

        try {
            Key.fromBase64(config.serverPublicKey);
        } catch (Exception e) {
            throw new IllegalStateException(
                    "Invalid WireGuard server public key in registration response: "
                            + e.getMessage(), e);
        }
    }

    /**
     * Asserts that a JSON object contains the specified field.
     *
     * @param obj       JSON object to check
     * @param field     Field name to require
     * @param context   Human-readable context for error messages
     * @throws IOException if field is missing
     */
    private static void requireField(JSONObject obj, String field, String context)
            throws IOException {
        if (!obj.has(field)) {
            throw new IOException(
                    "WARP response malformed: missing '" + field + "' in " + context);
        }
    }

    /**
     * Asserts that a string value is non-null and non-empty.
     *
     * @param value   String to validate
     * @param field   Field name for error message
     * @return The original value if valid
     * @throws IOException if value is null or empty
     */
    private static String requireNonEmpty(String value, String field) throws IOException {
        if (value == null || value.isEmpty()) {
            throw new IOException("WARP response malformed: '" + field + "' is empty");
        }
        return value;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // CACHING
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Attempts to load WarpConfig from SharedPreferences.
     *
     * @return WarpConfig if cache is complete and readable, null otherwise
     */
    private static WarpConfig loadCachedConfig(SharedPreferences prefs) {
        try {
            String privateKey = prefs.getString(K_PRIV, null);
            String srvPubKey  = prefs.getString(K_SRV_PUB, null);

            // Quick check — if primary keys missing, cache is invalid
            if (privateKey == null || srvPubKey == null) {
                return null;
            }

            WarpConfig config = new WarpConfig();
            config.privateKeyBase64 = privateKey;
            config.publicKeyBase64  = prefs.getString(K_PUB, null);
            config.serverPublicKey  = srvPubKey;
            config.endpoint         = prefs.getString(K_ENDPOINT, null);
            config.v4Address        = prefs.getString(K_V4, null);
            config.v6Address        = prefs.getString(K_V6, "");
            config.clientId         = prefs.getString(K_CLIENT_ID, "");

            return config;

        } catch (Exception e) {
            Log.e(TAG, "Failed to read WARP cache from SharedPreferences", e);
            return null;
        }
    }

    /**
     * Persists all WarpConfig fields to SharedPreferences atomically.
     * Uses {@code apply()} for asynchronous write (never blocks the calling thread).
     */
    private static void persistConfig(SharedPreferences prefs, WarpConfig config) {
        prefs.edit()
                .putString(K_PRIV,      config.privateKeyBase64)
                .putString(K_PUB,       config.publicKeyBase64)
                .putString(K_SRV_PUB,   config.serverPublicKey)
                .putString(K_ENDPOINT,  config.endpoint)
                .putString(K_V4,        config.v4Address)
                .putString(K_V6,        config.v6Address)
                .putString(K_CLIENT_ID, config.clientId)
                .apply();
        Log.d(TAG, "WARP config persisted to cache");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // UTILITIES
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Generates an ISO 8601 UTC timestamp.
     *
     * <p>SimpleDateFormat is NOT thread-safe, so we create a new instance per call.
     * This is intentional and correct — do not make this a static field.
     *
     * <p>Format: {@code 2024-01-15T10:30:00.000Z}
     */
    private static String iso8601Now() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }
}