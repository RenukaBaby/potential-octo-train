package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class CloudflareDeviceProvisioner {
    private static final String DEBUG_TAG = "AdsViewer/CF-PROVISION";

    private static final String PROVISION_API_URL = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String HEADER_USER_AGENT = "okhttp/3.12.1";
    private static final String HEADER_CLIENT_VER = "a-6.30-3596";

    private static final String PREF_LOCAL_PRIVATE = "cf_local_priv";
    private static final String PREF_LOCAL_PUBLIC = "cf_local_pub";
    private static final String PREF_REMOTE_PUBLIC = "cf_remote_pub";
    private static final String PREF_REMOTE_ENDPOINT = "cf_endpoint";
    private static final String PREF_IP_V4 = "cf_v4_addr";
    private static final String PREF_IP_V6 = "cf_v6_addr";
    private static final String PREF_RESERVED_ID = "cf_reserved_id";

    public static class ProvisioningDetails {
        public String privateKeyLocal;
        public String publicKeyLocal;
        public String publicKeyRemote;
        public String connectionEndpoint;
        public String addressV4;
        public String addressV6;
        public String reservedClientId;
    }

    public static ProvisioningDetails fetchOrProvision(SharedPreferences storage, boolean requireNewIdentity)
            throws Exception {

        boolean hasSavedIdentity = storage.contains(PREF_LOCAL_PRIVATE) && storage.contains(PREF_REMOTE_PUBLIC);

        if (!requireNewIdentity && hasSavedIdentity) {
            ProvisioningDetails details = new ProvisioningDetails();
            details.privateKeyLocal = storage.getString(PREF_LOCAL_PRIVATE, null);
            details.publicKeyLocal = storage.getString(PREF_LOCAL_PUBLIC, null);
            details.publicKeyRemote = storage.getString(PREF_REMOTE_PUBLIC, null);
            details.connectionEndpoint = storage.getString(PREF_REMOTE_ENDPOINT, null);
            details.addressV4 = storage.getString(PREF_IP_V4, null);
            details.addressV6 = storage.getString(PREF_IP_V6, null);
            details.reservedClientId = storage.getString(PREF_RESERVED_ID, null);
            Log.d(DEBUG_TAG, "Loaded existing CF identity. IPv4: " + details.addressV4);
            return details;
        }

        Log.d(DEBUG_TAG, "Requesting fresh CF identity...");

        KeyPair generatedKeys = new KeyPair();
        String generatedPrivateBase64 = generatedKeys.getPrivateKey().toBase64();
        String generatedPublicBase64 = generatedKeys.getPublicKey().toBase64();

        JSONObject requestPayload = new JSONObject();
        requestPayload.put("locale", "en_US");
        requestPayload.put("type", "Android");
        requestPayload.put("model", "PC");
        requestPayload.put("tos", fetchCurrentUtcTimestamp());
        requestPayload.put("fcm_token", "");
        requestPayload.put("install_id", "");
        requestPayload.put("key", generatedPublicBase64);

        OkHttpClient httpClient = new OkHttpClient.Builder()
                .readTimeout(20, TimeUnit.SECONDS)
                .connectTimeout(15, TimeUnit.SECONDS)
                .build();

        RequestBody postBody = RequestBody.create(
                requestPayload.toString(),
                MediaType.parse("application/json; charset=utf-8")
        );

        Request httpRequest = new Request.Builder()
                .url(PROVISION_API_URL)
                .addHeader("Content-Type", "application/json")
                .addHeader("CF-Client-Version", HEADER_CLIENT_VER)
                .addHeader("User-Agent", HEADER_USER_AGENT)
                .post(postBody)
                .build();

        String rawResponse;
        try (Response response = httpClient.newCall(httpRequest).execute()) {
            ResponseBody body = response.body();
            rawResponse = (body == null) ? "" : body.string();
            if (!response.isSuccessful()) {
                throw new IOException("CF Provisioning HTTP error " + response.code() + " | Body: " + rawResponse);
            }
        }

        Log.d(DEBUG_TAG, "Received successful CF provision response (" + rawResponse.length() + " bytes)");

        JSONObject rootElement = new JSONObject(rawResponse);
        JSONObject configElement = rootElement.getJSONObject("config");

        JSONArray remotePeers = configElement.getJSONArray("peers");
        JSONObject firstPeer = remotePeers.getJSONObject(0);
        
        String cfPublicKey = firstPeer.getString("public_key");
        String cfHostEndpoint = firstPeer.getJSONObject("endpoint").getString("host");

        JSONObject assignedAddresses = configElement.getJSONObject("interface").getJSONObject("addresses");
        String assignedV4 = assignedAddresses.getString("v4");
        String assignedV6 = assignedAddresses.getString("v6");

        String fetchedClientId = configElement.optString("client_id", "");

        ProvisioningDetails newDetails = new ProvisioningDetails();
        newDetails.privateKeyLocal = generatedPrivateBase64;
        newDetails.publicKeyLocal = generatedPublicBase64;
        newDetails.publicKeyRemote = cfPublicKey;
        newDetails.connectionEndpoint = cfHostEndpoint;
        newDetails.addressV4 = assignedV4;
        newDetails.addressV6 = assignedV6;
        newDetails.reservedClientId = fetchedClientId;

        Key.fromBase64(newDetails.privateKeyLocal);
        Key.fromBase64(newDetails.publicKeyRemote);

        storage.edit()
                .putString(PREF_LOCAL_PRIVATE, newDetails.privateKeyLocal)
                .putString(PREF_LOCAL_PUBLIC, newDetails.publicKeyLocal)
                .putString(PREF_REMOTE_PUBLIC, newDetails.publicKeyRemote)
                .putString(PREF_REMOTE_ENDPOINT, newDetails.connectionEndpoint)
                .putString(PREF_IP_V4, newDetails.addressV4)
                .putString(PREF_IP_V6, newDetails.addressV6)
                .putString(PREF_RESERVED_ID, newDetails.reservedClientId)
                .apply();

        Log.d(DEBUG_TAG, "Provisioning complete. Assigned IP: " + newDetails.addressV4 
                + ", remote host: " + newDetails.connectionEndpoint);
                
        return newDetails;
    }

    public static void wipeStoredData(SharedPreferences storage) {
        storage.edit()
                .remove(PREF_LOCAL_PRIVATE)
                .remove(PREF_LOCAL_PUBLIC)
                .remove(PREF_REMOTE_PUBLIC)
                .remove(PREF_REMOTE_ENDPOINT)
                .remove(PREF_IP_V4)
                .remove(PREF_IP_V6)
                .remove(PREF_RESERVED_ID)
                .apply();
    }

    private static String fetchCurrentUtcTimestamp() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        return formatter.format(new Date());
    }
}