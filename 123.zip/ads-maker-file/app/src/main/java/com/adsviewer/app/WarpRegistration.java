package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class CloudflareDeviceManager {

    private static final String LOG_TAG = "AdsViewer/CF-DEV";

    private static final String REGISTRATION_ENDPOINT = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String HTTP_USER_AGENT       = "okhttp/3.12.1";
    private static final String CF_VERSION_HEADER     = "a-6.30-3596";

    private static final String PREF_PRIVATE_KEY  = "warp_priv";
    private static final String PREF_PUBLIC_KEY   = "warp_pub";
    private static final String PREF_SERVER_KEY   = "warp_srv_pub";
    private static final String PREF_ENDPOINT     = "warp_endpoint";
    private static final String PREF_IPV4         = "warp_v4";
    private static final String PREF_IPV6         = "warp_v6";
    private static final String PREF_CLIENT_ID    = "warp_client_id";

    private static final int CONNECT_TIMEOUT_SEC = 15;
    private static final int READ_TIMEOUT_SEC    = 20;

    public static class DeviceProfile {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;
    }

    public static DeviceProfile fetchOrCreate(SharedPreferences store, boolean forceRotate)
            throws Exception {

        if (!forceRotate && hasCachedProfile(store)) {
            return loadFromCache(store);
        }

        return performRegistration(store);
    }

    private static boolean hasCachedProfile(SharedPreferences store) {
        return store.contains(PREF_PRIVATE_KEY) && store.contains(PREF_SERVER_KEY);
    }

    private static DeviceProfile loadFromCache(SharedPreferences store) {
        DeviceProfile profile = new DeviceProfile();
        profile.privateKeyBase64 = store.getString(PREF_PRIVATE_KEY, null);
        profile.publicKeyBase64  = store.getString(PREF_PUBLIC_KEY,  null);
        profile.serverPublicKey  = store.getString(PREF_SERVER_KEY,  null);
        profile.endpoint         = store.getString(PREF_ENDPOINT,    null);
        profile.v4Address        = store.getString(PREF_IPV4,        null);
        profile.v6Address        = store.getString(PREF_IPV6,        null);
        profile.clientId         = store.getString(PREF_CLIENT_ID,   null);
        Log.d(LOG_TAG, "Reusing cached WARP registration: v4=" + profile.v4Address);
        return profile;
    }

    private static DeviceProfile performRegistration(SharedPreferences store) throws Exception {
        Log.d(LOG_TAG, "Registering new WARP device with Cloudflare...");

        KeyPair wireguardPair = new KeyPair();
        String generatedPriv  = wireguardPair.getPrivateKey().toBase64();
        String generatedPub   = wireguardPair.getPublicKey().toBase64();

        String requestPayload = buildRequestPayload(generatedPub);
        String rawResponse    = dispatchRegistrationRequest(requestPayload);

        Log.d(LOG_TAG, "WARP reg response received (" + rawResponse.length() + " bytes)");

        DeviceProfile profile = parseRegistrationResponse(rawResponse, generatedPriv, generatedPub);

        validateKeyIntegrity(profile);
        persistProfile(store, profile);

        Log.d(LOG_TAG, "[WARP] Registered with Cloudflare: v4=" + profile.v4Address
                + " endpoint=" + profile.endpoint);

        return profile;
    }

    private static String buildRequestPayload(String publicKey) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("key",        publicKey);
        payload.put("install_id", "");
        payload.put("fcm_token",  "");
        payload.put("tos",        currentUtcTimestamp());
        payload.put("model",      "PC");
        payload.put("type",       "Android");
        payload.put("locale",     "en_US");
        return payload.toString();
    }

    private static String dispatchRegistrationRequest(String jsonBody) throws Exception {
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .connectTimeout(CONNECT_TIMEOUT_SEC, TimeUnit.SECONDS)
                .readTimeout(READ_TIMEOUT_SEC, TimeUnit.SECONDS)
                .build();

        MediaType jsonMediaType = MediaType.parse("application/json; charset=utf-8");

        Request outbound = new Request.Builder()
                .url(REGISTRATION_ENDPOINT)
                .header("User-Agent",       HTTP_USER_AGENT)
                .header("CF-Client-Version", CF_VERSION_HEADER)
                .header("Content-Type",     "application/json")
                .post(RequestBody.create(jsonBody, jsonMediaType))
                .build();

        String responseText;
        try (Response inbound = httpClient.newCall(outbound).execute()) {
            ResponseBody responseBody = inbound.body();
            responseText = responseBody != null ? responseBody.string() : "";
            if (!inbound.isSuccessful()) {
                throw new IOException("WARP reg HTTP " + inbound.code() + ": " + responseText);
            }
        }

        return responseText;
    }

    private static DeviceProfile parseRegistrationResponse(
            String rawJson,
            String privKey,
            String pubKey) throws Exception {

        JSONObject root       = new JSONObject(rawJson);
        JSONObject configNode = root.getJSONObject("config");

        JSONArray  peerList   = configNode.getJSONArray("peers");
        JSONObject firstPeer  = peerList.getJSONObject(0);
        String     serverPub  = firstPeer.getString("public_key");

        JSONObject endpointNode = firstPeer.getJSONObject("endpoint");
        String     resolvedHost = endpointNode.getString("host");

        JSONObject ifaceNode   = configNode.getJSONObject("interface");
        JSONObject addrBlock   = ifaceNode.getJSONObject("addresses");
        String     assignedV4  = addrBlock.getString("v4");
        String     assignedV6  = addrBlock.getString("v6");

        String reservedId = configNode.optString("client_id", "");

        DeviceProfile profile  = new DeviceProfile();
        profile.privateKeyBase64 = privKey;
        profile.publicKeyBase64  = pubKey;
        profile.serverPublicKey  = serverPub;
        profile.endpoint         = resolvedHost;
        profile.v4Address        = assignedV4;
        profile.v6Address        = assignedV6;
        profile.clientId         = reservedId;

        return profile;
    }

    private static void validateKeyIntegrity(DeviceProfile profile) throws Exception {
        Key.fromBase64(profile.privateKeyBase64);
        Key.fromBase64(profile.serverPublicKey);
    }

    private static void persistProfile(SharedPreferences store, DeviceProfile profile) {
        store.edit()
                .putString(PREF_PRIVATE_KEY, profile.privateKeyBase64)
                .putString(PREF_PUBLIC_KEY,  profile.publicKeyBase64)
                .putString(PREF_SERVER_KEY,  profile.serverPublicKey)
                .putString(PREF_ENDPOINT,    profile.endpoint)
                .putString(PREF_IPV4,        profile.v4Address)
                .putString(PREF_IPV6,        profile.v6Address)
                .putString(PREF_CLIENT_ID,   profile.clientId)
                .apply();
    }

    public static void clearCache(SharedPreferences store) {
        store.edit()
                .remove(PREF_PRIVATE_KEY)
                .remove(PREF_PUBLIC_KEY)
                .remove(PREF_SERVER_KEY)
                .remove(PREF_ENDPOINT)
                .remove(PREF_IPV4)
                .remove(PREF_IPV6)
                .remove(PREF_CLIENT_ID)
                .apply();
    }

    private static String currentUtcTimestamp() {
        SimpleDateFormat formatter = new SimpleDateFormat(
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        return formatter.format(new Date());
    }
}