package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class WarpRegistration {
    private static final String LOG_PREFIX = "AdsViewer/WARP-REG";
    private static final String CLOUDFLARE_API_ENDPOINT = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String HTTP_USER_AGENT = "okhttp/3.12.1";
    private static final String CLOUDFLARE_CLIENT_VER = "a-6.30-3596";

    private static final String PREF_PRIVATE_KEY = "warp_priv";
    private static final String PREF_PUBLIC_KEY = "warp_pub";
    private static final String PREF_SERVER_KEY = "warp_srv_pub";
    private static final String PREF_SERVER_ENDPOINT = "warp_endpoint";
    private static final String PREF_IPV4_ADDR = "warp_v4";
    private static final String PREF_IPV6_ADDR = "warp_v6";
    private static final String PREF_DEVICE_ID = "warp_client_id";

    public static class WarpConfig {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;
    }

    public static WarpConfig getOrRegister(SharedPreferences preferences, boolean forceNewRegistration)
            throws Exception {

        if (!forceNewRegistration && hasExistingConfiguration(preferences)) {
            return loadCachedConfiguration(preferences);
        }

        return performNewRegistration(preferences);
    }

    private static boolean hasExistingConfiguration(SharedPreferences prefs) {
        return prefs.contains(PREF_PRIVATE_KEY) && prefs.contains(PREF_SERVER_KEY);
    }

    private static WarpConfig loadCachedConfiguration(SharedPreferences prefs) {
        WarpConfig configuration = new WarpConfig();
        configuration.privateKeyBase64 = prefs.getString(PREF_PRIVATE_KEY, null);
        configuration.publicKeyBase64 = prefs.getString(PREF_PUBLIC_KEY, null);
        configuration.serverPublicKey = prefs.getString(PREF_SERVER_KEY, null);
        configuration.endpoint = prefs.getString(PREF_SERVER_ENDPOINT, null);
        configuration.v4Address = prefs.getString(PREF_IPV4_ADDR, null);
        configuration.v6Address = prefs.getString(PREF_IPV6_ADDR, null);
        configuration.clientId = prefs.getString(PREF_DEVICE_ID, null);
        Log.d(LOG_PREFIX, "Reusing cached WARP registration: v4=" + configuration.v4Address);
        return configuration;
    }

    private static WarpConfig performNewRegistration(SharedPreferences prefs) throws Exception {
        Log.d(LOG_PREFIX, "Registering new WARP device with Cloudflare...");

        KeyPair wireGuardKeys = new KeyPair();
        String clientPrivateKey = wireGuardKeys.getPrivateKey().toBase64();
        String clientPublicKey = wireGuardKeys.getPublicKey().toBase64();

        JSONObject registrationPayload = buildRegistrationRequest(clientPublicKey);
        String responseData = executeRegistrationRequest(registrationPayload);
        WarpConfig deviceConfig = parseRegistrationResponse(responseData, clientPrivateKey, clientPublicKey);
        
        validateAndPersistConfiguration(prefs, deviceConfig);

        Log.d(LOG_PREFIX, "[WARP] Registered with Cloudflare: v4=" + deviceConfig.v4Address
                + " endpoint=" + deviceConfig.endpoint);
        return deviceConfig;
    }

    private static JSONObject buildRegistrationRequest(String publicKey) throws Exception {
        JSONObject requestBody = new JSONObject();
        requestBody.put("key", publicKey);
        requestBody.put("install_id", "");
        requestBody.put("fcm_token", "");
        requestBody.put("tos", getCurrentIsoTimestamp());
        requestBody.put("model", "PC");
        requestBody.put("type", "Android");
        requestBody.put("locale", "en_US");
        return requestBody;
    }

    private static String executeRegistrationRequest(JSONObject payload) throws IOException {
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        Request httpRequest = new Request.Builder()
                .url(CLOUDFLARE_API_ENDPOINT)
                .header("User-Agent", HTTP_USER_AGENT)
                .header("CF-Client-Version", CLOUDFLARE_CLIENT_VER)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(payload.toString(),
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        String responseContent;
        try (Response httpResponse = httpClient.newCall(httpRequest).execute()) {
            ResponseBody responseBody = httpResponse.body();
            responseContent = responseBody != null ? responseBody.string() : "";
            if (!httpResponse.isSuccessful()) {
                throw new IOException("WARP reg HTTP " + httpResponse.code() + ": " + responseContent);
            }
        }

        Log.d(LOG_PREFIX, "WARP reg response received (" + responseContent.length() + " bytes)");
        return responseContent;
    }

    private static WarpConfig parseRegistrationResponse(String responseJson, String privateKey, String publicKey) throws Exception {
        JSONObject parsedResponse = new JSONObject(responseJson);
        JSONObject deviceConfiguration = parsedResponse.getJSONObject("config");

        JSONArray peerList = deviceConfiguration.getJSONArray("peers");
        JSONObject primaryPeer = peerList.getJSONObject(0);
        String serverPublicKey = primaryPeer.getString("public_key");
        JSONObject endpointInfo = primaryPeer.getJSONObject("endpoint");
        String serverEndpoint = endpointInfo.getString("host");

        JSONObject interfaceConfig = deviceConfiguration.getJSONObject("interface");
        JSONObject addressConfig = interfaceConfig.getJSONObject("addresses");
        String ipv4Address = addressConfig.getString("v4");
        String ipv6Address = addressConfig.getString("v6");

        String deviceIdentifier = deviceConfiguration.optString("client_id", "");

        WarpConfig resultConfig = new WarpConfig();
        resultConfig.privateKeyBase64 = privateKey;
        resultConfig.publicKeyBase64 = publicKey;
        resultConfig.serverPublicKey = serverPublicKey;
        resultConfig.endpoint = serverEndpoint;
        resultConfig.v4Address = ipv4Address;
        resultConfig.v6Address = ipv6Address;
        resultConfig.clientId = deviceIdentifier;

        return resultConfig;
    }

    private static void validateAndPersistConfiguration(SharedPreferences prefs, WarpConfig config) throws Exception {
        Key.fromBase64(config.privateKeyBase64);
        Key.fromBase64(config.serverPublicKey);

        prefs.edit()
                .putString(PREF_PRIVATE_KEY, config.privateKeyBase64)
                .putString(PREF_PUBLIC_KEY, config.publicKeyBase64)
                .putString(PREF_SERVER_KEY, config.serverPublicKey)
                .putString(PREF_SERVER_ENDPOINT, config.endpoint)
                .putString(PREF_IPV4_ADDR, config.v4Address)
                .putString(PREF_IPV6_ADDR, config.v6Address)
                .putString(PREF_DEVICE_ID, config.clientId)
                .apply();
    }

    public static void clearCache(SharedPreferences preferences) {
        preferences.edit()
                .remove(PREF_PRIVATE_KEY).remove(PREF_PUBLIC_KEY).remove(PREF_SERVER_KEY)
                .remove(PREF_SERVER_ENDPOINT).remove(PREF_IPV4_ADDR).remove(PREF_IPV6_ADDR).remove(PREF_DEVICE_ID)
                .apply();
    }

    private static String getCurrentIsoTimestamp() {
        SimpleDateFormat timestampFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        timestampFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        return timestampFormatter.format(new Date());
    }
}