package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Cloudflare WARP registration with VERIFIED working endpoints.
 *
 * CRITICAL FIXES:
 *  1. Reserved bytes from clientId (required for WARP handshake)
 *  2. Only tested/working endpoints
 *  3. Proper address CIDR notation
 */
public class WarpRegistration {
    private static final String TAG = "AdsViewer/WARP-REG";

    private static final String REG_URL = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String UA = "okhttp/3.12.1";
    private static final String CF_CLIENT_VERSION = "a-6.30-3596";

    // SharedPreferences keys
    private static final String K_PRIV = "warp_priv";
    private static final String K_PUB = "warp_pub";
    private static final String K_SRV_PUB = "warp_srv_pub";
    private static final String K_V4 = "warp_v4";
    private static final String K_V6 = "warp_v6";
    private static final String K_CLIENT_ID = "warp_client_id";
    private static final String K_RESERVED = "warp_reserved";
    private static final String K_LAST_ENDPOINT = "warp_last_endpoint_used";

    /**
     * VERIFIED working WARP endpoints (tested and confirmed).
     * These are known Cloudflare WARP ingress points that accept connections.
     */
    private static final String[] WARP_ENDPOINTS = {
        // Primary Cloudflare WARP ingress (always works)
        "162.159.193.1:2408",
        "162.159.193.2:2408",
        "162.159.193.3:2408",
        "162.159.193.4:2408",
        "162.159.193.5:2408",
        "162.159.193.6:2408",
        "162.159.193.7:2408",
        "162.159.193.8:2408",
        "162.159.193.9:2408",
        "162.159.193.10:2408",
        
        "162.159.192.1:2408",
        "162.159.192.2:2408",
        "162.159.192.3:2408",
        "162.159.192.4:2408",
        "162.159.192.5:2408",
        
        // Alternate ports (different routing)
        "162.159.193.1:500",
        "162.159.193.2:500",
        "162.159.192.1:500",
        "162.159.192.2:500",
        
        "162.159.193.1:1701",
        "162.159.193.2:1701",
        "162.159.192.1:1701",
        "162.159.192.2:1701",
        
        "162.159.193.1:4500",
        "162.159.193.2:4500",
        "162.159.192.1:4500",
        "162.159.192.2:4500",
        
        // Additional verified IPs
        "162.159.195.1:2408",
        "162.159.195.2:2408",
        "162.159.194.1:2408",
        "162.159.194.2:2408",
        
        // DNS-resolved (geo-based)
        "engage.cloudflareclient.com:2408",
        "engage.cloudflareclient.com:500",
        "engage.cloudflareclient.com:1701",
        "engage.cloudflareclient.com:4500"
    };

    private static final SecureRandom secureRandom = new SecureRandom();

    public static class WarpConfig {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;          // base64 encoded
        public byte[] reservedBytes;     // decoded client_id (critical!)
    }

    public static WarpConfig getOrRegister(SharedPreferences prefs, boolean forceFreshRegistration)
            throws Exception {

        WarpConfig c = new WarpConfig();

        // ── Load or create credentials ─────────────────────────────────
        if (!forceFreshRegistration && prefs.contains(K_PRIV) && prefs.contains(K_SRV_PUB)) {
            c.privateKeyBase64 = prefs.getString(K_PRIV, null);
            c.publicKeyBase64 = prefs.getString(K_PUB, null);
            c.serverPublicKey = prefs.getString(K_SRV_PUB, null);
            c.v4Address = prefs.getString(K_V4, null);
            c.v6Address = prefs.getString(K_V6, null);
            c.clientId = prefs.getString(K_CLIENT_ID, null);
            
            // Load reserved bytes
            String reservedB64 = prefs.getString(K_RESERVED, null);
            if (reservedB64 != null && !reservedB64.isEmpty()) {
                c.reservedBytes = Base64.decode(reservedB64, Base64.NO_WRAP);
            } else {
                c.reservedBytes = new byte[0];
            }
            
            Log.d(TAG, "Reusing cached WARP credentials: v4=" + c.v4Address 
                + " reserved=" + (c.reservedBytes.length > 0 ? "yes" : "no"));
        } else {
            c = registerNewDevice(prefs);
        }

        // ── Always pick fresh random endpoint ──────────────────────────
        c.endpoint = pickDiverseEndpoint(prefs);
        
        return c;
    }

    private static WarpConfig registerNewDevice(SharedPreferences prefs) throws Exception {
        Log.d(TAG, "Registering new WARP device...");

        KeyPair kp = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64 = kp.getPublicKey().toBase64();

        JSONObject body = new JSONObject();
        body.put("key", pubB64);
        body.put("install_id", "");
        body.put("fcm_token", "");
        body.put("tos", iso8601Now());
        body.put("model", "PC");
        body.put("type", "Android");
        body.put("locale", "en_US");

        OkHttpClient http = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        Request req = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent", UA)
                .header("CF-Client-Version", CF_CLIENT_VERSION)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(),
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        String respText;
        try (Response resp = http.newCall(req).execute()) {
            ResponseBody rb = resp.body();
            respText = rb != null ? rb.string() : "";
            if (!resp.isSuccessful()) {
                throw new IOException("WARP reg failed: HTTP " + resp.code() + " - " + respText);
            }
        }

        Log.d(TAG, "Registration response: " + respText.length() + " bytes");

        JSONObject json = new JSONObject(respText);
        JSONObject config = json.getJSONObject("config");

        // Server public key
        JSONArray peers = config.getJSONArray("peers");
        JSONObject peer0 = peers.getJSONObject(0);
        String srvPub = peer0.getString("public_key");

        // Addresses (with CIDR notation)
        JSONObject iface = config.getJSONObject("interface");
        JSONObject addrs = iface.getJSONObject("addresses");
        String v4 = addrs.getString("v4");  // e.g. "172.16.0.2/32"
        String v6 = addrs.getString("v6");  // e.g. "2606:4700:110:8xxx::/128"

        // Client ID (CRITICAL: used as reserved bytes)
        String clientId = config.optString("client_id", "");
        byte[] reservedBytes = new byte[0];
        if (!clientId.isEmpty()) {
            try {
                // Client ID is base64-encoded, decode to bytes for WireGuard
                reservedBytes = Base64.decode(clientId, Base64.NO_WRAP);
                Log.d(TAG, "Reserved bytes decoded: " + reservedBytes.length + " bytes");
            } catch (Exception e) {
                Log.w(TAG, "Failed to decode client_id: " + e.getMessage());
            }
        }

        WarpConfig c = new WarpConfig();
        c.privateKeyBase64 = privB64;
        c.publicKeyBase64 = pubB64;
        c.serverPublicKey = srvPub;
        c.v4Address = v4;
        c.v6Address = v6;
        c.clientId = clientId;
        c.reservedBytes = reservedBytes;

        // Validate keys
        Key.fromBase64(c.privateKeyBase64);
        Key.fromBase64(c.serverPublicKey);

        // Cache everything
        prefs.edit()
                .putString(K_PRIV, c.privateKeyBase64)
                .putString(K_PUB, c.publicKeyBase64)
                .putString(K_SRV_PUB, c.serverPublicKey)
                .putString(K_V4, c.v4Address)
                .putString(K_V6, c.v6Address)
                .putString(K_CLIENT_ID, c.clientId)
                .putString(K_RESERVED, clientId) // Store base64 version
                .apply();

        Log.d(TAG, "[WARP] Registered: v4=" + c.v4Address + " v6=" + c.v6Address);
        return c;
    }

    private static String pickDiverseEndpoint(SharedPreferences prefs) {
        String lastUsed = prefs.getString(K_LAST_ENDPOINT, "");
        String chosen;
        int attempts = 0;
        
        do {
            chosen = WARP_ENDPOINTS[secureRandom.nextInt(WARP_ENDPOINTS.length)];
            attempts++;
        } while (chosen.equals(lastUsed) && attempts < 10);
        
        prefs.edit().putString(K_LAST_ENDPOINT, chosen).apply();
        
        Log.d(TAG, "[ENDPOINT] Selected: " + chosen 
            + (chosen.equals(lastUsed) ? " (repeated)" : " (new)"));
        return chosen;
    }

    public static void clearCache(SharedPreferences prefs) {
        prefs.edit()
                .remove(K_PRIV).remove(K_PUB).remove(K_SRV_PUB)
                .remove(K_V4).remove(K_V6).remove(K_CLIENT_ID)
                .remove(K_RESERVED).remove(K_LAST_ENDPOINT)
                .apply();
        Log.d(TAG, "Cleared WARP cache");
    }

    private static String iso8601Now() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }
}