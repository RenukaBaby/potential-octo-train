package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Handles Cloudflare WARP device registration with diverse endpoint selection.
 *
 * CRITICAL FIX: We IGNORE Cloudflare's suggested endpoint (always engage.cloudflareclient.com:2408)
 * and instead pick from a pool of 38+ diverse ingress points to avoid 104.x exit IP lock.
 *
 * The WireGuard credentials from CF work with ANY WARP ingress endpoint, so we can safely
 * override their suggestion to get varied exit IPs (172.x, 141.x, 185.x, IPv6, etc.).
 */
public class WarpRegistration {
    private static final String TAG = "AdsViewer/WARP-REG";

    private static final String REG_URL = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String UA = "okhttp/3.12.1";
    private static final String CF_CLIENT_VERSION = "a-6.30-3596";

    // SharedPreferences keys
    private static final String K_PRIV = "warp_priv";
    private static final String K_PUB = "warp_pub";
    private static final String K_SRV_PUB = "warp_srv_pub";
    private static final String K_V4 = "warp_v4";
    private static final String K_V6 = "warp_v6";
    private static final String K_CLIENT_ID = "warp_client_id";
    private static final String K_LAST_ENDPOINT = "warp_last_endpoint_used";

    /**
     * Diverse WARP ingress endpoints across different Cloudflare PoPs and ports.
     * Different paths → different exit IP pools (avoiding 104.x lock).
     *
     * Exit ranges you'll see:
     *  - 172.x.x.x (most common alternative)
     *  - 141.101.x.x (CDN range)
     *  - 185.x.x.x (EU PoPs)
     *  - 2606:4700::x (IPv6 — never 104.x)
     *  - 104.x.x.x (what we're avoiding, but may still appear occasionally)
     */
    private static final String[] WARP_ENDPOINTS = {
        // ── Primary ingress IPs on standard port ────────────────────
        "162.159.193.1:2408",
        "162.159.193.2:2408",
        "162.159.192.1:2408",
        "162.159.192.2:2408",
        "162.159.193.5:2408",
        "162.159.192.5:2408",
        
        // ── Alternate ports (different routing paths) ───────────────
        "162.159.193.1:1701",   // L2TP port
        "162.159.192.1:1701",
        "162.159.193.1:500",    // IKEv2 port
        "162.159.192.1:500",
        "162.159.193.1:4500",   // NAT-T port
        "162.159.192.1:4500",
        "162.159.193.1:8886",   // Custom WARP port
        "162.159.192.1:8886",
        "162.159.193.1:864",    // Legacy port
        "162.159.192.1:864",
        
        // ── Different subnet ranges (separate PoP clusters) ─────────
        "162.159.195.1:2408",
        "162.159.195.2:2408",
        "162.159.195.1:1701",
        "162.159.195.1:8886",
        "162.159.194.1:2408",
        "162.159.194.2:2408",
        "162.159.194.1:1701",
        "162.159.136.1:2408",
        "162.159.137.1:2408",
        "162.159.138.1:2408",
        
        // ── DNS-resolved endpoints (geo-based PoP selection) ────────
        "engage.cloudflareclient.com:2408",
        "engage.cloudflareclient.com:1701",
        "engage.cloudflareclient.com:500",
        "engage.cloudflareclient.com:4500",
        "engage.cloudflareclient.com:8886",
        
        // ── IPv6 ingress (completely separate exit infrastructure) ──
        "[2606:4700:d0::a29f:c001]:2408",
        "[2606:4700:d0::a29f:c002]:2408",
        "[2606:4700:d0::a29f:c101]:2408",
        "[2606:4700:d0::a29f:c102]:2408",
        "[2606:4700:d1::a29f:c001]:2408",
        "[2606:4700:d1::a29f:c002]:2408",
        "[2606:4700:d0::a29f:c001]:1701",
        "[2606:4700:d1::a29f:c001]:1701"
    };

    private static final SecureRandom secureRandom = new SecureRandom();

    public static class WarpConfig {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;
    }

    /**
     * Get cached credentials or register a new device with Cloudflare.
     * ALWAYS returns a fresh random endpoint (not cached).
     *
     * @param prefs SharedPreferences instance
     * @param forceFreshRegistration if true, gets new keys/IPs from Cloudflare
     * @return WarpConfig with randomly-selected diverse endpoint
     */
    public static WarpConfig getOrRegister(SharedPreferences prefs, boolean forceFreshRegistration)
            throws Exception {

        WarpConfig c = new WarpConfig();

        // ── Step 1: Load or create credentials ─────────────────────────
        if (!forceFreshRegistration && prefs.contains(K_PRIV) && prefs.contains(K_SRV_PUB)) {
            // Reuse cached registration
            c.privateKeyBase64 = prefs.getString(K_PRIV, null);
            c.publicKeyBase64 = prefs.getString(K_PUB, null);
            c.serverPublicKey = prefs.getString(K_SRV_PUB, null);
            c.v4Address = prefs.getString(K_V4, null);
            c.v6Address = prefs.getString(K_V6, null);
            c.clientId = prefs.getString(K_CLIENT_ID, null);
            Log.d(TAG, "Reusing cached WARP credentials: v4=" + c.v4Address);
        } else {
            // Register brand-new device with Cloudflare
            c = registerNewDevice(prefs);
        }

        // ── Step 2: ALWAYS pick a fresh random endpoint ────────────────
        // This overrides whatever Cloudflare suggested in their response
        c.endpoint = pickDiverseEndpoint(prefs);
        
        return c;
    }

    /**
     * Register a new WARP device with Cloudflare's API.
     */
    private static WarpConfig registerNewDevice(SharedPreferences prefs) throws Exception {
        Log.d(TAG, "Registering new WARP device with Cloudflare...");

        // Generate fresh WireGuard keypair
        KeyPair kp = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64 = kp.getPublicKey().toBase64();

        JSONObject body = new JSONObject();
        body.put("key", pubB64);
        body.put("install_id", "");
        body.put("fcm_token", "");
        body.put("tos", iso8601Now());
        body.put("model", "PC");
        body.put("type", "Android");
        body.put("locale", "en_US");

        OkHttpClient http = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        Request req = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent", UA)
                .header("CF-Client-Version", CF_CLIENT_VERSION)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(),
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        String respText;
        try (Response resp = http.newCall(req).execute()) {
            ResponseBody rb = resp.body();
            respText = rb != null ? rb.string() : "";
            if (!resp.isSuccessful()) {
                throw new IOException("WARP reg HTTP " + resp.code() + ": " + respText);
            }
        }

        Log.d(TAG, "WARP registration response received (" + respText.length() + " bytes)");

        JSONObject json = new JSONObject(respText);
        JSONObject config = json.getJSONObject("config");

        // Extract server public key
        JSONArray peers = config.getJSONArray("peers");
        JSONObject peer0 = peers.getJSONObject(0);
        String srvPub = peer0.getString("public_key");
        
        // ── IGNORE Cloudflare's suggested endpoint ─────────────────────
        // JSONObject ep = peer0.getJSONObject("endpoint");
        // String cfEndpoint = ep.getString("host");
        // ^ This is always "engage.cloudflareclient.com:2408" → 104.x exits
        // We'll pick our own endpoint from the diverse pool instead.

        // Extract assigned IP addresses
        JSONObject iface = config.getJSONObject("interface");
        JSONObject addrs = iface.getJSONObject("addresses");
        String v4 = addrs.getString("v4");
        String v6 = addrs.getString("v6");

        String clientId = config.optString("client_id", "");

        WarpConfig c = new WarpConfig();
        c.privateKeyBase64 = privB64;
        c.publicKeyBase64 = pubB64;
        c.serverPublicKey = srvPub;
        c.v4Address = v4;
        c.v6Address = v6;
        c.clientId = clientId;
        // endpoint will be set by caller

        // Validate keys parse correctly
        Key.fromBase64(c.privateKeyBase64);
        Key.fromBase64(c.serverPublicKey);

        // Cache credentials (but NOT endpoint — picked fresh each time)
        prefs.edit()
                .putString(K_PRIV, c.privateKeyBase64)
                .putString(K_PUB, c.publicKeyBase64)
                .putString(K_SRV_PUB, c.serverPublicKey)
                .putString(K_V4, c.v4Address)
                .putString(K_V6, c.v6Address)
                .putString(K_CLIENT_ID, c.clientId)
                .apply();

        Log.d(TAG, "[WARP] Successfully registered: v4=" + c.v4Address 
            + " v6=" + c.v6Address);
        return c;
    }

    /**
     * Select a random WARP ingress endpoint, avoiding the last-used one.
     * Called on EVERY tunnel start to ensure rotation through different PoPs.
     */
    private static String pickDiverseEndpoint(SharedPreferences prefs) {
        String lastUsed = prefs.getString(K_LAST_ENDPOINT, "");
        String chosen;
        int attempts = 0;
        
        // Pick random endpoint, trying to avoid the last one
        do {
            chosen = WARP_ENDPOINTS[secureRandom.nextInt(WARP_ENDPOINTS.length)];
            attempts++;
        } while (chosen.equals(lastUsed) && attempts < 10);
        
        // Save for next rotation
        prefs.edit().putString(K_LAST_ENDPOINT, chosen).apply();
        
        Log.d(TAG, "[ENDPOINT] Selected: " + chosen 
            + (chosen.equals(lastUsed) ? " (repeated)" : " (new)"));
        return chosen;
    }

    /**
     * Clear all cached WARP credentials and endpoint history.
     */
    public static void clearCache(SharedPreferences prefs) {
        prefs.edit()
                .remove(K_PRIV).remove(K_PUB).remove(K_SRV_PUB)
                .remove(K_V4).remove(K_V6).remove(K_CLIENT_ID)
                .remove(K_LAST_ENDPOINT)
                .apply();
        Log.d(TAG, "Cleared WARP registration cache");
    }

    private static String iso8601Now() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }
}