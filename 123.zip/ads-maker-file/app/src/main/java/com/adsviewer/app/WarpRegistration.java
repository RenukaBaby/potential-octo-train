package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class WarpRegistration {

    private static final String LOG_LABEL = "AdsViewer/CF-TUNNEL";

    private static final String TARGET_ENDPOINT = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String AGENT_STRING = "okhttp/3.12.1";
    private static final String VERSION_HEADER_VAL = "a-6.30-3596";

    private static final String STORE_PRIV = "tun_key_priv";
    private static final String STORE_PUB = "tun_key_pub";
    private static final String STORE_PEER = "tun_peer_key";
    private static final String STORE_HOST = "tun_host";
    private static final String STORE_ADDR4 = "tun_inet4";
    private static final String STORE_ADDR6 = "tun_inet6";
    private static final String STORE_RES = "tun_reserved";

    public static class TunnelProfile {
        public String myPrivateKey;
        public String myPublicKey;
        public String peerPublicKey;
        public String hostPort;
        public String inet4;
        public String inet6;
        public String reservedToken;
    }

    public static TunnelProfile resolveProfile(SharedPreferences store, boolean forceRotate)
            throws Exception {

        boolean cacheValid = store.contains(STORE_PRIV) && store.contains(STORE_PEER);

        if (!forceRotate && cacheValid) {
            TunnelProfile cached = new TunnelProfile();
            cached.myPrivateKey = store.getString(STORE_PRIV, null);
            cached.myPublicKey = store.getString(STORE_PUB, null);
            cached.peerPublicKey = store.getString(STORE_PEER, null);
            cached.hostPort = store.getString(STORE_HOST, null);
            cached.inet4 = store.getString(STORE_ADDR4, null);
            cached.inet6 = store.getString(STORE_ADDR6, null);
            cached.reservedToken = store.getString(STORE_RES, null);
            Log.d(LOG_LABEL, "Reusing cached WARP registration: v4=" + cached.inet4);
            return cached;
        }

        Log.d(LOG_LABEL, "Registering new WARP device with Cloudflare...");

        KeyPair freshPair = new KeyPair();
        String encodedPriv = freshPair.getPrivateKey().toBase64();
        String encodedPub = freshPair.getPublicKey().toBase64();

        JSONObject payload = buildPayload(encodedPub);

        OkHttpClient netClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        Request outgoingReq = new Request.Builder()
                .url(TARGET_ENDPOINT)
                .header("User-Agent", AGENT_STRING)
                .header("CF-Client-Version", VERSION_HEADER_VAL)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(
                        payload.toString(),
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        String rawBody = executeRequest(netClient, outgoingReq);

        Log.d(LOG_LABEL, "WARP reg response received (" + rawBody.length() + " bytes)");

        TunnelProfile result = parseResponse(rawBody, encodedPriv, encodedPub);

        Key.fromBase64(result.myPrivateKey);
        Key.fromBase64(result.peerPublicKey);

        persistProfile(store, result);

        Log.d(LOG_LABEL, "[WARP] Registered with Cloudflare: v4=" + result.inet4
                + " endpoint=" + result.hostPort);
        return result;
    }

    private static JSONObject buildPayload(String pubKeyEncoded) throws Exception {
        JSONObject obj = new JSONObject();
        obj.put("key", pubKeyEncoded);
        obj.put("install_id", "");
        obj.put("fcm_token", "");
        obj.put("tos", nowAsIso8601());
        obj.put("model", "PC");
        obj.put("type", "Android");
        obj.put("locale", "en_US");
        return obj;
    }

    private static String executeRequest(OkHttpClient client, Request request) throws IOException {
        try (Response resp = client.newCall(request).execute()) {
            ResponseBody rb = resp.body();
            String text = rb != null ? rb.string() : "";
            if (!resp.isSuccessful()) {
                throw new IOException("WARP reg HTTP " + resp.code() + ": " + text);
            }
            return text;
        }
    }

    private static TunnelProfile parseResponse(String json, String privKey, String pubKey)
            throws Exception {
        JSONObject root = new JSONObject(json);
        JSONObject cfgBlock = root.getJSONObject("config");

        JSONArray peerList = cfgBlock.getJSONArray("peers");
        JSONObject firstPeer = peerList.getJSONObject(0);
        String remotePubKey = firstPeer.getString("public_key");
        String remoteHost = firstPeer.getJSONObject("endpoint").getString("host");

        JSONObject ifaceBlock = cfgBlock.getJSONObject("interface");
        JSONObject addrBlock = ifaceBlock.getJSONObject("addresses");
        String v4Addr = addrBlock.getString("v4");
        String v6Addr = addrBlock.getString("v6");

        String clientToken = cfgBlock.optString("client_id", "");

        TunnelProfile profile = new TunnelProfile();
        profile.myPrivateKey = privKey;
        profile.myPublicKey = pubKey;
        profile.peerPublicKey = remotePubKey;
        profile.hostPort = remoteHost;
        profile.inet4 = v4Addr;
        profile.inet6 = v6Addr;
        profile.reservedToken = clientToken;
        return profile;
    }

    private static void persistProfile(SharedPreferences store, TunnelProfile p) {
        store.edit()
                .putString(STORE_PRIV, p.myPrivateKey)
                .putString(STORE_PUB, p.myPublicKey)
                .putString(STORE_PEER, p.peerPublicKey)
                .putString(STORE_HOST, p.hostPort)
                .putString(STORE_ADDR4, p.inet4)
                .putString(STORE_ADDR6, p.inet6)
                .putString(STORE_RES, p.reservedToken)
                .apply();
    }

    public static void clearCache(SharedPreferences store) {
        store.edit()
                .remove(STORE_PRIV)
                .remove(STORE_PUB)
                .remove(STORE_PEER)
                .remove(STORE_HOST)
                .remove(STORE_ADDR4)
                .remove(STORE_ADDR6)
                .remove(STORE_RES)
                .apply();
    }

    private static String nowAsIso8601() {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        return fmt.format(new Date());
    }
}