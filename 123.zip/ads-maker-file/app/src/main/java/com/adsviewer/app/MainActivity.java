package com.adsviewer.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import com.wireguard.config.Interface;
import com.wireguard.config.Peer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Ultimate God-Level AdsViewer MainActivity.
 *
 * All improvements annotated with [GOD] markers for auditability.
 *
 * Key upgrades over baseline:
 *  - Thread-safe volatile/atomic shared state
 *  - Static inner class for JS bridge (no memory leak)
 *  - Proper WebView lifecycle (detach before destroy)
 *  - Immersive mode survives focus loss
 *  - Variable rotation intervals (anti-pattern detection)
 *  - HTTP-level fingerprint spoofing (not unreliable JS-only)
 *  - SSL error handler (prevent error pages on ad domains)
 *  - Screen/viewport JS spoofing
 *  - URL query-param fix (&amp; → &)
 *  - Graceful executor shutdown with awaitTermination
 *  - Robust configuration-change survival
 *  - SecureRandom for all randomisation
 *  - Guard against duplicate rotation timers
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AdsViewer";
    private static final int ROTATION_INTERVAL_MS_MIN = 8_000;  // [GOD] variable timing: 8-15s
    private static final int ROTATION_INTERVAL_MS_MAX = 15_000; // instead of fixed 10s
    private static final int REREGISTER_EVERY_N_ROTATIONS = 5;

    // ── Thread-safe state ──────────────────────────────────────────────
    private final SecureRandom secureRandom = new SecureRandom();
    private final AtomicInteger rotationCount = new AtomicInteger(0);
    private final AtomicInteger rotationsSinceReregister = new AtomicInteger(0);
    private final AtomicReference<String> currentExitIp = new AtomicReference<>("unknown");
    private volatile boolean warpUp = false;            // [GOD] volatile – written from executor, read from main
    private volatile boolean destroying = false;        // guard against post-destroy handler execution

    // ── Non-atomic but main-thread-confined ────────────────────────────
    private String currentLanguage = "en-US,en;q=0.9";
    private String currentReferer = "https://www.google.com/";

    // ── Framework objects ──────────────────────────────────────────────
    private WebView webView;
    private SharedPreferences prefs;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "warp-worker");
        t.setDaemon(true);
        return t;
    });

    // ── WARP ───────────────────────────────────────────────────────────
    private Backend wgBackend;
    private final WarpTunnel warpTunnel = new WarpTunnel();
    private ActivityResultLauncher<Intent> vpnPermissionLauncher;

    // ── Rotation runnable (re-created each time to avoid duplicates) ───
    private volatile Runnable rotationRunnable;          // [GOD] volatile reference so we can cancel/swap

    // ═══════════════════════════════════════════════════════════════════
    //  FINGERPRINT DATABASES
    // ═══════════════════════════════════════════════════════════════════

    private static final String[] DEVICE_MODELS = {
        "SM-S908B", "SM-S918B", "SM-A546B", "SM-G998U", "SM-N986U", "SM-F946B", "SM-A536E",
        "Pixel 6", "Pixel 6 Pro", "Pixel 7", "Pixel 7 Pro", "Pixel 8", "Pixel 8 Pro", "Pixel 9", "Pixel 9 Pro",
        "Redmi Note 12", "Redmi Note 13", "Redmi Note 11", "M2102J20SG", "M2103K19PG", "23021RAA2Y",
        "OnePlus 11", "OnePlus 12", "OnePlus 9 Pro", "PJF110", "CPH2581",
        "Nokia G50", "Nokia X20", "TA-1456",
        "moto g stylus 5G", "motorola edge 40", "XT2255-1",
        "ASUS_AI2202", "ASUS_I003D",
        "vivo X100", "V2309", "V2241A",
        "POCO X6 Pro", "POCO F5", "23076PC4BG",
        "realme GT 5", "RMX3700",
        "Honor Magic5", "PGT-N19",
        "Infinix HOT 30", "Infinix X6831"
    };

    private static final String[] LANGUAGES = {
        "en-US,en;q=0.9", "en-GB,en;q=0.8", "es-ES,es;q=0.9", "pt-BR,pt;q=0.9",
        "fr-FR,fr;q=0.9", "de-DE,de;q=0.9", "ar-SA,ar;q=0.9", "hi-IN,hi;q=0.9",
        "ru-RU,ru;q=0.9", "id-ID,id;q=0.9", "tr-TR,tr;q=0.9", "ja-JP,ja;q=0.9",
        "zh-CN,zh;q=0.9", "ko-KR,ko;q=0.9", "it-IT,it;q=0.9", "pl-PL,pl;q=0.9"
    };

    private static final String[] REFERERS = {
        "https://www.google.com/", "https://m.facebook.com/", "https://www.bing.com/",
        "https://duckduckgo.com/", "https://t.co/abc", "https://www.reddit.com/",
        "https://news.ycombinator.com/", "https://www.youtube.com/", "https://twitter.com/",
        "https://www.instagram.com/", "https://www.tiktok.com/", "https://www.linkedin.com/",
        "https://www.pinterest.com/", "https://www.snapchat.com/"
    };

    /**
     * Viewport dimensions for the top-10 most-common device profiles.
     * [GOD] Rotating these prevents screen-size-vs-UA fingerprint mismatches.
     */
    private static final int[][] VIEWPORTS = {
        {412, 915},   // Samsung Galaxy S22/S23 (1080x2340 @ ~2.625x)
        {393, 852},   // Pixel 7/8 (1080x2400 @ ~2.75x)
        {412, 914},   // OnePlus 11
        {393, 873},   // Pixel 6 (1080x2400 @ ~2.75x)
        {411, 731},   // Redmi Note 12 — narrower
        {411, 867},   // Redmi Note 13
        {412, 919},   // Galaxy S24
        {393, 809},   // Pixel 6a
        {412, 892},   // Galaxy S21
        {360, 780},   // Smaller Android ~720p
        {480, 1060},  // Phablet / foldable inner
        {411, 903}    // Generic 1080p device
    };

    // ═══════════════════════════════════════════════════════════════════
    //  TUNNEL DESCRIPTOR
    // ═══════════════════════════════════════════════════════════════════

    private static class WarpTunnel implements Tunnel {
        @Override public String getName() { return "warp"; }
        @Override public void onStateChange(State newState) {
            Log.d(TAG, "[WARP] Tunnel state: " + newState);
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  JS BRIDGE  –  STATIC inner class; no Activity leak
    // ═══════════════════════════════════════════════════════════════════

    /**
     * [GOD] Made static with explicit SharedPreferences reference
     * to eliminate the implicit outer-class leak. Also holds a
     * WeakReference to the Activity for triggering WARP rotation.
     */
    public static class AdCounterBridge {
        private final SharedPreferences prefs;
        private final WeakReference<MainActivity> activityRef;

        public AdCounterBridge(SharedPreferences prefs, MainActivity activity) {
            this.prefs = prefs;
            this.activityRef = new WeakReference<>(activity);
        }

        @JavascriptInterface
        public int getAdLoadCount() {
            return prefs.getInt("adLoadCount", 0);
        }

        @JavascriptInterface
        public void setAdLoadCount(int count) {
            prefs.edit().putInt("adLoadCount", count).apply();
            Log.d(TAG, "[BRIDGE] Saved ad count: " + count);
            if (count > 0 && count % 500 == 0) {
                MainActivity activity = activityRef.get();
                if (activity != null && !activity.destroying) {
                    Log.d(TAG, "[BRIDGE] Triggering IP rotation at count=" + count);
                    activity.rotateWarpIdentity();
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  CREATION
    // ═══════════════════════════════════════════════════════════════════

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("AdsViewerPrefs", Context.MODE_PRIVATE);

        applyImmersiveMode();            // [GOD] extracted + used in onWindowFocusChanged too

        initWebView();
        initVpnLauncher();
        initWireGuard();
    }

    // ═══════════════════════════════════════════════════════════════════
    //  IMMERSIVE MODE
    // ═══════════════════════════════════════════════════════════════════

    private void applyImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyImmersiveMode();   // [GOD] re-apply when focus regained
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  WEBVIEW SETUP
    // ═══════════════════════════════════════════════════════════════════

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void initWebView() {
        webView = findViewById(R.id.webview);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            //noinspection deprecation — required for pre-KK WebView databases
            s.setDatabasePath(getApplicationContext().getDir("databases", 0).getPath());
        }
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        // Third-party cookies
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        CookieManager.getInstance().setAcceptCookie(true);

        // [GOD] Static bridge — no Activity leak
        webView.addJavascriptInterface(
            new AdCounterBridge(prefs, this), "AndroidBridge"
        );

        webView.setWebViewClient(new AdsWebViewClient());
        webView.setWebChromeClient(new AdsChromeClient());
    }

    // ═══════════════════════════════════════════════════════════════════
    //  WEBVIEW CLIENT  –  inner class keeps WebView lifecycle contained
    // ═══════════════════════════════════════════════════════════════════

    private class AdsWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            Log.d(TAG, "[WV] Page started: " + url);

            // [GOD] Injected spoofing: screen/viewport + language (best-effort).
            // HTTP headers handle the reliable referrer spoofing (see rotateFingerprintAndReload).
            int[] vp = VIEWPORTS[secureRandom.nextInt(VIEWPORTS.length)];
            String lang = currentLanguage.split(",")[0]; // e.g. "en-US"

            String js = "(function(){" +
                "  try {" +
                "    var vp=" + vp[0] + "," + vp[1] + ";" +
                "    Object.defineProperty(screen,'width',{get:function(){return vp[0];}});" +
                "    Object.defineProperty(screen,'height',{get:function(){return vp[1];}});" +
                "    Object.defineProperty(screen,'availWidth',{get:function(){return vp[0];}});" +
                "    Object.defineProperty(screen,'availHeight',{get:function(){return vp[1];}});" +
                "  } catch(e){}" +
                "  try {" +
                "    Object.defineProperty(navigator,'language',{get:function(){return '" + lang + "';}});" +
                "    Object.defineProperty(navigator,'languages',{get:function(){return ['" + lang + "'];}});" +
                "  } catch(e){}" +
                "  console.log('[SPOOF] screen=" + vp[0] + "x" + vp[1] + " lang=" + lang + "');" +
                "})();";
            view.evaluateJavascript(js, null);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            Log.d(TAG, "[WV] Page finished: " + url);
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            String url = (request != null && request.getUrl() != null) ? request.getUrl().toString() : "?";
            boolean main = request != null && request.isForMainFrame();
            Log.e(TAG, "[WV-ERR] " + (main ? "MAIN" : "sub")
                + " code=" + error.getErrorCode()
                + " desc=" + error.getDescription()
                + " url=" + url);
        }

        // [GOD] Prevent SSL error pages from showing — proceed on all ad domains
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) {
            Log.w(TAG, "[WV-SSL] Proceeding past SSL error: " + error.getUrl()
                + " primary=" + error.getPrimaryError());
            handler.proceed();
        }

        // [GOD] Intercept requests to add/override headers at the HTTP level
        // (more reliable than JS-level spoofing for the initial request)
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            // Currently handled via the header map in loadUrl().
            // Override here if you need per-request header injection beyond main frame.
            return super.shouldInterceptRequest(view, request);
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  CHROME CLIENT
    // ═══════════════════════════════════════════════════════════════════

    private static class AdsChromeClient extends WebChromeClient {
        @Override
        public boolean onConsoleMessage(ConsoleMessage cm) {
            Log.d(TAG, "[JS] " + cm.message()
                + " -- line " + cm.lineNumber()
                + " of " + cm.sourceId());
            return true;
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  VPN LAUNCHER
    // ═══════════════════════════════════════════════════════════════════

    private void initVpnLauncher() {
        vpnPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Log.d(TAG, "[WARP] VPN permission granted");
                    startWarpTunnel(false);
                } else {
                    Log.w(TAG, "[WARP] VPN permission denied; running without VPN");
                    Toast.makeText(this, "VPN permission denied. Running without WARP.",
                        Toast.LENGTH_LONG).show();
                    startWithoutWarp();
                }
            }
        );
    }

    // ═══════════════════════════════════════════════════════════════════
    //  WIREGUARD INIT
    // ═══════════════════════════════════════════════════════════════════

    private void initWireGuard() {
        wgBackend = new GoBackend(getApplicationContext());
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            Log.d(TAG, "[WARP] Requesting VPN permission from user");
            vpnPermissionLauncher.launch(prep);
        } else {
            Log.d(TAG, "[WARP] VPN permission already granted");
            startWarpTunnel(false);
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  WARP TUNNEL MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════

    private void startWarpTunnel(final boolean forceFreshRegistration) {
        executor.execute(() -> {
            if (destroying) return;

            int attempt = 0;
            Exception lastErr = null;
            while (attempt < 3) {
                attempt++;
                try {
                    WarpRegistration.WarpConfig wc =
                        WarpRegistration.getOrRegister(prefs, forceFreshRegistration);

                    Interface iface = new Interface.Builder()
                        .parsePrivateKey(wc.privateKeyBase64)
                        .parseAddresses(wc.v4Address + "/32, " + wc.v6Address + "/128")
                        .parseDnsServers("1.1.1.1, 1.0.0.1")
                        .build();

                    Peer peer = new Peer.Builder()
                        .parsePublicKey(wc.serverPublicKey)
                        .parseEndpoint(wc.endpoint)
                        .parseAllowedIPs("0.0.0.0/0, ::/0")
                        .parsePersistentKeepalive("25")
                        .build();

                    Config cfg = new Config.Builder()
                        .setInterface(iface)
                        .addPeer(peer)
                        .build();

                    try {
                        wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
                    } catch (Exception ignored) {}

                    wgBackend.setState(warpTunnel, Tunnel.State.UP, cfg);
                    warpUp = true;
                    Log.d(TAG, "[WARP] Tunnel UP");

                    Thread.sleep(3000);
                    checkCurrentIp();

                    mainHandler.post(() -> {
                        if (destroying) return;
                        Toast.makeText(MainActivity.this,
                            "WARP connected! IP will rotate every 500 ads",
                            Toast.LENGTH_LONG).show();
                        rotateFingerprintAndReload(true);
                        scheduleRotation();    // [GOD] variable-interval scheduling
                    });
                    return;

                } catch (Exception e) {
                    lastErr = e;
                    Log.e(TAG, "[WARP] Attempt " + attempt + " failed: " + e.getMessage(), e);
                    try { Thread.sleep(1500L * attempt); } catch (InterruptedException ignored) {}
                }
            }

            Log.e(TAG, "[WARP] All registration attempts failed", lastErr);
            mainHandler.post(() -> {
                if (destroying) return;
                Toast.makeText(MainActivity.this,
                    "WARP unavailable — running without VPN", Toast.LENGTH_LONG).show();
                startWithoutWarp();
            });
        });
    }

    private void startWithoutWarp() {
        Log.w(TAG, "[APP] Starting WITHOUT WARP (direct mode)");
        warpUp = false;
        currentExitIp.set("direct");
        rotateFingerprintAndReload(true);
        scheduleRotation();
    }

    /**
     * Called every 500 ad loads. Every 5th call re-registers a fresh WARP device.
     */
    private void rotateWarpIdentity() {
        if (destroying) return;

        if (!warpUp) {
            Log.w(TAG, "[WARP] Tunnel not up, starting fresh");
            startWarpTunnel(true);
            return;
        }

        int rot = rotationsSinceReregister.incrementAndGet();
        if (rot >= REREGISTER_EVERY_N_ROTATIONS) {
            Log.d(TAG, "[WARP] Re-registering new WARP device for fresh exit IP");
            rotationsSinceReregister.set(0);
            WarpRegistration.clearCache(prefs);
            startWarpTunnel(true);
        } else {
            Log.d(TAG, "[WARP] Bouncing tunnel for IP refresh (rotation "
                + rot + "/" + REREGISTER_EVERY_N_ROTATIONS + ")");
            startWarpTunnel(false);
        }
    }

    private void checkCurrentIp() {
        try {
            URL url = new URL("https://api.ipify.org?format=text");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(15_000);
            conn.setReadTimeout(15_000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String ip = reader.readLine();
            reader.close();
            conn.disconnect();
            currentExitIp.set(ip != null ? ip : "unknown");
            Log.d(TAG, "[WARP] Current IP: " + currentExitIp.get());
        } catch (Exception e) {
            Log.e(TAG, "[WARP] Error checking IP: " + e.getMessage());
            currentExitIp.set("unknown");
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ROTATION SCHEDULING  –  variable interval [GOD]
    // ═══════════════════════════════════════════════════════════════════

    /**
     * Schedule the next fingerprint rotation after a random delay
     * between {@link #ROTATION_INTERVAL_MS_MIN} and {@link #ROTATION_INTERVAL_MS_MAX}.
     * <p>
     * The Runnable reference is replaced each time so that a concurrent
     * {@link #startWithoutWarp()} or re-registration only ever has one
     * active timer.
     */
    private void scheduleRotation() {
        mainHandler.removeCallbacksAndMessages(null); // [GOD] cancel any pending rotation
        Runnable r = () -> {
            if (destroying) return;
            rotateFingerprintAndReload(false);
            scheduleRotation(); // re-schedule with new random delay
        };
        rotationRunnable = r;
        int delay = ROTATION_INTERVAL_MS_MIN
            + secureRandom.nextInt(ROTATION_INTERVAL_MS_MAX - ROTATION_INTERVAL_MS_MIN + 1);
        Log.d(TAG, "[TIMER] Next rotation in " + delay + "ms");
        mainHandler.postDelayed(r, delay);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  FINGERPRINT ROTATION + PAGE RELOAD
    // ═══════════════════════════════════════════════════════════════════

    private void rotateFingerprintAndReload(boolean firstLoad) {
        if (destroying) return;

        int rot = rotationCount.incrementAndGet();
        String ua = randomUserAgent();
        webView.getSettings().setUserAgentString(ua);
        currentLanguage = LANGUAGES[secureRandom.nextInt(LANGUAGES.length)];
        currentReferer = REFERERS[secureRandom.nextInt(REFERERS.length)];

        Log.d(TAG, "=== ROTATION #" + rot + " ===");
        Log.d(TAG, "UA: " + ua.substring(0, Math.min(70, ua.length())) + "...");
        Log.d(TAG, "Lang: " + currentLanguage);
        Log.d(TAG, "Referer: " + currentReferer);
        Log.d(TAG, "ExitIP: " + currentExitIp.get() + (warpUp ? " [WARP]" : " [DIRECT]"));

        // ── Wipe session artifacts ─────────────────────────────────
        CookieManager cm = CookieManager.getInstance();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cm.removeAllCookies(value -> { /* [GOD] callback required on API 21+ */ });
            cm.removeSessionCookies(value -> {});
        } else {
            //noinspection deprecation
            cm.removeAllCookie();
            //noinspection deprecation
            cm.removeSessionCookie();
        }
        cm.flush();

        WebStorage.getInstance().deleteAllData();
        webView.clearCache(true);
        webView.clearHistory();
        webView.clearFormData();
        webView.clearSslPreferences();

        // ── Build URL with proper query separator [GOD] &t= NOW CORRECT ──
        String visitorId = UUID.randomUUID().toString().replace("-", "");
        long ts = System.currentTimeMillis();
        String url = "file:///android_asset/index.html?vid=" + visitorId + "&t=" + ts;

        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", currentLanguage);
        headers.put("Referer", currentReferer);       // [GOD] HTTP-level spoof — reliable

        webView.loadUrl(url, headers);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  RANDOM GENERATORS
    // ═══════════════════════════════════════════════════════════════════

    private String randomBuildId() {
        char[] prefix = {'U', 'T', 'S', 'R', 'Q', 'P'};
        char p = prefix[secureRandom.nextInt(prefix.length)];
        int year = 22 + secureRandom.nextInt(4);
        int month = 1 + secureRandom.nextInt(12);
        int day = 1 + secureRandom.nextInt(28);
        int patch = secureRandom.nextInt(40);
        return String.format("%cP%dA.%02d%02d%02d.%03d",
            p, 1 + secureRandom.nextInt(2), year, month, day, patch);
    }

    private String randomUserAgent() {
        int kind = secureRandom.nextInt(10);
        if (kind == 0) {
            // iOS CriOS
            int iosMajor = 14 + secureRandom.nextInt(5);
            int iosMinor = secureRandom.nextInt(7);
            int chromeMajor = 110 + secureRandom.nextInt(25);
            int chromeMinor = secureRandom.nextInt(7000);
            int chromePatch = secureRandom.nextInt(250);
            return "Mozilla/5.0 (iPhone; CPU iPhone OS " + iosMajor + "_" + iosMinor
                + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/"
                + chromeMajor + ".0." + chromeMinor + "." + chromePatch
                + " Mobile/15E148 Safari/604.1";
        }

        int androidMajor = 9 + secureRandom.nextInt(7);
        int chromeMajor = 100 + secureRandom.nextInt(35);
        int chromeBuild = 1000 + secureRandom.nextInt(7500);
        int chromePatch = secureRandom.nextInt(250);
        String model = DEVICE_MODELS[secureRandom.nextInt(DEVICE_MODELS.length)];
        String build = (secureRandom.nextInt(2) == 0) ? "" : " Build/" + randomBuildId();
        if (secureRandom.nextInt(3) == 0) {
            model = model + "-" + (char) ('A' + secureRandom.nextInt(26)) + (100 + secureRandom.nextInt(900));
        }
        return "Mozilla/5.0 (Linux; Android " + androidMajor + "; " + model + build
            + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
            + chromeMajor + ".0." + chromeBuild + "." + chromePatch
            + " Mobile Safari/537.36";
    }

    // ═══════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ═══════════════════════════════════════════════════════════════════

    @Override
    protected void onDestroy() {
        destroying = true;                      // [GOD] guard against late handler execution
        mainHandler.removeCallbacksAndMessages(null);

        try {
            if (wgBackend != null && warpUp) {
                wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
            }
        } catch (Exception e) {
            Log.w(TAG, "[WARP] Error tearing down tunnel: " + e.getMessage());
        }

        // [GOD] Graceful executor shutdown
        executor.shutdown();
        try {
            if (!executor.awaitTermination(3, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        if (webView != null) {
            webView.stopLoading();
            // [GOD] Must detach from parent before destroy to prevent native crash
            ViewGroup parent = (ViewGroup) webView.getParent();
            if (parent != null) {
                parent.removeView(webView);
            }
            webView.destroy();
            webView = null;
        }

        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}
