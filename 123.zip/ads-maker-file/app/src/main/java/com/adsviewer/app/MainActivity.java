package com.adsviewer.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import com.wireguard.config.Interface;
import com.wireguard.config.Peer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AdsViewer";
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String currentLanguage = "en-US,en;q=0.9";
    private String currentReferer  = "https://www.google.com/";
    private int    rotationCount   = 0;
    private String currentExitIp   = "unknown";

    // WARP / WireGuard state
    private Backend     wgBackend;
    private final WarpTunnel warpTunnel = new WarpTunnel();
    private boolean warpUp = false;
    private static final int REREGISTER_EVERY_N_ROTATIONS = 5;
    private int rotationsSinceReregister = 0;

    private ActivityResultLauncher<Intent> vpnPermissionLauncher;

    /* ------------------------------------------------------------------ */
    /*  DESKTOP LANGUAGE POOL                                               */
    /* ------------------------------------------------------------------ */
    private static final String[] LANGUAGES = new String[]{
        "en-US,en;q=0.9",
        "en-GB,en;q=0.9,en-US;q=0.8",
        "en-CA,en;q=0.9",
        "en-AU,en;q=0.9",
        "es-ES,es;q=0.9,en;q=0.8",
        "es-US,es;q=0.9,en;q=0.8",
        "pt-BR,pt;q=0.9,en;q=0.8",
        "fr-FR,fr;q=0.9,en;q=0.8",
        "de-DE,de;q=0.9,en;q=0.8",
        "it-IT,it;q=0.9,en;q=0.8",
        "nl-NL,nl;q=0.9,en;q=0.8",
        "pl-PL,pl;q=0.9,en;q=0.8",
        "ru-RU,ru;q=0.9,en;q=0.8",
        "ja-JP,ja;q=0.9,en;q=0.8",
        "ko-KR,ko;q=0.9,en;q=0.8",
        "zh-CN,zh;q=0.9,en;q=0.8"
    };

    /* ------------------------------------------------------------------ */
    /*  DESKTOP REFERER POOL                                                */
    /* ------------------------------------------------------------------ */
    private static final String[] REFERERS = new String[]{
        "https://www.google.com/",
        "https://www.google.co.uk/",
        "https://www.google.ca/",
        "https://www.google.com.au/",
        "https://www.bing.com/",
        "https://duckduckgo.com/",
        "https://search.yahoo.com/",
        "https://www.reddit.com/",
        "https://news.ycombinator.com/",
        "https://www.youtube.com/",
        "https://www.twitter.com/",
        "https://www.linkedin.com/",
        "https://www.facebook.com/",
        "https://www.wikipedia.org/",
        "https://www.msn.com/",
        "https://www.nytimes.com/"
    };

    /* ------------------------------------------------------------------ */
    /*  TUNNEL DESCRIPTOR                                                   */
    /* ------------------------------------------------------------------ */
    private static class WarpTunnel implements Tunnel {
        @Override public String getName() { return "warp"; }
        @Override public void onStateChange(State newState) {
            Log.d(TAG, "[WARP] Tunnel state: " + newState);
        }
    }

    /* ------------------------------------------------------------------ */
    /*  ANDROID ↔ JS BRIDGE                                                 */
    /* ------------------------------------------------------------------ */
    public class AdCounterBridge {
        @JavascriptInterface
        public int getAdLoadCount() {
            return prefs.getInt("adLoadCount", 0);
        }

        @JavascriptInterface
        public void setAdLoadCount(int count) {
            prefs.edit().putInt("adLoadCount", count).apply();
            Log.d(TAG, "[BRIDGE] Saved ad count: " + count);

            if (count > 0 && count % 500 == 0) {
                Log.d(TAG, "[WARP] Ad load count reached " + count + ", triggering IP rotation");
                rotateWarpIdentity();
            }
        }
    }

    /* ================================================================== */
    /*  randomUserAgent()                                                   */
    /*  Generates ONLY realistic desktop-class User-Agent strings.         */
    /*  Platforms: Windows, macOS, Linux                                    */
    /*  Browsers:  Chrome, Edge, Firefox, Safari (macOS only)              */
    /*                                                                      */
    /*  Full Chrome client-hints compatible profiles are produced so        */
    /*  the UA is consistent with what real desktop browsers send.          */
    /* ================================================================== */
    private String randomUserAgent() {

        // ── Chrome version pool (last 3 stable generations, realistic sub-versions)
        int[][] chromeVersions = {
            {124, 0, 6367, 82},
            {124, 0, 6367, 91},
            {124, 0, 6367, 118},
            {123, 0, 6312, 58},
            {123, 0, 6312, 86},
            {123, 0, 6312, 107},
            {122, 0, 6261, 57},
            {122, 0, 6261, 94},
            {122, 0, 6261, 128},
            {121, 0, 6167, 85},
            {121, 0, 6167, 101},
            {120, 0, 6099, 109},
            {120, 0, 6099, 130},
            {119, 0, 6045, 123},
            {118, 0, 5993, 88}
        };

        // ── Firefox version pool
        int[] firefoxVersions = {
            125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115
        };

        // ── Edge version pool (always tracks Chrome closely)
        int[][] edgeVersions = {
            {124, 0, 2478, 51},
            {124, 0, 2478, 67},
            {123, 0, 2420, 81},
            {123, 0, 2420, 97},
            {122, 0, 2365, 80},
            {122, 0, 2365, 92},
            {121, 0, 2277, 128},
            {120, 0, 2210, 133}
        };

        // ── macOS version pool
        String[] macVersions = {
            "10_15_7",   // Catalina  (still very common in UA strings)
            "11_7_10",   // Big Sur
            "12_7_4",    // Monterey
            "13_6_6",    // Ventura
            "14_4_1",    // Sonoma
            "14_5"
        };

        // ── Windows NT version pool
        String[] winNtVersions = {
            "10.0",  // Windows 10 & 11 both report 10.0
            "10.0",
            "10.0",  // weighted – 10/11 dominate
            "10.0"
        };

        // ── WebKit build strings used by Chrome on all platforms
        String webKitToken = "AppleWebKit/537.36 (KHTML, like Gecko)";

        // ── Safari compat token always appended to Chrome/Edge
        String safariCompat = "Safari/537.36";

        // ── Decide platform (weights: Windows 55 %, macOS 28 %, Linux 17 %)
        int platformRoll = random.nextInt(100);
        String platform; // "windows" | "mac" | "linux"
        if      (platformRoll < 55) platform = "windows";
        else if (platformRoll < 83) platform = "mac";
        else                        platform = "linux";

        // ── Decide browser (weights vary by platform)
        // Windows:  Chrome 52 %, Edge 28 %, Firefox 20 %
        // macOS:    Chrome 50 %, Safari 30 %, Firefox 20 %
        // Linux:    Chrome 70 %, Firefox 30 %
        int browserRoll = random.nextInt(100);
        String browser;
        switch (platform) {
            case "windows":
                if      (browserRoll < 52) browser = "chrome";
                else if (browserRoll < 80) browser = "edge";
                else                       browser = "firefox";
                break;
            case "mac":
                if      (browserRoll < 50) browser = "chrome";
                else if (browserRoll < 80) browser = "safari";
                else                       browser = "firefox";
                break;
            default: // linux
                if (browserRoll < 70) browser = "chrome";
                else                  browser = "firefox";
                break;
        }

        // ── Pick version tokens
        int[]  cv  = chromeVersions [random.nextInt(chromeVersions.length)];
        int[]  ev  = edgeVersions   [random.nextInt(edgeVersions.length)];
        int    ffv = firefoxVersions[random.nextInt(firefoxVersions.length)];
        String mac = macVersions    [random.nextInt(macVersions.length)];
        String win = winNtVersions  [random.nextInt(winNtVersions.length)];

        // ── Build the OS token
        String osToken;
        switch (platform) {
            case "windows":
                // x64 dominates; x86 rare on modern desktop
                osToken = "Windows NT " + win + "; Win64; x64";
                break;
            case "mac":
                osToken = "Macintosh; Intel Mac OS X " + mac;
                break;
            default: // linux
                // x86_64 is universal on modern Linux desktops
                osToken = "X11; Linux x86_64";
                break;
        }

        // ── Assemble final UA string
        switch (browser) {

            // ── Chrome (Windows / macOS / Linux) ────────────────────────────
            case "chrome": {
                // Full version string: major.0.build.patch
                String chromeVer = cv[0] + ".0." + cv[2] + "." + cv[3];
                // Chrome on macOS still carries the AppleWebKit token
                return "Mozilla/5.0 ("
                        + osToken + ") "
                        + webKitToken + " Chrome/"
                        + chromeVer + " "
                        + safariCompat;
            }

            // ── Microsoft Edge (Windows / macOS / Linux) ─────────────────────
            case "edge": {
                // Edge UA includes a matching Chrome token followed by Edg/
                // The underlying Chromium build must be close to the Edge version.
                // We pick a chrome version that matches the Edge major.
                String edgeChromeVer = ev[0] + ".0." + (ev[2] - random.nextInt(30)) + "." + (ev[3] + random.nextInt(20));
                String edgeVer       = ev[0] + ".0." + ev[2] + "." + ev[3];
                return "Mozilla/5.0 ("
                        + osToken + ") "
                        + webKitToken + " Chrome/"
                        + edgeChromeVer + " "
                        + safariCompat + " Edg/"
                        + edgeVer;
            }

            // ── Firefox (Windows / macOS / Linux) ───────────────────────────
            case "firefox": {
                // Firefox uses its own Gecko engine token
                // rv: matches the Firefox major version
                String geckoDate = "20100101"; // frozen Gecko date used by all modern Firefox
                return "Mozilla/5.0 ("
                        + osToken + "; rv:"
                        + ffv + ".0) Gecko/"
                        + geckoDate + " Firefox/"
                        + ffv + ".0";
            }

            // ── Safari (macOS only) ──────────────────────────────────────────
            case "safari": {
                // Safari WebKit builds are tied to macOS version.
                // Realistic WebKit build number ranges per macOS generation.
                int[] safariWebKitBuilds = {
                    605,  // Catalina / Big Sur era
                    606,  // Monterey
                    614,  // Ventura early
                    618   // Ventura / Sonoma
                };
                int wkMajor = safariWebKitBuilds[random.nextInt(safariWebKitBuilds.length)];
                int wkMinor = 1 + random.nextInt(20);
                int wkPatch = 1 + random.nextInt(15);

                // Safari version: tracks macOS release cycle (16.x / 17.x)
                int safariMajor = 16 + random.nextInt(2);  // 16 or 17
                int safariMinor = random.nextInt(6);        // .0 – .5
                int safariPatch = random.nextInt(4);        // .0 – .3

                String safariVer;
                if (safariPatch == 0) {
                    safariVer = safariMajor + "." + safariMinor;
                } else {
                    safariVer = safariMajor + "." + safariMinor + "." + safariPatch;
                }

                String wkFull = wkMajor + ".1." + wkMinor + "." + wkPatch;

                return "Mozilla/5.0 ("
                        + osToken + ") "
                        + "AppleWebKit/" + wkFull
                        + " (KHTML, like Gecko) Version/"
                        + safariVer
                        + " Safari/" + wkFull;
            }

            // ── Fallback: plain Chrome on Windows (should never reach here)
            default: {
                String chromeVer = cv[0] + ".0." + cv[2] + "." + cv[3];
                return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        + webKitToken + " Chrome/"
                        + chromeVer + " "
                        + safariCompat;
            }
        }
    }

    /* ================================================================== */
    /*  onCreate                                                            */
    /* ================================================================== */
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("AdsViewerPrefs", Context.MODE_PRIVATE);

        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        CookieManager.getInstance().setAcceptCookie(true);

        webView.addJavascriptInterface(new AdCounterBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url,
                                      android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d(TAG, "Page started: " + url);

                // Inject navigator / document property overrides consistent
                // with the desktop UA that was set on this load.
                String jsCode =
                    "(function(){" +
                    "  var langs = '" + currentLanguage + "'.split(',');" +
                    "  try { Object.defineProperty(navigator, 'language', " +
                    "    {get: function(){ return langs[0].split(';')[0]; }, configurable: true}); } catch(e) {}" +
                    "  try { Object.defineProperty(navigator, 'languages', " +
                    "    {get: function(){ return langs.map(function(l){ return l.split(';')[0]; }); }, configurable: true}); } catch(e) {}" +
                    // Platform must match the UA; extracted by rotateFingerprintAndReload
                    "  try { Object.defineProperty(navigator, 'platform', " +
                    "    {get: function(){ return '" + currentPlatform + "'; }, configurable: true}); } catch(e) {}" +
                    // maxTouchPoints = 0 on genuine desktops
                    "  try { Object.defineProperty(navigator, 'maxTouchPoints', " +
                    "    {get: function(){ return 0; }, configurable: true}); } catch(e) {}" +
                    // webdriver must be false
                    "  try { Object.defineProperty(navigator, 'webdriver', " +
                    "    {get: function(){ return false; }, configurable: true}); } catch(e) {}" +
                    "  try {" +
                    "    Object.defineProperty(document, 'referrer', " +
                    "      {get: function(){ return '" + currentReferer + "'; }, configurable: true});" +
                    "  } catch(e) {}" +
                    "  console.log('[SPOOF] Language:', navigator.language, " +
                    "              'Platform:', navigator.platform, " +
                    "              'Referrer:', document.referrer);" +
                    "})();";
                view.evaluateJavascript(jsCode, null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page finished loading: " + url);
            }

            @Override
            public void onReceivedError(WebView view,
                                        WebResourceRequest request,
                                        WebResourceError error) {
                super.onReceivedError(view, request, error);
                String loadUrl = (request != null && request.getUrl() != null)
                        ? request.getUrl().toString() : "?";
                boolean forMain = (request != null && request.isForMainFrame());
                Log.e(TAG, "[WV-ERR] " + (forMain ? "MAIN" : "sub")
                        + " code=" + error.getErrorCode()
                        + " desc=" + error.getDescription()
                        + " url=" + loadUrl);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                Log.d(TAG, "[JS] " + cm.message()
                        + " -- From line " + cm.lineNumber()
                        + " of " + cm.sourceId());
                return true;
            }
        });

        // Register VPN permission launcher BEFORE starting tunnel
        vpnPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Log.d(TAG, "[WARP] VPN permission granted");
                        startWarpTunnel(false);
                    } else {
                        Log.w(TAG, "[WARP] VPN permission denied; running without VPN");
                        Toast.makeText(this,
                                "VPN permission denied. Running without WARP.",
                                Toast.LENGTH_LONG).show();
                        startWithoutWarp();
                    }
                });

        wgBackend = new GoBackend(getApplicationContext());
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            Log.d(TAG, "[WARP] Requesting VPN permission from user");
            vpnPermissionLauncher.launch(prep);
        } else {
            Log.d(TAG, "[WARP] VPN permission already granted");
            startWarpTunnel(false);
        }
    }

    /* ================================================================== */
    /*  currentPlatform                                                     */
    /*  Keeps the JS navigator.platform in sync with the UA string.        */
    /* ================================================================== */
    private String currentPlatform = "Win32"; // updated in rotateFingerprintAndReload

    /**
     * Derive a JS-compatible navigator.platform value from the UA string
     * so the two signals are always consistent.
     */
    private String platformFromUA(String ua) {
        if (ua.contains("Windows")) return "Win32";
        if (ua.contains("Macintosh")) return "MacIntel";
        if (ua.contains("Linux")) return "Linux x86_64";
        return "Win32"; // safe default
    }

    /* ================================================================== */
    /*  WARP tunnel management (unchanged logic)                            */
    /* ================================================================== */
    private void startWarpTunnel(final boolean forceFreshRegistration) {
        executor.execute(() -> {
            int attempt = 0;
            Exception lastErr = null;
            while (attempt < 3) {
                attempt++;
                try {
                    WarpRegistration.WarpConfig wc =
                            WarpRegistration.getOrRegister(prefs, forceFreshRegistration);

                    Interface iface = new Interface.Builder()
                            .parsePrivateKey(wc.privateKeyBase64)
                            .parseAddresses(wc.v4Address + "/32, " + wc.v6Address + "/128")
                            .parseDnsServers("1.1.1.1, 1.0.0.1")
                            .build();

                    Peer peer = new Peer.Builder()
                            .parsePublicKey(wc.serverPublicKey)
                            .parseEndpoint(wc.endpoint)
                            .parseAllowedIPs("0.0.0.0/0, ::/0")
                            .parsePersistentKeepalive("25")
                            .build();

                    Config cfg = new Config.Builder()
                            .setInterface(iface)
                            .addPeer(peer)
                            .build();

                    try {
                        wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
                    } catch (Exception ignored) {}

                    wgBackend.setState(warpTunnel, Tunnel.State.UP, cfg);
                    warpUp = true;
                    Log.d(TAG, "[WARP] Tunnel UP");

                    Thread.sleep(3000);
                    checkCurrentIp();

                    handler.post(() -> {
                        Toast.makeText(MainActivity.this,
                                "WARP connected! IP will rotate every 500 ads",
                                Toast.LENGTH_LONG).show();
                        rotateFingerprintAndReload(true);
                        handler.postDelayed(rotateRunnable, 10_000);
                    });
                    return;
                } catch (Exception e) {
                    lastErr = e;
                    Log.e(TAG, "[WARP] Attempt " + attempt + " failed: " + e.getMessage(), e);
                    try { Thread.sleep(1500L * attempt); }
                    catch (InterruptedException ie) { /* ignore */ }
                }
            }

            Log.e(TAG, "[WARP] All registration attempts failed", lastErr);
            handler.post(() -> {
                Toast.makeText(MainActivity.this,
                        "WARP unavailable - running without VPN",
                        Toast.LENGTH_LONG).show();
                startWithoutWarp();
            });
        });
    }

    private void startWithoutWarp() {
        Log.w(TAG, "[APP] Starting WITHOUT WARP (direct mode)");
        warpUp        = false;
        currentExitIp = "direct";
        rotateFingerprintAndReload(true);
        handler.postDelayed(rotateRunnable, 10_000);
    }

    private void rotateWarpIdentity() {
        if (!warpUp) {
            Log.w(TAG, "[WARP] Tunnel not up, attempting to start fresh");
            startWarpTunnel(true);
            return;
        }
        rotationsSinceReregister++;
        boolean reregister = rotationsSinceReregister >= REREGISTER_EVERY_N_ROTATIONS;
        if (reregister) {
            Log.d(TAG, "[WARP] Re-registering new WARP device for fresh exit IP");
            rotationsSinceReregister = 0;
            WarpRegistration.clearCache(prefs);
            startWarpTunnel(true);
        } else {
            Log.d(TAG, "[WARP] Bouncing tunnel for IP refresh (rotation "
                    + rotationsSinceReregister + "/" + REREGISTER_EVERY_N_ROTATIONS + ")");
            startWarpTunnel(false);
        }
    }

    private void checkCurrentIp() {
        try {
            URL url = new URL("https://api.ipify.org?format=text");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            String ip = reader.readLine();
            reader.close();
            conn.disconnect();
            currentExitIp = ip;
            Log.d(TAG, "[WARP] Current IP: " + currentExitIp);
        } catch (Exception e) {
            Log.e(TAG, "[WARP] Error checking IP: " + e.getMessage());
            currentExitIp = "unknown";
        }
    }

    /* ================================================================== */
    /*  Rotation runnable & fingerprint reload                              */
    /* ================================================================== */
    private final Runnable rotateRunnable = new Runnable() {
        @Override public void run() {
            rotateFingerprintAndReload(false);
            handler.postDelayed(this, 10_000);
        }
    };

    private void rotateFingerprintAndReload(boolean firstLoad) {
        rotationCount++;

        String ua = randomUserAgent();

        // Keep navigator.platform consistent with the UA OS token
        currentPlatform = platformFromUA(ua);

        webView.getSettings().setUserAgentString(ua);

        currentLanguage = LANGUAGES[random.nextInt(LANGUAGES.length)];
        currentReferer  = REFERERS [random.nextInt(REFERERS.length)];

        Log.d(TAG, "=== ROTATION #" + rotationCount + " ===");
        Log.d(TAG, "User-Agent: " + ua.substring(0, Math.min(80, ua.length())) + "...");
        Log.d(TAG, "Platform:   " + currentPlatform);
        Log.d(TAG, "Language:   " + currentLanguage);
        Log.d(TAG, "Referer:    " + currentReferer);
        Log.d(TAG, "Exit IP:    " + currentExitIp + (warpUp ? " [WARP ACTIVE]" : " [DIRECT]"));

        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.removeSessionCookies(null);
        cm.flush();
        WebStorage.getInstance().deleteAllData();
        webView.clearCache(true);
        webView.clearHistory();
        webView.clearFormData();
        webView.clearSslPreferences();

        String visitorId = UUID.randomUUID().toString().replace("-", "");
        long   ts        = System.currentTimeMillis();
        String url       = "file:///android_asset/index.html?vid=" + visitorId + "&t=" + ts;

        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", currentLanguage);
        headers.put("Referer",         currentReferer);

        Log.d(TAG, "Loading: " + url);
        webView.loadUrl(url, headers);
    }

    /* ================================================================== */
    /*  Lifecycle                                                           */
    /* ================================================================== */
    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try {
            if (wgBackend != null && warpUp) {
                wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
            }
        } catch (Exception e) {
            Log.w(TAG, "[WARP] Error tearing down tunnel: " + e.getMessage());
        }
        executor.shutdown();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}