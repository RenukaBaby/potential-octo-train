package com.adsviewer.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import com.wireguard.config.Interface;
import com.wireguard.config.Peer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AdsViewer";
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String currentLanguage = "en-US,en;q=0.9";
    private String currentReferer = "https://www.google.com/";
    private int rotationCount = 0;
    private String currentExitIp = "unknown";

    // WARP / WireGuard state
    private Backend wgBackend;
    private final WarpTunnel warpTunnel = new WarpTunnel();
    private boolean warpUp = false;
    private static final int REREGISTER_EVERY_N_ROTATIONS = 5;
    private int rotationsSinceReregister = 0;

    private ActivityResultLauncher<Intent> vpnPermissionLauncher;

    private static final String[] DEVICE_MODELS = new String[] {
        "SM-S908B", "SM-S918B", "SM-A546B", "SM-G998U", "SM-N986U", "SM-F946B", "SM-A536E",
        "Pixel 6", "Pixel 6 Pro", "Pixel 7", "Pixel 7 Pro", "Pixel 8", "Pixel 8 Pro", "Pixel 9", "Pixel 9 Pro",
        "Redmi Note 12", "Redmi Note 13", "Redmi Note 11", "M2102J20SG", "M2103K19PG", "23021RAA2Y",
        "OnePlus 11", "OnePlus 12", "OnePlus 9 Pro", "PJF110", "CPH2581",
        "Nokia G50", "Nokia X20", "TA-1456",
        "moto g stylus 5G", "motorola edge 40", "XT2255-1",
        "ASUS_AI2202", "ASUS_I003D",
        "vivo X100", "V2309", "V2241A",
        "POCO X6 Pro", "POCO F5", "23076PC4BG",
        "realme GT 5", "RMX3700",
        "Honor Magic5", "PGT-N19",
        "Infinix HOT 30", "Infinix X6831"
    };

    private static final String[] LANGUAGES = new String[] {
        "en-US,en;q=0.9", "en-GB,en;q=0.8", "es-ES,es;q=0.9", "pt-BR,pt;q=0.9",
        "fr-FR,fr;q=0.9", "de-DE,de;q=0.9", "ar-SA,ar;q=0.9", "hi-IN,hi;q=0.9",
        "ru-RU,ru;q=0.9", "id-ID,id;q=0.9", "tr-TR,tr;q=0.9", "ja-JP,ja;q=0.9",
        "zh-CN,zh;q=0.9", "ko-KR,ko;q=0.9", "it-IT,it;q=0.9", "pl-PL,pl;q=0.9"
    };

    private static final String[] REFERERS = new String[] {
        "https://www.google.com/", "https://m.facebook.com/", "https://www.bing.com/",
        "https://duckduckgo.com/", "https://t.co/abc", "https://www.reddit.com/",
        "https://news.ycombinator.com/", "https://www.youtube.com/", "https://twitter.com/",
        "https://www.instagram.com/", "https://www.tiktok.com/", "https://www.linkedin.com/",
        "https://www.pinterest.com/", "https://www.snapchat.com/"
    };

    /** Tunnel descriptor required by GoBackend. */
    private static class WarpTunnel implements Tunnel {
        @Override public String getName() { return "warp"; }
        @Override public void onStateChange(State newState) {
            Log.d(TAG, "[WARP] Tunnel state: " + newState);
        }
    }

    public class AdCounterBridge {
        @JavascriptInterface
        public int getAdLoadCount() {
            return prefs.getInt("adLoadCount", 0);
        }

        @JavascriptInterface
        public void setAdLoadCount(int count) {
            prefs.edit().putInt("adLoadCount", count).apply();
            Log.d(TAG, "[BRIDGE] Saved ad count: " + count);

            if (count > 0 && count % 500 == 0) {
                Log.d(TAG, "[WARP] Ad load count reached " + count + ", triggering IP rotation");
                rotateWarpIdentity();
            }
        }
    }

    private String randomBuildId() {
        char[] prefixOptions = {'U','T','S','R','Q','P'};
        char p = prefixOptions[random.nextInt(prefixOptions.length)];
        int year = 22 + random.nextInt(4);
        int month = 1 + random.nextInt(12);
        int day = 1 + random.nextInt(28);
        int patch = random.nextInt(40);
        return String.format("%cP%dA.%02d%02d%02d.%03d",
                p, 1 + random.nextInt(2), year, month, day, patch);
    }

    /**
     * Desktop-only User-Agent generator.
     *
     * Profiles:
     *   0-3  → Windows  + Chrome
     *   4    → Windows  + Edge
     *   5    → Windows  + Firefox
     *   6-7  → macOS    + Chrome
     *   8    → macOS    + Safari
     *   9    → macOS    + Firefox
     *  10    → Linux    + Chrome
     *  11    → Linux    + Firefox
     *
     * Every UA is paired with a consistent internal profile object so the
     * calling site can later inject matching JS fingerprint overrides.
     */
    private String randomUserAgent() {

        // ── Chrome version pool (only realistic modern releases) ──────────────
        int[][] chromeVersions = {
            {110, 5481, 77},  {112, 5615, 116}, {114, 5735, 131},
            {116, 5845, 57},  {118, 5993, 168}, {120, 6099, 109},
            {122, 6261, 40},  {124, 6367, 82},  {125, 6422, 116},
            {126, 6478, 205}, {127, 6533, 119}, {128, 6613, 172},
            {129, 6668, 66},  {130, 6723, 91},  {131, 6778, 137},
            {132, 6834, 72},  {133, 6943, 58},  {134, 7023, 42},
            {135, 7049, 12}
        };
        int[] cv = chromeVersions[random.nextInt(chromeVersions.length)];
        int chromeMajor = cv[0];
        int chromeBuild = cv[1] + random.nextInt(60);
        int chromePatch = cv[2] + random.nextInt(20);

        // ── Firefox version pool ──────────────────────────────────────────────
        int[] ffVersions = {115, 117, 118, 119, 120, 121, 122, 123, 124, 125,
                            126, 127, 128, 129, 130, 131, 132, 133, 134, 135};
        int ffMajor = ffVersions[random.nextInt(ffVersions.length)];

        // ── macOS version pool ────────────────────────────────────────────────
        String[][] macVersions = {
            {"10_15_7", "10.15.7"}, {"11_7_10", "11.7.10"},
            {"12_7_4",  "12.7.4"},  {"13_6_7",  "13.6.7"},
            {"14_4_1",  "14.4.1"},  {"14_5",    "14.5"},
            {"14_6_1",  "14.6.1"},  {"15_0",    "15.0"},
            {"15_1",    "15.1"},    {"15_2",    "15.2"}
        };
        String[] mac = macVersions[random.nextInt(macVersions.length)];
        String macUa  = mac[0];   // underscored for UA string
        String macDot = mac[1];   // dotted  for display

        // ── WebKit build (Safari / Chrome on macOS) ───────────────────────────
        int[] webkitBuilds = {605, 606, 607, 608, 609, 610, 611};
        int wkBuild = webkitBuilds[random.nextInt(webkitBuilds.length)];
        int wkMinor = 1 + random.nextInt(20);

        // ── Windows NT version pool ───────────────────────────────────────────
        // 10.0 = Win10 or Win11 (both report 10.0 in UA)
        String winNt = (random.nextInt(10) < 9) ? "10.0" : "6.1";   // ~10% Win7 for diversity

        // ── pick profile ──────────────────────────────────────────────────────
        int profile = random.nextInt(12);

        switch (profile) {

            // ── Windows + Chrome ─────────────────────────────────────────────
            case 0: case 1: case 2: case 3: {
                return "Mozilla/5.0 (Windows NT " + winNt + "; Win64; x64) "
                     + "AppleWebKit/537.36 (KHTML, like Gecko) "
                     + "Chrome/" + chromeMajor + ".0." + chromeBuild + "." + chromePatch
                     + " Safari/537.36";
            }

            // ── Windows + Edge ───────────────────────────────────────────────
            case 4: {
                // Edge version tracks Chrome closely; offset by 0-2 minor versions
                int edgeMajor = chromeMajor;
                int edgeBuild = chromeBuild + random.nextInt(30);
                int edgePatch = chromePatch + random.nextInt(10);
                return "Mozilla/5.0 (Windows NT " + winNt + "; Win64; x64) "
                     + "AppleWebKit/537.36 (KHTML, like Gecko) "
                     + "Chrome/" + chromeMajor + ".0." + chromeBuild + "." + chromePatch
                     + " Safari/537.36 "
                     + "Edg/" + edgeMajor + ".0." + edgeBuild + "." + edgePatch;
            }

            // ── Windows + Firefox ────────────────────────────────────────────
            case 5: {
                return "Mozilla/5.0 (Windows NT " + winNt + "; Win64; x64; rv:"
                     + ffMajor + ".0) "
                     + "Gecko/20100101 Firefox/" + ffMajor + ".0";
            }

            // ── macOS + Chrome ───────────────────────────────────────────────
            case 6: case 7: {
                return "Mozilla/5.0 (Macintosh; Intel Mac OS X " + macUa + ") "
                     + "AppleWebKit/537.36 (KHTML, like Gecko) "
                     + "Chrome/" + chromeMajor + ".0." + chromeBuild + "." + chromePatch
                     + " Safari/537.36";
            }

            // ── macOS + Safari ───────────────────────────────────────────────
            case 8: {
                // Safari version roughly matches macOS release era
                int safariMajor = 16 + random.nextInt(3);          // 16, 17, 18
                int safariMinor = random.nextInt(5);
                int safariBuild = 100 + random.nextInt(500);
                return "Mozilla/5.0 (Macintosh; Intel Mac OS X " + macUa + ") "
                     + "AppleWebKit/" + wkBuild + "." + wkMinor + ".15 (KHTML, like Gecko) "
                     + "Version/" + safariMajor + "." + safariMinor
                     + " Safari/" + wkBuild + "." + wkMinor + ".15";
            }

            // ── macOS + Firefox ──────────────────────────────────────────────
            case 9: {
                return "Mozilla/5.0 (Macintosh; Intel Mac OS X " + macDot + "; rv:"
                     + ffMajor + ".0) "
                     + "Gecko/20100101 Firefox/" + ffMajor + ".0";
            }

            // ── Linux + Chrome ───────────────────────────────────────────────
            case 10: {
                return "Mozilla/5.0 (X11; Linux x86_64) "
                     + "AppleWebKit/537.36 (KHTML, like Gecko) "
                     + "Chrome/" + chromeMajor + ".0." + chromeBuild + "." + chromePatch
                     + " Safari/537.36";
            }

            // ── Linux + Firefox ──────────────────────────────────────────────
            case 11: default: {
                return "Mozilla/5.0 (X11; Linux x86_64; rv:"
                     + ffMajor + ".0) "
                     + "Gecko/20100101 Firefox/" + ffMajor + ".0";
            }
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("AdsViewerPrefs", Context.MODE_PRIVATE);

        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        CookieManager.getInstance().setAcceptCookie(true);

        webView.addJavascriptInterface(new AdCounterBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d(TAG, "Page started: " + url);
                String jsCode =
                    "(function(){" +
                    "  var langs = '" + currentLanguage + "'.split(',');" +
                    "  try { Object.defineProperty(navigator, 'language', {get: function(){ return langs[0].split(';')[0]; }, configurable: true}); } catch(e) {}" +
                    "  try { Object.defineProperty(navigator, 'languages', {get: function(){ return langs.map(function(l){ return l.split(';')[0]; }); }, configurable: true}); } catch(e) {}" +
                    "  try {" +
                    "    Object.defineProperty(document, 'referrer', {get: function(){ return '" + currentReferer + "'; }, configurable: true});" +
                    "  } catch(e) {}" +
                    "  console.log('[SPOOF] Language:', navigator.language, 'Referrer:', document.referrer);" +
                    "})();";
                view.evaluateJavascript(jsCode, null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page finished loading: " + url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                String url = request != null && request.getUrl() != null ? request.getUrl().toString() : "?";
                boolean forMain = request != null && request.isForMainFrame();
                Log.e(TAG, "[WV-ERR] " + (forMain ? "MAIN" : "sub") + " code=" + error.getErrorCode()
                        + " desc=" + error.getDescription() + " url=" + url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                Log.d(TAG, "[JS] " + cm.message() + " -- From line " + cm.lineNumber() + " of " + cm.sourceId());
                return true;
            }
        });

        // Register VPN permission launcher BEFORE starting tunnel
        vpnPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Log.d(TAG, "[WARP] VPN permission granted");
                        startWarpTunnel(false);
                    } else {
                        Log.w(TAG, "[WARP] VPN permission denied; running without VPN");
                        Toast.makeText(this, "VPN permission denied. Running without WARP.", Toast.LENGTH_LONG).show();
                        startWithoutWarp();
                    }
                });

        // Initialize WireGuard backend (Go-based) and request VPN consent
        wgBackend = new GoBackend(getApplicationContext());
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            Log.d(TAG, "[WARP] Requesting VPN permission from user");
            vpnPermissionLauncher.launch(prep);
        } else {
            Log.d(TAG, "[WARP] VPN permission already granted");
            startWarpTunnel(false);
        }
    }

    private void startWarpTunnel(final boolean forceFreshRegistration) {
        executor.execute(() -> {
            int attempt = 0;
            Exception lastErr = null;
            while (attempt < 3) {
                attempt++;
                try {
                    WarpRegistration.WarpConfig wc =
                            WarpRegistration.getOrRegister(prefs, forceFreshRegistration);

                    Interface iface = new Interface.Builder()
                            .parsePrivateKey(wc.privateKeyBase64)
                            .parseAddresses(wc.v4Address + "/32, " + wc.v6Address + "/128")
                            .parseDnsServers("1.1.1.1, 1.0.0.1")
                            .build();

                    Peer peer = new Peer.Builder()
                            .parsePublicKey(wc.serverPublicKey)
                            .parseEndpoint(wc.endpoint)
                            .parseAllowedIPs("0.0.0.0/0, ::/0")
                            .parsePersistentKeepalive("25")
                            .build();

                    Config cfg = new Config.Builder()
                            .setInterface(iface)
                            .addPeer(peer)
                            .build();

                    try {
                        wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
                    } catch (Exception ignored) {}

                    wgBackend.setState(warpTunnel, Tunnel.State.UP, cfg);
                    warpUp = true;
                    Log.d(TAG, "[WARP] Tunnel UP");

                    Thread.sleep(3000);
                    checkCurrentIp();

                    handler.post(() -> {
                        Toast.makeText(MainActivity.this,
                                "WARP connected! IP will rotate every 500 ads",
                                Toast.LENGTH_LONG).show();
                        rotateFingerprintAndReload(true);
                        handler.postDelayed(rotateRunnable, 10_000);
                    });
                    return;
                } catch (Exception e) {
                    lastErr = e;
                    Log.e(TAG, "[WARP] Attempt " + attempt + " failed: " + e.getMessage(), e);
                    try { Thread.sleep(1500L * attempt); } catch (InterruptedException ie) { /* ignore */ }
                }
            }

            Log.e(TAG, "[WARP] All registration attempts failed", lastErr);
            handler.post(() -> {
                Toast.makeText(MainActivity.this,
                        "WARP unavailable - running without VPN", Toast.LENGTH_LONG).show();
                startWithoutWarp();
            });
        });
    }

    private void startWithoutWarp() {
        Log.w(TAG, "[APP] Starting WITHOUT WARP (direct mode)");
        warpUp = false;
        currentExitIp = "direct";
        rotateFingerprintAndReload(true);
        handler.postDelayed(rotateRunnable, 10_000);
    }

    private void rotateWarpIdentity() {
        if (!warpUp) {
            Log.w(TAG, "[WARP] Tunnel not up, attempting to start fresh");
            startWarpTunnel(true);
            return;
        }
        rotationsSinceReregister++;
        boolean reregister = rotationsSinceReregister >= REREGISTER_EVERY_N_ROTATIONS;
        if (reregister) {
            Log.d(TAG, "[WARP] Re-registering new WARP device for fresh exit IP");
            rotationsSinceReregister = 0;
            WarpRegistration.clearCache(prefs);
            startWarpTunnel(true);
        } else {
            Log.d(TAG, "[WARP] Bouncing tunnel for IP refresh (rotation "
                    + rotationsSinceReregister + "/" + REREGISTER_EVERY_N_ROTATIONS + ")");
            startWarpTunnel(false);
        }
    }

    private void checkCurrentIp() {
        try {
            URL url = new URL("https://api.ipify.org?format=text");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String ip = reader.readLine();
            reader.close();
            conn.disconnect();
            currentExitIp = ip;
            Log.d(TAG, "[WARP] Current IP: " + currentExitIp);
        } catch (Exception e) {
            Log.e(TAG, "[WARP] Error checking IP: " + e.getMessage());
            currentExitIp = "unknown";
        }
    }

    private final Runnable rotateRunnable = new Runnable() {
        @Override public void run() {
            rotateFingerprintAndReload(false);
            handler.postDelayed(this, 10_000);
        }
    };

    private void rotateFingerprintAndReload(boolean firstLoad) {
        rotationCount++;

        String ua = randomUserAgent();
        webView.getSettings().setUserAgentString(ua);

        currentLanguage = LANGUAGES[random.nextInt(LANGUAGES.length)];
        currentReferer = REFERERS[random.nextInt(REFERERS.length)];

        Log.d(TAG, "=== ROTATION #" + rotationCount + " ===");
        Log.d(TAG, "User-Agent: " + ua.substring(0, Math.min(60, ua.length())) + "...");
        Log.d(TAG, "Language: " + currentLanguage);
        Log.d(TAG, "Referer: " + currentReferer);
        Log.d(TAG, "Exit IP: " + currentExitIp + (warpUp ? " [WARP ACTIVE]" : " [DIRECT]"));

        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.removeSessionCookies(null);
        cm.flush();
        WebStorage.getInstance().deleteAllData();
        webView.clearCache(true);
        webView.clearHistory();
        webView.clearFormData();
        webView.clearSslPreferences();

        String visitorId = UUID.randomUUID().toString().replace("-", "");
        long ts = System.currentTimeMillis();
        String url = "file:///android_asset/index.html?vid=" + visitorId + "&t=" + ts;

        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", currentLanguage);
        headers.put("Referer", currentReferer);

        Log.d(TAG, "Loading: " + url);
        webView.loadUrl(url, headers);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try {
            if (wgBackend != null && warpUp) {
                wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
            }
        } catch (Exception e) {
            Log.w(TAG, "[WARP] Error tearing down tunnel: " + e.getMessage());
        }
        executor.shutdown();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}